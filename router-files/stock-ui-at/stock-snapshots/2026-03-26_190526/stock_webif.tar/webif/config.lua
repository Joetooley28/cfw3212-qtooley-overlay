-----------------------------------------------------------------------------------------------------------------------
-- Copyright (C) 2020 Casa Systems Inc.
--
-----------------------------------------------------------------------------------------------------------------------

-- This is default configuration which can be overridden by configuration under the variants directory
return {
  DEFAULT_PAGE = "status.html",
  LOGCLEAR_CMD = "/sbin/logcat.sh -c",
  REBOOT_TIME_SECS = 150,
}
