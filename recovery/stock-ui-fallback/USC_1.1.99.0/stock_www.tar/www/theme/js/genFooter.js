// Copyright (c) 2020 Casa Systems
// Generating footer code

function genLanguageSelection(currentLanguage) {
    if (Object.keys(SUPPORTED_LANGUAGES).length <= 1) {
        return "";
    }

    let options = "";
    for (const langCode in SUPPORTED_LANGUAGES) {
        options += `
            <option value="${langCode}"${langCode == currentLanguage ? " selected" : ""}>
                ${SUPPORTED_LANGUAGES[langCode]}
            </option>
        `;
    }

    return `
    <div id="language_selection_block">
        <span id="language_selection_title">${_("Language")}</span>
        <span id="language_selection_icon"><img src="/img/language_selection_icon.svg" height="20"></span>
        <span class="custom-dropdown">
            <select id="change_language_selection" class="select" onChange="changeLanguageSelection();">
            ${options}
            </select>
        </span>
    </div>
    `;
}

function genThemeFooter(pageData) {
    let html = `
    <footer class="footer">
      <div class="container">
        <span class="copy-right">${_("Powered by Casa Systems.")}</span>
        ${genLanguageSelection(currentLanguage)}
      </div>
    </footer>
    `;
    return html;
}
