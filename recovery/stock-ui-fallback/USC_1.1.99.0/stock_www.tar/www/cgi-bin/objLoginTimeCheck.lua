objHandler = {
  authenticatedOnly=true,
    readGroups={root=true,admin=true},
    writeGroups={root=true,admin=true},
    get=function(authenticated, requestHandler)
    return {}
  end,
  validate=function(o, requestHandler)
    return true
  end,
  set=function(authenticated, o, requestHandler)
    return
  end
}
