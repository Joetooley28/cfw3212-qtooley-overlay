// Copyright (c) 2022 Casa Systems
// Supporting language selection

// call-back function on change-language-selection UI event
// which should be originated from an UI element ID "change_language_selection"
function changeLanguageSelection() {
    $.post("/language_selection", {
        csrfToken: csrfToken,
        language: $("#change_language_selection").val(),
    }, function (data, textStatus, jqXHR) {
        if (jqXHR.status == 200) {
            location.reload();
        }
    });
}
