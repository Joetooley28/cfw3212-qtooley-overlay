var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
function _(str) {
    if ((typeof xlat !== "undefined")) {
        var newStr = xlat[str];
        if (newStr) {
            newStr = newStr.replace(/&#x2F;/g, '/');
            newStr = newStr.replace(/&amp;/g, '&');
            return newStr;
        }
    }
    return str;
}
function formatString(format, args) {
    return format.replace(/{(\d+)}/g, function (match, number) {
        return typeof args[number] != "undefined" ? args[number] : match;
    });
}
function encode(data) { return Base64.encode(data); }
function decode(data) { return Base64.decode(data); }
function toBool(b) {
    if (typeof b === "string")
        return b !== '0' && b !== '';
    if (typeof b === "number")
        return b !== 0;
    if (typeof b === "boolean")
        return b;
    return false;
}
function validateEmail(email) {
    return email.indexOf("@") > 0;
}
function pollUrl(url, timeout, period, fnSuccess, fnError) {
    return setInterval(function () {
        $.ajax({
            url: url,
            dataType: "script",
            timeout: timeout,
            success: fnSuccess,
            error: fnError
        });
    }, period);
}
function downloadToFile(text, name, type) {
    setEnable("downloadButton", false);
    var a = document.getElementById("fileDownload");
    var file = new Blob([text], { type: type });
    a.href = URL.createObjectURL(file);
    a.download = name;
    setEnable("downloadButton", true);
}
function downloadUrl(url, name) {
    setEnable("downloadButton", false);
    var a = document.getElementById("fileDownload");
    a.href = url;
    a.download = name;
    setEnable("downloadButton", true);
}
function clearLogFiles(csrfToken) {
    setEnable("clearButton", false);
    $.post("logfile/clear_log", { csrfToken: csrfToken })
        .done(function (resp) {
        success_alert("", "Logs were cleared successfully.");
    })
        .fail(function (err) {
        alertInvalidRequest();
    });
    setEnable("clearButton", true);
}
function getServerCertiInfo(succFunc) {
    var url = "genServerCerti/info";
    var result;
    $.getJSON(url, {}, succFunc).fail(function () { console.log("failed to get server certificate info"); });
}
function generateServerCa(succFunc, failFunc) {
    var url1, url2, errMsg;
    var formData = new FormData();
    formData.append("csrfToken", csrfToken);
    url1 = "genServerCerti/gen_ca";
    url2 = "genServerCerti/info";
    errMsg = _("ca fail");
    blockUI_wait(_("GUI pleaseWait"));
    $.ajax({
        xhr: function () {
            var xhr = new XMLHttpRequest();
            return xhr;
        },
        url: url1,
        data: formData,
        processData: false,
        contentType: false,
        type: 'post',
        success: function (respObj) {
            if (respObj.result == "0") {
                $.getJSON(url2, {}, function (res) {
                    if (res.result == "0") {
                        $.unblockUI();
                        succFunc(res);
                    }
                }).fail(function () { $.unblockUI(); failFunc(); });
            }
            else {
                $.unblockUI();
                blockUI_alert(errMsg);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $.unblockUI();
            failFunc();
        }
    });
}
function checkGroupAccess(allowedGroups, userGroups) {
    for (var _i = 0, userGroups_1 = userGroups; _i < userGroups_1.length; _i++) {
        var userGroup = userGroups_1[_i];
        if (allowedGroups.indexOf(userGroup) >= 0) {
            return true;
        }
    }
    return false;
}
function generateDebuginfoX(csrfToken) {
    setEnable("generateButton", false);
    blockUI_wait_progress(_("GUI pleaseWait"));
    $.post("debuginfoX/generate", { csrfToken: csrfToken })
        .done(function (resp) {
        $.unblockUI();
        success_alert("", "Encrypted debuginfo file is generated successfully.");
    })
        .fail(function (err) {
        $.unblockUI();
        alertInvalidRequest();
    });
    setEnable("generateButton", true);
}
var ratio_km_to_mi = 0.621371192;
var valid_digits = 2;
function cvt_km2mi(val) {
    var dist = parseFloat(val);
    if (isNaN(dist)) {
        return '';
    }
    dist *= ratio_km_to_mi;
    var round_err = dist - Number(dist.toFixed(valid_digits));
    if (round_err < ((1 / (ratio_km_to_mi * Math.pow(10, valid_digits))) / 2) &&
        round_err >= (1 / Math.pow(10, valid_digits)) / 2) {
        dist -= 1 / Math.pow(10, valid_digits);
    }
    return dist.toFixed(valid_digits);
}
function cvt_mi2km(val) {
    var dist = parseFloat(val);
    if (isNaN(dist)) {
        return '';
    }
    dist /= ratio_km_to_mi;
    var round_err = dist - Number(dist.toFixed(valid_digits));
    if (round_err > ((ratio_km_to_mi / Math.pow(10, valid_digits)) / 2)) {
        dist += 1 / Math.pow(10, valid_digits);
    }
    return dist.toFixed(valid_digits);
}
function cvt_dd2dms(coord_type, coord, elem) {
    var dd, abs_dd, degrees, minutes, seconds;
    dd = parseFloat(coord);
    if (!isNaN(dd)) {
        abs_dd = Math.abs(dd);
        degrees = Math.floor(abs_dd);
        minutes = Math.floor((abs_dd * 60) % 60);
        seconds = (abs_dd * 3600) % 60;
        if (typeof (elem) == "undefined") {
            if (coord_type == "lati") {
                return (dd > 0 ? "N" : "S") + degrees.toString() + String.fromCharCode(176) + " " +
                    minutes.toString().padStart(2, "0") + "' " + seconds.toFixed(4) + "\"";
            }
            else {
                return (dd > 0 ? "E" : "W") + degrees.toString() + String.fromCharCode(176) + " " +
                    minutes.toString().padStart(2, "0") + "' " + seconds.toFixed(4) + "\"";
            }
        }
        else {
            $("#" + elem + "_dir").val(dd >= 0 ? '+' : '-');
            $("#" + elem + "_d").val(degrees.toString());
            $("#" + elem + "_m").val(minutes.toString().padStart(2, "0"));
            $("#" + elem + "_s").val(seconds.toFixed(4));
        }
    }
    else {
        if (typeof (elem) == "undefined") {
            return '';
        }
        else {
            $("#" + elem + "_dir").val('+');
            $("#" + elem + "_d").val('');
            $("#" + elem + "_m").val('');
            $("#" + elem + "_s").val('');
        }
    }
}
function cvt_dms2dd(elem) {
    var dir = $("#" + elem + "_dir").val();
    var degree = $("#" + elem + "_d").val();
    var minute = $("#" + elem + "_m").val();
    var second = $("#" + elem + "_s").val();
    var abs_dd = 0;
    if (typeof (dir) != "undefined" && typeof (degree) != "undefined" &&
        typeof (minute) != "undefined" && typeof (second) != "undefined") {
        var degreeNum = parseFloat(degree.toString());
        var minuteNum = parseFloat(minute.toString());
        var secondNum = parseFloat(second.toString());
        if (isNaN(degreeNum) || isNaN(minuteNum) || isNaN(secondNum)) {
            return '';
        }
        abs_dd = degreeNum + minuteNum / 60 + secondNum / 3600;
    }
    return (dir == "-" ? "-" : "") + abs_dd.toFixed(6);
}
function get_dms_fields(elem) {
    var dir = $("#" + elem + "_dir").val();
    var degree = $("#" + elem + "_d").val();
    var minute = $("#" + elem + "_m").val();
    var second = $("#" + elem + "_s").val();
    if (elem == "lati_dms") {
        dir = (dir == "-" ? "S" : "N");
    }
    else {
        dir = (dir == "-" ? "W" : "E");
    }
    return (dir + degree.toString() + String.fromCharCode(176) + " " +
        minute.toString().padStart(2, "0") + "' " + second.toString() + '"');
}
function cvt_dm2dd(dir, coord) {
    var dm, degree_only, dd;
    dm = parseFloat(coord);
    if (isNaN(dm)) {
        return '';
    }
    degree_only = Math.floor(dm);
    dd = Math.floor(degree_only / 100) + ((degree_only % 100) / 60) + ((dm - degree_only) / 60);
    return dir + dd.toFixed(6).toString();
}
function generateDebuginfo(csrfToken) {
    setEnable("generateButton", false);
    blockUI_wait_progress(_("GUI pleaseWait"));
    $.post("debuginfo/generate", { csrfToken: csrfToken })
        .done(function (resp) {
        $.unblockUI();
        success_alert("", "Debuginfo file is generated successfully.");
    })
        .fail(function (err) {
        $.unblockUI();
        alertInvalidRequest();
    });
    setEnable("generateButton", true);
}
function getDateVar(date, time) {
    var myDate = new Date();
    myDate.setUTCDate(date.substring(0, 2));
    myDate.setUTCMonth(date.substring(2, 4) - 1);
    var year = parseInt(date.substring(4, 6));
    if (year >= 80) {
        year += 1900;
    }
    else {
        year += 2000;
    }
    myDate.setUTCFullYear(year);
    myDate.setUTCHours(time.substring(0, 2));
    myDate.setUTCMinutes(time.substring(2, 4));
    myDate.setUTCSeconds(time.substring(4, 6));
    return myDate;
}
function UrlDecode(str) {
    var output = "";
    for (var i = 0; i < str.length; i += 3) {
        var val = parseInt("0x" + str.substring(i + 1, i + 3));
        output += String.fromCharCode(val);
    }
    return output;
}
function isLetter(c) {
    return c.toLowerCase() != c.toUpperCase();
}
function pad(str, max) {
    return str.length < max ? pad("0" + str, max) : str;
}
function isValidValue(val) {
    return (typeof val !== "undefined") && val != "" && val != "N/A";
}
function timestampToTime(timestamp) {
    var oDate = new Date(Number(timestamp) * 1000), oYear = oDate.getFullYear(), oMonth = oDate.getMonth() + 1, oDay = oDate.getDate(), oHour = oDate.getHours(), oMin = oDate.getMinutes(), oSen = oDate.getSeconds();
    return oYear + '-' + supplementZero(oMonth) + '-' + supplementZero(oDay) + ' ' + supplementZero(oHour) + ':' + supplementZero(oMin) + ':' + supplementZero(oSen);
}
;
function supplementZero(num) {
    if (Number(num) < 10) {
        num = '0' + num;
    }
    return num;
}
function htmlTag(tag, attrs, contents) {
    if (contents === void 0) { contents = ""; }
    var closeTag = true;
    switch (tag) {
        case 'input':
        case 'img':
        case 'link':
        case 'meta':
            closeTag = false;
    }
    var attrStr = '';
    for (var attr in attrs) {
        attrStr += ' ' + attr + '="' + attrs[attr] + '"';
    }
    var html = "<" + tag + attrStr + ">";
    if (closeTag)
        return html + contents + "</" + tag + ">";
    return html;
}
function htmlDiv(attrs, contents) {
    return htmlTag("div", attrs, contents);
}
function genHelperHyperLink(pe) {
    return htmlDiv(pe.helperAttr ? pe.helperAttr : {}, htmlTag('a', { id: pe.memberName + "_helperHyperLink", "class": "hyperlink-text", href: pe.helperHyperLink }, _(pe.helperText)));
}
function helperText(pe) {
    if (pe.helperHyperLink)
        return genHelperHyperLink(pe);
    if ((typeof pe.helperText === "function"))
        return pe.helperText();
    if (pe.helperText)
        return htmlDiv(pe.helperAttr ? pe.helperAttr : {}, htmlTag('span', { id: pe.memberName + "_helperText", "class": "normal-text" }, _(pe.helperText)));
    return "";
}
function escapeHTML(text) {
    var map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    };
    var regex = /[&<>"']/g;
    var hasSpecialChars = regex.test(text);
    if (hasSpecialChars) {
        return text.replace(regex, function (m) {
            return map[m];
        });
    }
    else {
        return text;
    }
}
function setHtmlElementText(Name, v) {
    $("#" + Name).text(v);
}
function setHtmlElementVal(Name, v) {
    $("#" + Name).val(v);
}
function getHtmlElementVal(Name) {
    var value = $("#" + Name).val();
    return String(value);
}
function setVisible(div, v) {
    var b = toBool(v);
    if (div)
        $(div).css("display", b ? "" : "none");
    return b;
}
function setDivVisible(show, divName) {
    setVisible("#div_" + divName, show);
}
function setTblVisible(show, tblName) {
    setVisible("#table" + tblName, show);
}
function setEditButtonRowVisible(show) {
    setVisible("#buttonRow", show);
}
function setPageObjVisible(show, objName) {
    setVisible("#objouterwrapper" + objName, show);
}
function removeValidClass(field) {
    $("#" + field).removeClass("valid");
}
function setDivLabelStyle(divName, style) {
    $("#div_" + divName).children('label').attr('class', style);
}
function setHtmlText(htmlId, txt) {
    $("#" + htmlId).html(txt);
}
function setToggle(tName, v) {
    var name = "#" + tName;
    if (v == '1') {
        $(name + "_0").prop("checked", true);
        $(name + "_1").removeAttr('checked');
    }
    else {
        $(name + "_1").prop("checked", true);
        $(name + "_0").removeAttr('checked');
    }
    $(name).val(v);
}
function setVisibilityToggle(name, val) {
    setToggle(name, val);
    setVisible("#objwrapper" + name, val);
}
function genToggleHtml(toggleName, onClick, descriptiveText) {
    function halfSwitch(whch) {
        var inpAttrs = { type: "radio",
            name: toggleName + "_radio",
            id: toggleName + (whch ? "_0" : "_1"),
            "class": "access", value: (whch ? "1" : "0") };
        if (!onClick)
            onClick = "setToggle";
        inpAttrs.onClick = onClick + "('" + toggleName + "','" + (whch ? "1" : "0") + "');";
        return htmlTag('input', inpAttrs, "") +
            htmlTag('label', { "for": toggleName + (whch ? "_0" : "_1"), "class": (whch ? "on" : "off") }, whch ? _("on") : _("off"));
    }
    var radioSwitch = halfSwitch(true) + halfSwitch(false);
    var retHtml = htmlTag('input', { type: "hidden", id: toggleName }, "")
        + htmlDiv({ "class": "location-settings" }, htmlDiv({ "class": "radio-switch" }, radioSwitch));
    if (descriptiveText) {
        retHtml += htmlDiv({ "class": "descriptive-text" }, _(descriptiveText));
    }
    return retHtml;
}
function setEnable(htmlId, en) {
    $("#" + htmlId).prop("disabled", !en);
}
function setEditableIpv4AddressEnable(memName, en) {
    $("#" + memName + "1").prop("disabled", !en);
    $("#" + memName + "2").prop("disabled", !en);
    $("#" + memName + "3").prop("disabled", !en);
    $("#" + memName + "4").prop("disabled", !en);
}
function setEditableIpv4AddressAndMaskEnable(memName, en) {
    $("#" + memName + "1").prop("disabled", !en);
    $("#" + memName + "2").prop("disabled", !en);
    $("#" + memName + "3").prop("disabled", !en);
    $("#" + memName + "4").prop("disabled", !en);
    $("#" + memName + "5").prop("disabled", !en);
}
function setToggleEnable(togName, en) {
    setEnable(togName + "_0", en);
    setEnable(togName + "_1", en);
}
function genRadioButtonHtml(btnName, onClick) {
    var id = btnName + "_btn";
    return htmlDiv({ "class": "radio-box" }, htmlTag('input', { type: "radio", "class": "access", id: id, name: id, onClick: onClick + "('" + id + "');" }) +
        htmlTag('label', { "for": id }, "&nbsp;"));
}
function setRadioButtonEnable(btnName, en) {
    setEnable(btnName + "_btn", en);
}
function getRadioButtonVal(id) {
    var ids = "#" + id + "_btn";
    var attr = $(ids).prop('checked');
    if ((typeof attr !== "undefined") && attr !== false) {
        return true;
    }
    return false;
}
function setRadioButtonVal(id, val) {
    var ids = "#" + id + "_btn";
    $(ids).prop('checked', toBool(val));
}
function setupFocusoutEvent(mem, doPingTestFunction) {
    $("#inp_" + mem).focusout(doPingTestFunction);
}
function genCheckboxHtml(btnName, onClick, cbText, cbTextStyle) {
    var id = btnName + "_btn";
    var cbTextHtml = htmlTag('label', { "for": id, "class": cbTextStyle }, cbText);
    return htmlDiv({ "class": "checkbox", id: "div_" + id }, htmlTag('input', { type: "checkbox", "class": "checkbox-access", id: id, name: id, onClick: onClick + "('" + id + "');" }) +
        cbTextHtml);
}
function setCheckboxEnable(id, en) {
    setEnable(id + "_btn", en);
}
function getCheckboxVal(id) {
    var ids = "#" + id + "_btn";
    var attr = $(ids).prop('checked');
    return attr;
}
function setCheckboxVal(id, val) {
    var ids = "#" + id + "_btn";
    $(ids).prop('checked', toBool(val));
}
function setCheckboxText(id, txt) {
    $("#" + id + "_btn").siblings('label').text(txt);
}
function setCheckboxVisible(show, id) {
    setDivVisible(show, id + "_btn");
}
function setOption(name, options, v) {
    var select = document.getElementById("sel_" + name);
    if (select == null)
        return;
    if (select.options)
        while (select.options.length > 0)
            select.remove(0);
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        if (typeof opt == "string") {
            el.textContent = _(opt);
            el.value = opt;
        }
        else {
            el.textContent = _(opt[1]);
            el.value = String(opt[0]);
        }
        if (typeof v === "string" && el.value == v) {
            el.selected = true;
        }
        if (Array.isArray(v)) {
            for (var i_1 = 0; i_1 < v.length; i_1++) {
                if (v[i_1] == el.value) {
                    el.selected = true;
                    break;
                }
            }
        }
        select.appendChild(el);
    }
}
function genBodyHtml(alert) {
    var menu = htmlDiv({ "class": "header-wrap", id: "main-menu" }, "");
    if (pageData.multiColumn) {
        var body = htmlTag("form", { "class": "validate", name: "form", id: "form", novalidate: "novalidate", onsubmit: "return false" }, "") +
            htmlDiv({ "class": "site-content", id: "content" }, htmlDiv({ "class": "container dashboard" }, htmlDiv({ "class": "grid-9 alpha", id: "htmlGoesHere" }, "") +
                htmlDiv({ "class": "grid-3 omega", id: "rightGoesHere" }, "")));
    }
    else {
        var titleCssClass = "title-box";
        var bodyCssClass = "body-box";
        var titleDiv = "";
        if (pageData.noTitleBox !== true) {
            if ((typeof pageData.style !== "undefined") && (typeof pageData.style.titleCssClass !== "undefined")) {
                titleCssClass = pageData.style.titleCssClass;
            }
            titleDiv = htmlDiv({ "class": titleCssClass }, htmlDiv({ "class": "pad", id: "titleGoesHere" }, ""));
        }
        if ((typeof pageData.style !== "undefined") && (typeof pageData.style.bodyCssClass !== "undefined")) {
            bodyCssClass = pageData.style.bodyCssClass;
        }
        var body = htmlDiv({ id: "content", "class": "site-content" }, htmlDiv({ "class": "container" }, htmlTag("aside", { "class": "grid-3 alpha sidemenu", id: "side-menu" }, "") +
            htmlDiv({ "class": "grid-9 omega" }, alert +
                htmlTag("form", { "class": "validate", name: "form", id: "form", novalidate: "novalidate", onsubmit: "return false" }, titleDiv +
                    htmlDiv({ "class": bodyCssClass }, htmlDiv({ "class": "pad", id: "htmlGoesHere" }, ""))))));
    }
    var footer = genThemeFooter(pageData);
    return menu + body + footer;
}
function genButtons(buttons, memberName) {
    if (memberName === void 0) { memberName = ""; }
    function genButton(id, labelText) {
        var attrs = { type: "button", id: id };
        return htmlTag("button", attrs, _(labelText));
    }
    var html = "";
    for (var key in buttons) {
        html += genButton(key + "Button", buttons[key]);
    }
    var attribs = { id: memberName + "buttonRow" };
    attribs["class"] = "submit-row form-row";
    if (buttons.length == 0) {
        return "";
    }
    else if (buttons.length > 1) {
        attribs["class"] += " multi-button";
    }
    return htmlDiv(attribs, html);
}
function setButtonEvent(btn, event, fn) {
    $("#" + btn + "Button").on(event, fn);
}
function appendButtons(buttons) {
    $("#htmlGoesHere").append(genButtons(buttons));
}
function addUpdateField(dst) {
    var div = document.getElementById('div_' + dst);
    if (div) {
        div.innerHTML += htmlDiv({ style: "inline" }, "&nbsp;" +
            htmlTag("i", { style: "display:none", id: dst + "_wait", "class": "progress-sml" }, "") +
            htmlTag("label", { id: dst + "_stat", style: "width:40px" }, ""));
    }
}
function disablePageIfPppoeEnabled() {
    if ((typeof service_pppoe_server_0_enable !== "undefined") && service_pppoe_server_0_enable == '1') {
        if ((typeof service_pppoe_server_0_wanipforward_enable !== "undefined") && service_pppoe_server_0_wanipforward_enable == '1') {
            pageData.disabled = true;
            pageData.alertHeading = "pppoeEnabled";
            pageData.alertText = "functionNotAvailable";
        }
    }
}
function genWarningBlock() {
    return htmlTag('h2', {}, "warning line 1") +
        htmlTag('p', {}, "warning line 2");
}
function setLogoffVisible(show) {
    setVisible("#logOff", show);
}
function genLogDownloadClear() {
    function genButton(id, labelText) {
        var attrs = { "class": "secondary " + id, type: "button", id: id };
        return htmlTag("button", attrs, _(labelText));
    }
    var html = "<a href='' id='fileDownload' download='logmsg.txt'>";
    html += genButton("downloadButton", "download") + "</a>";
    html += genButton("clearButton", "clear");
    var attribs = { id: "buttonRow" };
    attribs["class"] = "submit-row";
    attribs["class"] += " multi-button";
    return htmlDiv(attribs, html);
}
function appendLogDownloadClearButton() {
    $("#objouterwrapperlogfile").append(genLogDownloadClear());
}
function genSelUnselAllReset(selBtn, unselBtn, resetBtn) {
    function genButton(id, labelText) {
        var btnClass = "secondary auto-button";
        var attrs = { "class": btnClass, type: "button", id: id };
        return htmlTag("button", attrs, _(labelText));
    }
    var html = genButton(selBtn + "Button", "Select all") +
        genButton(unselBtn + "Button", "Unselect all") +
        genButton(resetBtn + "Button", "Reset all");
    var attribs = { id: "buttonRow" };
    attribs["class"] = "submit-row multi-button bottom-padding-60";
    return htmlDiv(attribs, html);
}
function genUploadButton(id, labelText, accept, onchange) {
    var attrs = { type: "file", id: id, accept: accept, onchange: onchange };
    return htmlTag("span", { "class": "file-wrapper" }, htmlTag("input", attrs, "") +
        htmlTag("span", { "class": "secondary button keyfileUpload" }, _(labelText)));
}
function genHostKeyManagement(generateKeys, getKeys, getPublicKeys, uploadKeys) {
    function genButton(id, labelText) {
        var btnClass = "secondary auto-button";
        var attrs = { "class": btnClass, type: "button", id: id, style: "margin: 0 0 0 10px" };
        return htmlTag("button", attrs, _(labelText));
    }
    var html = genButton(generateKeys + "Button", "Generate keys");
    html += genButton(getKeys + "Button", "Get keys");
    html += genButton(getPublicKeys + "Button", "Get public keys");
    html += genUploadButton("inp_" + uploadKeys, "Upload keys", ".zip", "uploadHostKeys()");
    var attribs = { id: "buttonRow", margin: "0 0 0 100px" };
    attribs["class"] = "submit-row multi-button-hostkey bottom-padding-60";
    return htmlDiv(attribs, html);
}
function appendHostKeyButton(generateKeys, getKeys, getPublicKeys, uploadKeys, objname) {
    $("#objwrapper" + objname).append(genHostKeyManagement(generateKeys, getKeys, getPublicKeys, uploadKeys));
}
function genClientKeyManagement(clear, upload) {
    function genButton(id, labelText) {
        var btnClass = "secondary auto-button";
        var attrs = { "class": btnClass, type: "button", id: id };
        return htmlTag("button", attrs, _(labelText));
    }
    var html = genButton(clear + "Button", "Clear") +
        genUploadButton("inp_" + upload, "Upload", ".pub", "uploadClientKeys()");
    var attribs = { id: "buttonRow" };
    attribs["class"] = "submit-row";
    return htmlDiv(attribs, html);
}
function appendClientKeyButton(clear, upload, objname) {
    $("#objwrapper" + objname).append(genClientKeyManagement(clear, upload));
}
function genDownloadButton(targetName, id_btn2) {
    function genButton(id, labelText) {
        var attrs = { "class": "secondary " + id, type: "button", id: id };
        return htmlTag("button", attrs, _(labelText));
    }
    var html = "<a href='' id='fileDownload' download='" + targetName + "'>";
    html += genButton("downloadButton", "Download") + "</a>";
    html += genButton(id_btn2 + "Button", id_btn2);
    var attribs = { id: "buttonRow" };
    attribs["class"] = "submit-row";
    attribs["class"] += " multi-button";
    return htmlDiv(attribs, html);
}
function appendGenSubmitButtons(targetName, id_btn2, objname) {
    $("#objwrapper" + objname).append(genDownloadButton(targetName, id_btn2));
}
function downloadButton(targetName, labelText) {
    function genButton(id, labelText) {
        var attrs = { "class": "secondary " + id, type: "button", id: id };
        return htmlTag("button", attrs, _(labelText));
    }
    var html = "<a href='' id='fileDownload' download='" + targetName + "'>";
    html += genButton("downloadButton", labelText) + "</a><br><br>";
    var attribs = { id: "buttonRow" };
    attribs["class"] = "submit-row";
    attribs["class"] += " multi-button";
    return htmlDiv(attribs, html);
}
function appendDownloadButtons(targetName, objname, labelText) {
    $("#objwrapper" + objname).append(downloadButton(targetName, labelText));
}
function hidePageForm() {
    $("#form").hide();
}
function add_band_list(bandName, target, source) {
    if (source.length > 0) {
        if (target.length > 0) {
            target += "<br>";
        }
        target += bandName + " " + _("Band(s)") + " <br>";
        source = source.sort(function (a, b) { return a - b; });
        var line = "";
        for (var i = 0; i < source.length; i++) {
            if (i > 0) {
                if (line.length > 28) {
                    target += (line + "<br>");
                    line = "";
                }
                line += ", ";
            }
            if (line.length + source[i].length > 28) {
                target += (line + "<br>");
                line = "";
            }
            line += source[i];
        }
        if (line.length > 0) {
            target += line;
        }
        target += "<br>";
    }
    return target;
}
function mergeObject(mainObj, extraObj) {
    var obj = mainObj;
    for (var key in extraObj) {
        if (extraObj.hasOwnProperty(key)) {
            obj[key] = extraObj[key];
        }
    }
    return obj;
}
var validaters = {};
function validateField(field) {
    var field0 = field[0];
    var name = field0.name;
    if (name != "") {
        var pe = validaters[name];
        if ((typeof pe !== "undefined") && (typeof pe.fnValidateField !== "undefined")) {
            for (var i = 0; i < pe.fnValidateField.length; i++) {
                if (pe.fnValidateField[i](field0.value) === false) {
                    return pe.errMsg[i];
                }
            }
        }
    }
}
function validateKey(field) {
    var name = field.name;
    if (name != "") {
        var member = validaters[name];
        if ((typeof member !== "undefined") && (typeof member.fnValidateKey === "function")) {
            member.fnValidateKey(field);
        }
    }
}
var PageElement = (function () {
    function PageElement(name, extras) {
        var _this_1 = this;
        this.attr = {};
        this.validateLua = [];
        this.conditionsForCheck = [];
        this.setVisible = function (show) { return setDivVisible(show, _this_1.memberName); };
        this.memberName = name;
        mergeObject(this, extras);
    }
    PageElement.prototype.setReadOnly = function (ro) {
        this.readOnly = ro;
        return this;
    };
    ;
    PageElement.prototype.addStyle = function (style) {
        this.style += style;
        return this;
    };
    ;
    ;
    PageElement.prototype.setEncode = function (encode) {
        this.encode = encode;
        return this;
    };
    ;
    PageElement.prototype.setLabel = function (label) {
        this.labelText = label;
        return this;
    };
    ;
    PageElement.prototype.getHtmlId = function () {
        return this.htmlId ? this.htmlId : this.memberName;
    };
    PageElement.prototype.setHtml = function (val) {
        $("#" + this.getHtmlId()).html(val);
    };
    PageElement.prototype.setAttr = function (attrName, val) {
        $("#" + this.getHtmlId()).attr(attrName, val);
    };
    PageElement.prototype.delAttr = function (attrName) {
        $("#" + this.getHtmlId()).removeAttr(attrName);
    };
    PageElement.prototype.setIsVisible = function (fnIsVisible) {
        this.fnIsVisible = fnIsVisible;
        return this;
    };
    PageElement.prototype.setRequired = function (req) {
        this.required = req;
        return this;
    };
    ;
    PageElement.prototype.getThis = function () {
        return this;
    };
    PageElement.prototype.setValidate = function (fnValidateField, errMsg, fnValidateKey, luaValidateFn) {
        if ((typeof fnValidateKey !== "undefined")) {
            this.fnValidateKey = fnValidateKey;
        }
        if ((typeof luaValidateFn !== "undefined")) {
            this.validateLua.push(luaValidateFn);
        }
        this.attr.onKeyUp = "validateKey(this);";
        var id = "inp_" + this.memberName;
        if ((typeof fnValidateField !== "undefined") && (typeof errMsg !== "undefined")) {
            if (!(typeof this.fnValidateField !== "undefined")) {
                this.fnValidateField = [];
                this.errMsg = [];
            }
            this.fnValidateField.push(fnValidateField);
            this.errMsg.push(_(errMsg));
            this.validate = "validate[" + (this.required === false ? "" : "required,") + "funcCall[validateField]]";
        }
        validaters[id] = this;
        return this;
    };
    PageElement.prototype.setAuthenticatedOnly = function () {
        this.authenticatedOnly = true;
        return this;
    };
    PageElement.prototype.setVal = function (obj, val) { };
    ;
    return PageElement;
}());
var NoticeTextConst = (function (_super) {
    __extends(NoticeTextConst, _super);
    function NoticeTextConst(name, text, extras) {
        var _this_1 = _super.call(this, name, extras) || this;
        _this_1.readOnly = true;
        _this_1.unwrapped = true;
        _this_1.cssClass = "notice-text";
        _this_1.style = "";
        _this_1.setVisible = function (show) { return setVisible("#" + _this_1.getHtmlId(), show); };
        _this_1.text = _(text);
        if (extras && "style" in extras) {
            _this_1.style += extras.style;
        }
        return _this_1;
    }
    NoticeTextConst.prototype.getVal = function () { return this.text; };
    NoticeTextConst.prototype.genHtml = function () {
        return htmlTag('div', { id: this.getHtmlId(), 'class': this.cssClass, style: this.style }, this.text);
    };
    return NoticeTextConst;
}(PageElement));
function noticeText(name, text) {
    return new NoticeTextConst(name, text);
}
var HiddenVariable = (function (_super) {
    __extends(HiddenVariable, _super);
    function HiddenVariable(name, rdbName, volatile, extras) {
        var _this_1 = _super.call(this, name, extras) || this;
        _this_1.hidden = true;
        if (rdbName) {
            _this_1.getThis();
        }
        return _this_1;
    }
    ;
    return HiddenVariable;
}(PageElement));
function hiddenVariable(memberName, rdbName, volatile) {
    if (volatile === void 0) { volatile = false; }
    return new HiddenVariable(memberName, rdbName, volatile);
}
var ShownVariable = (function (_super) {
    __extends(ShownVariable, _super);
    function ShownVariable(name, labelText, extras) {
        var _this_1 = _super.call(this, name, extras) || this;
        _this_1.setLabel(labelText);
        return _this_1;
    }
    ShownVariable.prototype.setVal = function (obj, val) { $("#" + this.getHtmlId()).val(val); };
    ShownVariable.prototype.getVal = function () { return String($("#" + this.getHtmlId()).val()); };
    ShownVariable.prototype.genLink = function () {
        return htmlTag("a", { id: "link_" + this.getHtmlId() }, "");
    };
    return ShownVariable;
}(PageElement));
function shownVariable(memberName, labelText, extras) {
    var pe = new ShownVariable(memberName, labelText, extras);
    return pe;
}
var StaticTextVariable = (function (_super) {
    __extends(StaticTextVariable, _super);
    function StaticTextVariable(name, labelText, extras) {
        var _this_1 = _super.call(this, name, labelText, extras) || this;
        _this_1.style = "margin:6px 0 0 3px;";
        return _this_1;
    }
    StaticTextVariable.prototype.getVal = function () { return $("#" + this.getHtmlId()).html(); };
    StaticTextVariable.prototype.setVal = function (obj, val) { $("#" + this.getHtmlId()).html(_(val)); };
    StaticTextVariable.prototype.genHtml = function () {
        return htmlTag('span', { id: this.getHtmlId() }, "");
    };
    ;
    return StaticTextVariable;
}(ShownVariable));
function staticTextVariable(name, label, extras) {
    return new StaticTextVariable(name, label, extras);
}
var StaticTextVariableWait = (function (_super) {
    __extends(StaticTextVariableWait, _super);
    function StaticTextVariableWait() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    StaticTextVariableWait.prototype.showWaiting = function (waiting) {
        if (waiting) {
            $("#spinner").show();
        }
        else {
            $("#spinner").hide();
        }
    };
    StaticTextVariableWait.prototype.genHtml = function () {
        var html = _super.prototype.genHtml.call(this);
        html += htmlTag('span', { id: 'spinner' }, '<img src="/img/spinner_250.gif" class="waitIcon">');
        return html;
    };
    ;
    return StaticTextVariableWait;
}(StaticTextVariable));
function staticTextVariableWait(name, label) {
    return new StaticTextVariableWait(name, label);
}
var StaticTextArea = (function (_super) {
    __extends(StaticTextArea, _super);
    function StaticTextArea() {
        var _this_1 = _super !== null && _super.apply(this, arguments) || this;
        _this_1.style = "margin:6px 0 0 3px;";
        return _this_1;
    }
    StaticTextArea.prototype.getVal = function () { return $("#" + this.getHtmlId()).html(); };
    StaticTextArea.prototype.setVal = function (obj, val) { this.setHtml(_(val)); };
    StaticTextArea.prototype.genHtml = function () {
        return htmlTag('textarea', { id: this.getHtmlId(), "class": "customTextArea" }, "");
    };
    ;
    return StaticTextArea;
}(ShownVariable));
function staticTextArea(name, label) {
    return new StaticTextArea(name, label);
}
var ConstTextArea = (function (_super) {
    __extends(ConstTextArea, _super);
    function ConstTextArea() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ConstTextArea.prototype.genHtml = function () {
        return htmlTag('textarea', { id: this.getHtmlId(), rows: this.rows, cols: this.cols, readonly: true });
    };
    return ConstTextArea;
}(ShownVariable));
function constTextArea(name, label, extras) {
    return new ConstTextArea(name, label, extras);
}
var StaticI18NVariable = (function (_super) {
    __extends(StaticI18NVariable, _super);
    function StaticI18NVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    StaticI18NVariable.prototype.setVal = function (obj, val) {
        _super.prototype.setVal.call(this, obj, _(val));
    };
    return StaticI18NVariable;
}(StaticTextVariable));
function staticI18NVariable(name, label) {
    return new StaticI18NVariable(name, label);
}
var StaticTextConst = (function (_super) {
    __extends(StaticTextConst, _super);
    function StaticTextConst(name, labelText, text, extras) {
        var _this_1 = _super.call(this, name, labelText, extras) || this;
        _this_1.readOnly = true;
        _this_1.style = "margin:6px 0 0 3px;";
        _this_1.text = text;
        return _this_1;
    }
    StaticTextConst.prototype.getVal = function () { return this.text; };
    StaticTextConst.prototype.genHtml = function () {
        return htmlTag('span', { id: this.getHtmlId() }, this.text);
    };
    return StaticTextConst;
}(ShownVariable));
function staticText(name, label, text) {
    return new StaticTextConst(name, label, text);
}
var EditableTextVariable = (function (_super) {
    __extends(EditableTextVariable, _super);
    function EditableTextVariable(memberName, labelText, extras) {
        var _this_1 = _super.call(this, memberName) || this;
        _this_1.isClearText = true;
        _this_1.setLabel(labelText);
        mergeObject(_this_1, extras);
        if (!(typeof _this_1.required !== "undefined") || _this_1.required !== false) {
            _this_1.validate = "validate[required]";
        }
        else {
            _this_1.validate = "";
        }
        return _this_1;
    }
    EditableTextVariable.prototype.setClearText = function (type) {
        this.isClearText = type;
        return this;
    };
    EditableTextVariable.prototype.setMaxLength = function (len) {
        this.maxlength = len;
        this.validateLua.push("(#v<=" + len + ")");
        return this;
    };
    EditableTextVariable.prototype.setMinLength = function (len) {
        this.minlength = len;
        this.validateLua.push("(#v>=" + len + ")");
        return this;
    };
    EditableTextVariable.prototype.setInputSizeCssName = function (size) {
        this.inputSizeCssName = size;
        return this;
    };
    EditableTextVariable.prototype.getVal = function () {
        return String($("#" + this.getHtmlId()).val());
    };
    EditableTextVariable.prototype.setVal = function (obj, val) {
        $("#" + this.getHtmlId()).val(val);
        if (this.mirrorHtmlId)
            $("#" + this.mirrorHtmlId).val(val);
    };
    EditableTextVariable.prototype.genHtml = function () {
        var id = this.getHtmlId();
        this.labelFor = id;
        var attr = mergeObject(this.attr, { name: id, id: id, type: this.isClearText ? "text" : "password" });
        if ((typeof this.maxlength !== "undefined"))
            attr.maxlength = this.maxlength;
        var inputSizeCssName = " large";
        if ((typeof this.inputSizeCssName !== "undefined")) {
            inputSizeCssName = " " + this.inputSizeCssName;
        }
        attr["class"] = this.validate + inputSizeCssName;
        if (this["class"]) {
            attr["class"] += ' ' + this["class"];
        }
        var descriptiveText = "";
        if (this.descriptiveText) {
            descriptiveText = htmlDiv({ "class": "descriptive-text" }, _(this.descriptiveText));
        }
        return htmlTag('input', attr) + descriptiveText;
    };
    return EditableTextVariable;
}(PageElement));
function editableTextVariable(memberName, labelText, extras) {
    var pe = new EditableTextVariable(memberName, labelText, extras);
    pe.setEnable = function (en) { setEnable(pe.getHtmlId(), en); };
    return pe;
}
var EnabledTextVariable = (function (_super) {
    __extends(EnabledTextVariable, _super);
    function EnabledTextVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EnabledTextVariable.prototype.setVal = function (obj, val) { this.setHtml(toBool(val) ? "enabled" : "disabled"); };
    return EnabledTextVariable;
}(StaticTextVariable));
function enabledTextVariable(memberName, labelText, extras) {
    return new EnabledTextVariable(memberName, labelText, extras);
}
var OnOffTextVariable = (function (_super) {
    __extends(OnOffTextVariable, _super);
    function OnOffTextVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    OnOffTextVariable.prototype.setVal = function (obj, val) { this.setHtml(toBool(val) ? "On" : "Off"); };
    return OnOffTextVariable;
}(StaticTextVariable));
function onOffTextVariable(memberName, labelText, extras) {
    return new OnOffTextVariable(memberName, labelText, extras);
}
var EditablePasswordVariable = (function (_super) {
    __extends(EditablePasswordVariable, _super);
    function EditablePasswordVariable(memberName, labelText, extras) {
        var _this_1 = _super.call(this, memberName, labelText, extras) || this;
        _this_1.setVerify = function (verifyLabelText) {
            this.genMultiRow = function (labelAndField) {
                var _this_1 = this;
                function addVerification(html, matchName) {
                    return html.replace("[required]", "[required,equals[inp_" + matchName + "]]");
                }
                var html = labelAndField(this, this.genHtml());
                var orgId = this.htmlId;
                var orgLabel = this.labelText;
                var orgName = this.memberName;
                this.memberName += "_verify";
                this.htmlId += "_verify";
                this.setVisible = function (show) { setDivVisible(show, _this_1.memberName); setDivVisible(show, _this_1.memberName + "_verify"); };
                this.labelText = verifyLabelText;
                this.mirrorHtmlId = this.htmlId;
                html += labelAndField(this, addVerification(this.genHtml(), orgName));
                this.memberName = orgName;
                this.labelText = orgLabel;
                this.htmlId = orgId;
                if (this["class"]) {
                    this.attr["class"] += ' ' + this["class"];
                }
                return html;
            };
            return this;
        };
        _this_1.isClearText = false;
        _this_1.encode = true;
        return _this_1;
    }
    EditablePasswordVariable.prototype.genHtml = function () {
        var html = _super.prototype.genHtml.call(this);
        var onclick = "      if ($('#" + this.getHtmlId() + "').attr('type') == 'password') {        $('#" + this.getHtmlId() + "').attr('type', 'text');      } else {        $('#" + this.getHtmlId() + "').attr('type', 'password');      }    ";
        html += htmlTag("span", { "class": "reveal-icon" }, htmlTag("img", { "src": "/img/reveal.png", "alt": _("Toggle unmasking"), "onclick": "javascript:" + onclick }));
        return html;
    };
    return EditablePasswordVariable;
}(EditableTextVariable));
function editablePasswordVariable(memberName, labelText, extras) {
    var pe = new EditablePasswordVariable(memberName, labelText, extras);
    pe.setEnable = function (en) { setEnable(pe.getHtmlId(), en); };
    return pe;
}
function updateStrength(PassStr, field) {
    if (field) {
        var strength = getPassStrength(PassStr);
        updatePassStrengthField(field, strength);
    }
}
function checkPassStrength(th, memberName) {
    updateStrength(th.value, document.getElementById(memberName));
}
var PASSWD_MAXLEN = 64;
var EditableStrongPasswordVariable = (function (_super) {
    __extends(EditableStrongPasswordVariable, _super);
    function EditableStrongPasswordVariable(memberName, labelText, extras) {
        var _this_1 = _super.call(this, memberName, labelText, extras) || this;
        _this_1.passStrength = memberName + "PassStrength";
        _this_1.attr = { onkeyup: "checkPassStrength(this, '" + _this_1.passStrength + "')" };
        return _this_1;
    }
    EditableStrongPasswordVariable.prototype.genHtml = function () {
        var id = this.getHtmlId();
        var html = _super.prototype.genHtml.call(this);
        var passStrengthEls = htmlTag('a', {
            href: 'javascript:showStrongPasswordInfo();',
            id: "passwordInfo",
            style: 'background-color:transparent;'
        }, htmlTag('i', { id: "net-info", style: "margin:5px; padding:5px 30px 12px 0" }, ""));
        var html_icon = htmlDiv({ "class": "password-strength-info", "style": "display:inline-block;" }, passStrengthEls);
        var html_input_reveal = htmlDiv({ "class": "password-input-reveal", "style": "display:inline-block;" }, html);
        var html_strengthtext = htmlTag("div", {}, htmlTag("span", { "class": "normal-text", "id": this.passStrength, "style": "width:150px; left:13%; display:block;" }, ""));
        var html_all = html_icon + html_input_reveal + html_strengthtext;
        return html_all;
    };
    EditableStrongPasswordVariable.prototype.setVal = function (obj, val) {
        _super.prototype.setVal.call(this, obj, val);
        if ((typeof val !== "undefined")) {
            updateStrength(val, document.getElementById(this.passStrength));
        }
    };
    return EditableStrongPasswordVariable;
}(EditablePasswordVariable));
function editableStrongPasswordVariable(memberName, labelText) {
    var pe = new EditableStrongPasswordVariable(memberName, labelText, {});
    var bulletHead = convert_to_html_entity("  • ");
    pe.setValidate(function (val) {
        return getPassStrength(val) == 'strong';
    }, [
        _("passwordWarning6"),
        bulletHead + _("passwordWarning2"),
        bulletHead + _("passwordWarning3"),
        bulletHead + _("passwordWarning4") + convert_to_html_entity('`~!@#$%^&*()-_=+[{]}\|;:\'\",\<.>/?.'),
        bulletHead + _("passwordWarning5")
    ].join("<br>"));
    pe.style = "position:relative; left: -40px;";
    pe.labelStyle = "position:relative; left: -30px;";
    return pe;
}
function editablePasswordConfirmVariablePair(memberName1, labelText1, memberName2, labelText2, buttonToDisable, strong) {
    var passwordElement, passwordConfirmElement;
    passwordElement = strong ? editableStrongPasswordVariable(memberName1, labelText1) :
        editablePasswordVariable(memberName1, labelText1);
    passwordElement.setRequired(true);
    passwordConfirmElement = editablePasswordVariable(memberName2, labelText2).setRequired(true)
        .setValidate(function (val) { return val === String($("#inp_" + memberName1).val()); }, "The password and confirm password do not match.");
    if ((typeof buttonToDisable !== "undefined")) {
        var onKeyUpCheckPwMatch = "setEnable('" + buttonToDisable +
            "', String($('#inp_" + memberName1 + "').val()) == String($('#inp_" + memberName2 + "').val())" +
            " && (getPassStrength(String($('#inp_" + memberName1 + "').val())) == 'strong')" +
            ");";
        if (strong) {
            passwordElement.attr.onkeyup = passwordElement.attr.onkeyup + "; " + onKeyUpCheckPwMatch;
        }
        else {
            passwordElement.attr = { onkeyup: onKeyUpCheckPwMatch };
        }
        passwordConfirmElement.attr = { onkeyup: onKeyUpCheckPwMatch };
    }
    return { password: passwordElement, passwordConfirm: passwordConfirmElement };
}
function editablePinConfirmVariablePair(memberName1, labelText1, memberName2, labelText2, buttonToDisable) {
    var passwordElement, passwordConfirmElement;
    passwordElement = editablePasswordVariable(memberName1, labelText1);
    passwordElement.setRequired(true);
    passwordConfirmElement = editablePasswordVariable(memberName2, labelText2).setRequired(true)
        .setValidate(function (val) { return val === String($("#inp_" + memberName1).val()); }, "The password and confirm password do not match.");
    if ((typeof buttonToDisable !== "undefined")) {
        var onKeyUpCheckPwMatch = "setEnable('" + buttonToDisable +
            "', String($('#inp_" + memberName1 + "').val()) == String($('#inp_" + memberName2 + "').val())" +
            ");";
        passwordElement.attr = { onkeyup: onKeyUpCheckPwMatch };
        passwordConfirmElement.attr = { onkeyup: onKeyUpCheckPwMatch };
    }
    return { password: passwordElement, passwordConfirm: passwordConfirmElement };
}
var EditableLandingPasswordVariable = (function (_super) {
    __extends(EditableLandingPasswordVariable, _super);
    function EditableLandingPasswordVariable(memberName, labelText, extras) {
        return _super.call(this, memberName, labelText, extras) || this;
    }
    EditableLandingPasswordVariable.prototype.genHtml = function () {
        var html = _super.prototype.genHtml.call(this);
        var html_confirmPass = htmlDiv({ "class": "confirm-password-input-reveal" }, html);
        return html_confirmPass;
    };
    return EditableLandingPasswordVariable;
}(EditablePasswordVariable));
function editableLandingPasswordVariable(memberName, labelText, extras) {
    var pe = new EditableLandingPasswordVariable(memberName, labelText, extras);
    pe.setEnable = function (en) { setEnable(pe.getHtmlId(), en); };
    return pe;
}
var EditableLandingStrongPasswordVariable = (function (_super) {
    __extends(EditableLandingStrongPasswordVariable, _super);
    function EditableLandingStrongPasswordVariable(memberName, labelText, extras) {
        var _this_1 = _super.call(this, memberName, labelText, extras) || this;
        _this_1.passStrength = memberName + "PassStrength";
        _this_1.attr = { onkeyup: "checkPassStrength(this, '" + _this_1.passStrength + "')" };
        return _this_1;
    }
    EditableLandingStrongPasswordVariable.prototype.genHtml = function () {
        var id = this.getHtmlId();
        var html = _super.prototype.genHtml.call(this);
        var passStrengthEls = htmlTag('a', {
            href: 'javascript:showStrongPasswordInfo();',
            id: "passwordInfo",
            style: 'background-color:transparent;'
        }, htmlTag('i', { id: "net-info", style: "margin:5px; padding:5px 30px 12px 0" }, ""));
        var html_icon = htmlDiv({ "class": "password-strength-info", "style": "display:inline-block;" }, passStrengthEls);
        var html_input_reveal = htmlDiv({ "class": "password-input-reveal", "style": "display:inline-block;" }, html);
        var html_tickbox = htmlTag('input', { type: "checkbox", id: id + "_btn", "class": "checkbox-access", name: id + "_btn", onClick: this.onClick + "('" + id + "');" });
        var html_tickboxtext = htmlTag('label', { "for": id + "_btn", style: "width:190px; font-weight:bold;" }, "Same as the root password");
        var html_checkbox = htmlDiv({ "class": "password-checkbox", style: "display:inline-block; height:20px;" }, html_tickbox + html_tickboxtext);
        var html_strengthtext = htmlTag("div", {}, htmlTag("span", { "class": "normal-text", "id": this.passStrength, "style": "width:150px; left:8%" }, ""));
        var html_all = html_icon + html_input_reveal + html_checkbox + html_strengthtext;
        return html_all;
    };
    EditableLandingStrongPasswordVariable.prototype.setVal = function (obj, val) {
        _super.prototype.setVal.call(this, obj, val);
        if ((typeof val !== "undefined")) {
            updateStrength(val, document.getElementById(this.passStrength));
        }
    };
    return EditableLandingStrongPasswordVariable;
}(EditablePasswordVariable));
function editableLandingStrongPasswordVariable(memberName, labelText, onClick) {
    var pe = new EditableLandingStrongPasswordVariable(memberName, labelText, {
        setEnable: function (en) { setCheckboxEnable(this.getHtmlId(), en); }
    });
    var bulletHead = convert_to_html_entity("  • ");
    pe.onClick = onClick;
    pe.setValidate(function (val) {
        return getPassStrength(val) == 'strong';
    }, [
        _("passwordWarning6"),
        bulletHead + _("passwordWarning2"),
        bulletHead + _("passwordWarning3"),
        bulletHead + _("passwordWarning4") + convert_to_html_entity('`~!@#$%^&*()-_=+[{]}\|;:\'\",\<.>/?.'),
        bulletHead + _("passwordWarning5")
    ].join("<br>"));
    return pe;
}
function editableLandingPasswordConfirmVariablePair(memberName1, labelText1, onClick, memberName2, labelText2, buttonToDisable, strong) {
    var passwordElement, passwordConfirmElement;
    passwordElement = strong ? editableLandingStrongPasswordVariable(memberName1, labelText1, onClick) :
        editableLandingPasswordVariable(memberName1, labelText1);
    passwordElement.setRequired(true);
    passwordConfirmElement = editableLandingPasswordVariable(memberName2, labelText2).setRequired(true)
        .setValidate(function (val) { return val === String($("#inp_" + memberName1).val()); }, "The password and confirm password do not match.");
    if ((typeof buttonToDisable !== "undefined")) {
        var onKeyUpCheckPwMatch = "setEnable('" + buttonToDisable +
            "', String($('#inp_" + memberName1 + "').val()) == String($('#inp_" + memberName2 + "').val())" +
            " && (getPassStrength(String($('#inp_" + memberName1 + "').val())) == 'strong')" +
            ");";
        if (strong) {
            passwordElement.attr.onkeyup = passwordElement.attr.onkeyup + "; " + onKeyUpCheckPwMatch;
        }
        else {
            passwordElement.attr = { onkeyup: onKeyUpCheckPwMatch };
        }
        passwordConfirmElement.attr = { onkeyup: onKeyUpCheckPwMatch };
    }
    return { password: passwordElement, passwordConfirm: passwordConfirmElement };
}
var EditableIpAddressVariable = (function (_super) {
    __extends(EditableIpAddressVariable, _super);
    function EditableIpAddressVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EditableIpAddressVariable.prototype.setVal = function (obj, val) { parse_ip_into_fields(val, this.memberName); };
    EditableIpAddressVariable.prototype.getVal = function () { return parse_ip_from_fields(this.memberName); };
    EditableIpAddressVariable.prototype.genHtml = function () {
        var fnGenIPBlocks = this.fnGenIPBlocks;
        if (!(typeof fnGenIPBlocks !== "undefined"))
            fnGenIPBlocks = this.required === false ? genHtmlIpBlocksWithoutRequired : genHtmlIpBlocks;
        return fnGenIPBlocks(this.memberName);
    };
    return EditableIpAddressVariable;
}(ShownVariable));
function editableIpAddressVariable(memberName, labelText, _fnGenIPBlocks, extras) {
    var pe = new EditableIpAddressVariable(memberName, labelText, extras);
    pe.setEnable = function (en) { setEditableIpv4AddressEnable(this.memberName, en); };
    pe.fnGenIPBlocks = _fnGenIPBlocks;
    pe.validateLua.push("isValid.IpAddress(v)");
    return pe;
}
var EditableIpAddressAndMaskVariable = (function (_super) {
    __extends(EditableIpAddressAndMaskVariable, _super);
    function EditableIpAddressAndMaskVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EditableIpAddressAndMaskVariable.prototype.setVal = function (obj, val) { parse_ip_mask_into_fields(val, this.memberName); };
    EditableIpAddressAndMaskVariable.prototype.getVal = function () { return parse_ip_mask_from_fields(this.memberName); };
    EditableIpAddressAndMaskVariable.prototype.genHtml = function () {
        return genHtmlIpAndMaskBlocks(this.memberName);
    };
    return EditableIpAddressAndMaskVariable;
}(ShownVariable));
function editableIpAddressAndMaskVariable(memberName, labelText) {
    var pe = new EditableIpAddressAndMaskVariable(memberName, labelText, {
        setEnable: function (en) { setEditableIpv4AddressAndMaskEnable(this.memberName, en); }
    });
    pe.validateLua.push("isValid.IpAddressAndMask(v)");
    return pe;
}
var EditableVlanIpAddressVariable = (function (_super) {
    __extends(EditableVlanIpAddressVariable, _super);
    function EditableVlanIpAddressVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return EditableVlanIpAddressVariable;
}(EditableIpAddressVariable));
function editableVlanIpAddressVariable(memberName, labelText, _fnGenIPBlocks) {
    var pe = new EditableVlanIpAddressVariable(memberName, labelText);
    pe.fnGenIPBlocks = _fnGenIPBlocks;
    pe.isVlanIp = true;
    pe.validateLua.push("isValid.VlanIpAddress(v_ip)");
    return pe;
}
function editableVlanRangeVariable(memberName, labelText, _fnGenIPBlocks) {
    var pe = new EditableIpAddressVariable(memberName, labelText, {
        setEnable: function (en) { setEditableIpv4AddressEnable(this.memberName, en); }
    });
    pe.fnGenIPBlocks = _fnGenIPBlocks;
    pe.validateLua.push("isValid.VlanRange(v,v_ip,v_mask)");
    return pe;
}
function nextField(name) {
    if ((typeof name !== "undefined")) {
        var split = name.split('_');
        if (split.length >= 2) {
            split[split.length - 1] = Number(split[split.length - 1]) + 1;
            return split.join('_');
        }
    }
}
function getGroupName(name) {
    var split = name.split("_");
    split.pop();
    return split.join('_');
}
function onKeyPressIpv6(_this, event) {
    if (!isHexaDigit(event.key)) {
        if (event.key == ':') {
            var next = nextField(_this.id);
            if ((typeof next !== "undefined")) {
                var el = document.getElementById(next);
                if (el) {
                    el.focus();
                }
            }
        }
        event.preventDefault();
    }
}
function onKeyPressIpv6v4(_this, event) {
    if (!isDigit(event.key) && event.key !== '.') {
        event.preventDefault();
    }
}
function onPasteIpv6(_this, e) {
    e.preventDefault();
    var content;
    if (e.clipboardData) {
        content = e.clipboardData.getData('text/plain');
    }
    else if (window.clipboardData) {
        content = window.clipboardData.getData('Text');
    }
    if (content) {
        parse_ipv6_into_fields(content, getGroupName(_this.id));
    }
    return false;
}
function onCopyIpv6(_this, e) {
    e.preventDefault();
    var textToCopy = parse_ipv6_from_fields(getGroupName(_this.id));
    if (e.clipboardData) {
        e.clipboardData.setData('Text', textToCopy);
    }
    else if (window.clipboardData) {
        window.clipboardData.setData('Text', textToCopy);
    }
    return false;
}
function genHtmlIpv6Blocks(name, required) {
    var html = "";
    var classDef = "ipv6-hextet";
    if (required)
        classDef = "required " + classDef;
    [":", ":", ":", ":", ":", ":", ":", ":"].forEach(function (dot, i) {
        var id = name + "_" + i;
        var inputAttribs = {
            type: 'text', "class": classDef, maxLength: 4, name: id, id: id,
            onKeyPress: "onKeyPressIpv6(this,event);",
            onPaste: "onPasteIpv6(this,event);",
            onCopy: "onCopyIpv6(this,event);"
        };
        var label = (i > 0) ? htmlTag("label", { "for": id, "class": 'input-connect-colon' }, dot) : "";
        html += htmlDiv({ id: "div_" + id, "class": 'field' }, label + htmlTag("input", inputAttribs, ""));
    });
    return html;
}
function parse_ipv6_into_fields(ipaddr, name) {
    if (!(typeof ipaddr !== "undefined") || ipaddr == '') {
        for (var i = 0; i < 8; i++) {
            $("#" + name + "_" + i).val("");
        }
        return;
    }
    ipaddr = ipaddr.replace(/\s+/g, '');
    var hextets = ipaddr.split(":");
    var octets = hextets[hextets.length - 1].split('.');
    var numFields = 8;
    var field6 = $("#" + name + "_6");
    if (octets.length === 4) {
        numFields = 7;
        field6.removeClass("ipv6-hextet");
        field6.addClass("ipv4-address");
        field6.attr("maxlength", 16);
        field6.attr("onKeyPress", "onKeyPressIpv6v4(this,event);");
        $("#div_" + name + "_7").hide();
    }
    else {
        field6.removeClass("ipv4-address");
        field6.addClass("ipv6-hextet");
        field6.attr("maxlength", 4);
        field6.attr("onKeyPress", "onKeyPressIpv6(this,event);");
        $("#div_" + name + "_7").show();
    }
    var shortfall = numFields - hextets.length;
    if (shortfall > 0 && hextets.length !== 1) {
        for (var i = 0; i < hextets.length; i++) {
            if (hextets[i] == "") {
                hextets[i] = "0";
                if (i === 0) {
                    i--;
                    continue;
                }
                for (var j = 0; j < shortfall; j++) {
                    hextets.splice(i, 0, "0");
                }
                break;
            }
        }
    }
    for (var i = 0; i < numFields; i++) {
        $("#" + name + "_" + i).val(hextets[i] || "0");
    }
}
function parse_ipv6_from_fields(name) {
    var hextets = [];
    for (var i = 0; i < 8; i++) {
        var val = $("#" + name + "_" + i).val();
        hextets[i] = (val != "") ? val : "0";
        if (hextets[i].indexOf('.') >= 0)
            break;
    }
    return hextets.join(":");
}
var EditableIpv6AddressVariable = (function (_super) {
    __extends(EditableIpv6AddressVariable, _super);
    function EditableIpv6AddressVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EditableIpv6AddressVariable.prototype.setVal = function (obj, val) { parse_ipv6_into_fields(val, this.memberName); };
    EditableIpv6AddressVariable.prototype.getVal = function () { return parse_ipv6_from_fields(this.memberName); };
    EditableIpv6AddressVariable.prototype.genHtml = function () { return genHtmlIpv6Blocks(this.memberName); };
    return EditableIpv6AddressVariable;
}(ShownVariable));
function editableIpv6AddressVariable(memberName, labelText) {
    var pe = new EditableIpv6AddressVariable(memberName, labelText);
    pe.validateLua.push("isValid.Ipv6Address(v)");
    return pe;
}
var EditableIpMaskVariable = (function (_super) {
    __extends(EditableIpMaskVariable, _super);
    function EditableIpMaskVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EditableIpMaskVariable.prototype.setVal = function (obj, val) { parse_ip_into_fields(val, this.memberName); };
    EditableIpMaskVariable.prototype.getVal = function () { return parse_ip_from_fields(this.memberName); };
    EditableIpMaskVariable.prototype.genHtml = function () {
        var fnGenIPBlocks = this.fnGenIPBlocks;
        if (!(typeof fnGenIPBlocks !== "undefined"))
            fnGenIPBlocks = this.required === false ? genHtmlMaskBlocksWithoutRequired : genHtmlMaskBlocks;
        return fnGenIPBlocks(this.memberName);
    };
    return EditableIpMaskVariable;
}(ShownVariable));
function editableIpMaskVariable(memberName, labelText, _fnGenIPBlocks) {
    var fnGenIPBlocks = _fnGenIPBlocks;
    var pe = new EditableIpMaskVariable(memberName, labelText, {
        setEnable: function (en) { }
    });
    pe.fnGenIPBlocks = fnGenIPBlocks;
    pe.validateLua.push("isValid.IpMask(v)");
    return pe;
}
var EditableVlanIpMaskVariable = (function (_super) {
    __extends(EditableVlanIpMaskVariable, _super);
    function EditableVlanIpMaskVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return EditableVlanIpMaskVariable;
}(EditableIpMaskVariable));
function editableVlanIpMaskVariable(memberName, labelText, _fnGenIPBlocks) {
    var fnGenIPBlocks = _fnGenIPBlocks;
    if (!(typeof _fnGenIPBlocks !== "undefined"))
        fnGenIPBlocks = genHtmlMaskBlocks;
    var pe = new EditableVlanIpMaskVariable(memberName, labelText, {
        setEnable: function (en) { }
    });
    pe.fnGenIPBlocks = fnGenIPBlocks;
    pe.isVlanMask = true;
    pe.validateLua.push("isValid.IpMask(v_mask)");
    return pe;
}
function editableURL(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (val) { return true; }, "", function (field) { return urlFilter(field); }, "isValid.URL(v)");
    return pe;
}
function editableHostname(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (val) { return true; }, "", function (field) { return hostNameFilter(field); }, "isValid.Hostname(v)");
    return pe;
}
function editableMacAddress(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setMaxLength(17);
    pe.setValidate(function (val) { return isValidMacAddress(val); }, "Invalid MAC address. Please specify a HEX value.", function (field) { return macAddrFilter(field); }, "isValid.MacAddress(v)");
    return pe;
}
function editableUsername(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (val) { return true; }, "Invalid user name.", function (field) { return userNameFilter(field); }, "isValid.Username(v)");
    pe.setEnable = function (en) { setEnable(pe.getHtmlId(), en); };
    return pe;
}
function editableUserOrEmail(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (val) { return true; }, "Invalid user name.", function (field) { return emailFilter(field); }, "isValid.UserOrEmail(v)");
    return pe;
}
function editableEmailAddress(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (val) {
        if (pe.required === false && val === "") {
            return true;
        }
        return validateEmail(val);
    }, "Invalid email address.", function (field) { }, "isValid.EmailAddress(v)");
    return pe;
}
function format2Digits(num) {
    return num < 10 ? ("0" + num.toString()) : num.toString();
}
var InstallCertTimeVariable = (function (_super) {
    __extends(InstallCertTimeVariable, _super);
    function InstallCertTimeVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    InstallCertTimeVariable.prototype.setVal = function (obj, val) {
        var date = new Date();
        var instCertTime = date.getFullYear().toString()
            + "-" + format2Digits(date.getMonth() + 1)
            + "-" + format2Digits(date.getDate())
            + "T" + format2Digits(date.getHours())
            + ":" + format2Digits(date.getMinutes())
            + ":" + format2Digits(date.getSeconds()) + "Z";
        $("#" + this.getHtmlId()).html(instCertTime);
    };
    return InstallCertTimeVariable;
}(StaticTextVariable));
function editableInteger(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (val) { return true; }, "", function (field) { return NumfieldEntry(field); }, "isValid.Integer(v)");
    return pe;
}
function editableBoundedInteger(memberName, labelText, lower, upper, msg, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    if (lower < 0) {
        pe.setValidate(function (val) { var n = parseInt(val); return n >= lower && n <= upper; }, msg, function (field) { return SignedNumfieldEntry(field); }, "isValid.BoundedSignedInteger(v," + lower + "," + upper + ")");
    }
    else {
        pe.setValidate(function (vals) { var val = parseInt(vals); return !isNaN(val) && val >= lower && val <= upper; }, msg, function (field) { return NumfieldEntry(field); }, "isValid.BoundedInteger(v," + lower + "," + upper + ")");
    }
    if (extras && extras.onKeyUp) {
        pe.attr.onKeyUp = extras.onKeyUp;
    }
    return pe;
}
function editableMultiRangedInteger(memberName, labelText, ranges, msg, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    var serverRanges = "";
    ranges.forEach(function (r) { serverRanges += (serverRanges == "" ? "" : ",") + "{" + r[0] + "," + r[1] + "}"; });
    pe.setValidate(function (vals) {
        var val = parseInt(vals);
        var isvalid = false;
        if (!isNaN(val)) {
            ranges.forEach(function (r) { if (val >= r[0] && val <= r[1]) {
                isvalid = true;
            } });
        }
        return isvalid;
    }, msg, function (field) { return NumfieldEntry(field); }, "isValid.MultiRangedInteger(v,{" + serverRanges + "})");
    if (extras && extras.onKeyUp) {
        pe.attr.onKeyUp = extras.onKeyUp;
    }
    return pe;
}
function editableDynamicBoundedInteger(memberName, labelText, lowerClient, upperClient, lowerServer, upperServer, msg, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (vals) {
        var val = parseInt(vals);
        var lower = lowerClient();
        var upper = upperClient();
        return val >= lower && val <= upper;
    }, msg, function (field) { return NumfieldEntry(field); }, "isValid.BoundedInteger(v," + lowerServer + "," + upperServer + ")");
    return pe;
}
function editableBoundedFloat(memberName, labelText, lower, upper, msg, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    if (lower < 0) {
        pe.setValidate(function (val) { var n = parseFloat(val); return n >= lower && n <= upper; }, msg, function (field) { return SignedFloatNumfieldEntry(field); }, "isValid.BoundedSignedFloat(v," + lower + "," + upper + ")");
    }
    else {
        pe.setValidate(function (vals) { var val = parseFloat(vals); return !isNaN(val) && val >= lower && val <= upper; }, msg, function (field) { return FloatNumfieldEntry(field); }, "isValid.BoundedFloat(v," + lower + "," + upper + ")");
    }
    if (extras && extras.onKeyUp) {
        pe.attr.onKeyUp = extras.onKeyUp;
    }
    return pe;
}
function editablePortNumber(memberName, labelText, extras) {
    var pe = editableBoundedInteger(memberName, labelText, 1, 65535, "Msg126", extras);
    pe.helperText = "1-65535";
    pe.setInputSizeCssName("sml");
    return pe;
}
function editablePortNumberMap(mapPorts, labelText, portNum) {
    switch (portNum) {
        case 1:
            return editableBoundedInteger(mapPorts[0], labelText, 1, 65535, "Msg126", { helperText: "1-65535", onKeyUp: "$('#inp_' + mapPorts[1]).val($('#inp_' + mapPorts[0]).val()); mapDstPort(mapPorts)" }).setInputSizeCssName("sml");
        default:
            return editableBoundedInteger(mapPorts[portNum - 1], labelText, 1, 65535, "Msg126", { helperText: "1-65535", onKeyUp: "mapDstPort(mapPorts)" }).setInputSizeCssName("sml");
    }
}
function mapDstPort(mapPorts) {
    if (Number($("#inp_" + mapPorts[1]).val()) != Number($("#inp_" + mapPorts[0]).val())) {
        $("#inp_" + mapPorts[2]).val($("#inp_" + mapPorts[0]).val());
        $("#inp_" + mapPorts[3]).val($("#inp_" + mapPorts[1]).val());
        $("#inp_" + mapPorts[2]).prop("disabled", true);
        return;
    }
    $("#inp_" + mapPorts[2]).prop("disabled", false);
    if ((Number($("#inp_" + mapPorts[1]).val()) > 0) && (Number($("#inp_" + mapPorts[0]).val()) > 0)) {
        $("#inp_" + mapPorts[3]).val($("#inp_" + mapPorts[2]).val());
    }
    else {
        $("#inp_" + mapPorts[1]).val("");
    }
}
var ToggleVariable = (function (_super) {
    __extends(ToggleVariable, _super);
    function ToggleVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ToggleVariable.prototype.setVal = function (obj, val) { setToggle(this.getHtmlId(), val); };
    ToggleVariable.prototype.getVal = function () { return String($("#" + this.getHtmlId()).val()); };
    ToggleVariable.prototype.genHtml = function () { return genToggleHtml(this.getHtmlId(), this.onClick, this.descriptiveText); };
    return ToggleVariable;
}(ShownVariable));
function toggleVariable(memberName, labelText, onClick, extras) {
    var pe = new ToggleVariable(memberName, labelText, extras);
    pe.setEnable = function (en) { setToggleEnable(this.getHtmlId(), en); };
    pe.onClick = onClick;
    pe.validateLua.push("isValid.BoolOrEmpty(v)");
    return pe;
}
var RadioButtonVariable = (function (_super) {
    __extends(RadioButtonVariable, _super);
    function RadioButtonVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    RadioButtonVariable.prototype.setVal = function (obj, val) { setRadioButtonVal(this.getHtmlId(), val); };
    RadioButtonVariable.prototype.getVal = function () { return getRadioButtonVal(this.getHtmlId()) ? "1" : "0"; };
    RadioButtonVariable.prototype.genHtml = function () { return genRadioButtonHtml(this.getHtmlId(), this.onClick); };
    return RadioButtonVariable;
}(ShownVariable));
function radioButtonVariable(memberName, labelText, onClick) {
    var pe = new RadioButtonVariable(memberName, labelText, {
        setEnable: function (en) { setRadioButtonEnable(this.getHtmlId(), en); }
    });
    pe.onClick = onClick;
    pe.validateLua.push("isValid.Bool(v)");
    return pe;
}
var CheckboxVariable = (function (_super) {
    __extends(CheckboxVariable, _super);
    function CheckboxVariable(name, labelText, onClick, cbText, cbTextStyle) {
        var _this_1 = _super.call(this, name, labelText, onClick) || this;
        _this_1.cbText = (typeof cbText !== "undefined") ? cbText : "";
        _this_1.cbTextStyle = (typeof cbTextStyle !== "undefined") ? cbTextStyle : "checkbox-cbText";
        return _this_1;
    }
    CheckboxVariable.prototype.setVal = function (obj, val) { setCheckboxVal(this.getHtmlId(), val); };
    CheckboxVariable.prototype.getVal = function () { return getCheckboxVal(this.getHtmlId()) ? "1" : "0"; };
    CheckboxVariable.prototype.genHtml = function () { return genCheckboxHtml(this.getHtmlId(), this.onClick, this.cbText, this.cbTextStyle); };
    return CheckboxVariable;
}(ShownVariable));
function checkboxVariable(memberName, labelText, onClick, cbText, cbTextStyle) {
    var pe = new CheckboxVariable(memberName, labelText, {
        setEnable: function (en) { setCheckboxEnable(this.getHtmlId(), en); }
    }, cbText, cbTextStyle);
    pe.onClick = onClick;
    pe.validateLua.push("isValid.Bool(v)");
    return pe;
}
var ButtonAction = (function (_super) {
    __extends(ButtonAction, _super);
    function ButtonAction() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ButtonAction.prototype.getVal = function () { return ""; };
    ButtonAction.prototype.genHtml = function () {
        var id = this.getHtmlId();
        if (this.buttonStyle == "submitButton") {
            return htmlDiv({ id: "div_" + id, "class": "submit-row form-row", style: "margin-left:0" }, htmlTag("button", { id: id, type: "button", onClick: this.onClick + "('" + id + "');"
            }, _(this.buttonText)));
        }
        else if (this.buttonStyle == "loginButton" ||
            this.buttonStyle == "rebootButton" ||
            this.buttonStyle == "resetButton" ||
            this.buttonStyle == "normalButton" ||
            this.buttonStyle == "xlargeButton" ||
            this.buttonStyle == "largeButton" ||
            this.buttonStyle == "ordinaryButton") {
            return htmlTag("button", {
                "class": "secondary " + this.buttonStyle, id: id, type: "button", onClick: this.onClick + "('" + id + "');"
            }, _(this.buttonText));
        }
        else {
            return htmlTag("button", {
                "class": "secondary", id: id, type: "button", onClick: this.onClick + "('" + id + "');",
                style: "width:auto;margin-left:0;"
            }, _(this.buttonText));
        }
    };
    return ButtonAction;
}(ShownVariable));
function buttonAction(memberName, buttonText, onClick, labelText, extras) {
    if (!(typeof labelText !== "undefined")) {
        labelText = "";
    }
    var pe = new ButtonAction(memberName, labelText, extras);
    pe.onClick = onClick;
    pe.buttonText = buttonText;
    if (extras && extras.buttonStyle) {
        pe.buttonStyle = extras.buttonStyle;
    }
    pe.setEnable = function (en) { setEnable(pe.getHtmlId(), en); };
    return pe;
}
function objVisibilityVariable(memberName, labelText, onClick) {
    var pe = toggleVariable(memberName, labelText, onClick);
    pe.visibilityVar = true;
    return pe;
}
var SelectVariable = (function (_super) {
    __extends(SelectVariable, _super);
    function SelectVariable(name, labelText, fnOptions, onChange, extras) {
        var _this_1 = _super.call(this, name, labelText, extras) || this;
        _this_1.fnOptions = fnOptions;
        _this_1.onChange = onChange;
        return _this_1;
    }
    SelectVariable.prototype.setVal = function (obj, val) { setOption(this.memberName, this.fnOptions(obj), val); };
    ;
    SelectVariable.prototype.getVal = function () { return String($("#sel_" + this.memberName).val()); };
    ;
    SelectVariable.prototype.genHtml = function () {
        var selClass = "defaultWidth";
        if ((typeof this.overwriteStyle !== "undefined")) {
            selClass = this.overwriteStyle;
        }
        this.htmlId = "sel_" + this.memberName;
        var attr = { id: this.htmlId, "class": "select " + selClass };
        if ((typeof this.onChange !== "undefined")) {
            attr.onChange = this.onChange + "(this);";
        }
        var selTag = "select";
        var descriptiveText = "";
        if (this.descriptiveText) {
            descriptiveText = htmlDiv({ "class": "descriptive-text" }, _(this.descriptiveText));
        }
        if (this.multiple) {
            selTag += " multiple";
            return htmlTag("span", { "class": "custom-multiselect" }, htmlTag(selTag, attr, "")) + descriptiveText;
        }
        return htmlTag("span", { "class": "custom-dropdown" }, htmlTag(selTag, attr, "")) + descriptiveText;
    };
    ;
    return SelectVariable;
}(ShownVariable));
function selectVariable(memberName, labelText, fnOptions, onChange, skipValidate, extras) {
    var pe = new SelectVariable(memberName, labelText, fnOptions, onChange, extras);
    pe.setEnable = function (en) { setEnable(pe.getHtmlId(), en); };
    if (skipValidate) {
        return pe;
    }
    var options = fnOptions();
    var luaOptions = [];
    options.forEach(function (opt) {
        if (typeof opt == "string") {
            luaOptions.push(opt);
        }
        else {
            luaOptions.push(opt[0]);
        }
    });
    if (luaOptions.length > 0) {
        pe.validateLua.push("isValid.Enum(v,{'" + luaOptions.join("','") + "'})");
    }
    return pe;
}
var SelectVariableInTable = (function (_super) {
    __extends(SelectVariableInTable, _super);
    function SelectVariableInTable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SelectVariableInTable.prototype.setVal = function (obj, val) { setOption(this.htmlId, this.fnOptions(obj), val); };
    ;
    SelectVariableInTable.prototype.genHtml = function () {
        var attr = { id: "sel_" + this.htmlId, "class": "select defaultWidth", onChange: this.onChange + "(this.id, this.value);" };
        return htmlTag("span", { "class": "custom-dropdown" }, htmlTag("select", attr, ""));
    };
    ;
    return SelectVariableInTable;
}(SelectVariable));
function selectVariableInTable(memberName, labelText, fnOptions, onChange) {
    var pe = new SelectVariableInTable(memberName, labelText, fnOptions, onChange);
    return pe;
}
function iconLink(icon, labelText) {
    var pe = {};
    pe.labelText = labelText;
    pe.icon = icon;
    pe.genHtml = function () {
        return htmlTag('a', { href: "" }, htmlTag('i', { "class": 'icon ' + icon }, ''));
    };
    return pe;
}
function editableHostnameWPort(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (val) { return true; }, "", function (field) {
        var tokens = field.value.split(":");
        var host = { value: tokens[0] };
        hostNameFilter(host);
        if (tokens.length > 1) {
            var port = { value: tokens[1] };
            NumfieldEntry(port);
            host.value = host.value.concat(":", port.value);
        }
        if (field.value.length != host.value.length) {
            field.value = host.value;
        }
    }, "isValid.HostnameWPort(v)");
    return pe;
}
function editableHostnameOrIpAddress(memberName, labelText, extras) {
    var pe = editableTextVariable(memberName, labelText, extras);
    pe.setValidate(function (val) { return is_valid_domain_name(val) || isValidIpAddress(val) || isValidIpv6Address(val); }, "Invalid hostname or IP address", function (field) { return hostNameIpFilter(field); }, "(isValid.Hostname(v) or isValid.IpAddress(v) or isValid.Ipv6Address(v))");
    return pe;
}
var SectionHeader = (function (_super) {
    __extends(SectionHeader, _super);
    function SectionHeader() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SectionHeader.prototype.genHtml = function () {
        return htmlTag('h2', {}, this.labelText);
    };
    return SectionHeader;
}(ShownVariable));
function sectionHeader(labelText) {
    var pe = new SectionHeader("noId", _(labelText));
    pe.unwrapped = true;
    return pe;
}
var FileUploader = (function (_super) {
    __extends(FileUploader, _super);
    function FileUploader(memberName, labelText, targetFile, fileExt, getParams, errExt, errLoad, showProgress, extras) {
        var _a, _b;
        var _this_1 = _super.call(this, memberName, labelText, extras) || this;
        _this_1.readOnly = true;
        _this_1.onInDOM = function () {
            var el = document.getElementById("inp_" + _this_1.memberName);
            if (el)
                el.onchange = function (ev) {
                    var el = ev.currentTarget;
                    _this_1.onUploaderFileChange("/" + relUrlOfPage, el.value);
                };
        };
        _this_1.targetFile = targetFile;
        _this_1.fileExt = fileExt;
        _this_1.helperText = _("not uploaded");
        if ((typeof extras !== "undefined")) {
            _this_1.keepFileName = (_a = extras["keepFileName"]) !== null && _a !== void 0 ? _a : false;
            _this_1.checkFreeSpace = (_b = extras["checkFreeSpace"]) !== null && _b !== void 0 ? _b : false;
        }
        _this_1.onUploaderFileChange = function (url, fileName, commit) {
            var params = (typeof getParams === "function") ? getParams(fileName) : [];
            var startIndex = fileName.lastIndexOf("\\");
            if (startIndex >= 0) {
                fileName = fileName.substr(startIndex);
                fileName = fileName.replace(/\\/g, "");
            }
            if (_this_1.keepFileName) {
                var relFileName = _this_1.targetFile + fileName;
                _this_1.targetFile = relFileName;
            }
            if (_this_1.checkFreeSpace && !commit) {
                var free_space;
                $.ajax({
                    type: 'post',
                    url: "UploadedFilesList/list",
                    data: { csrfToken: csrfToken },
                    dataType: "json",
                    async: false,
                    success: function (respObj) {
                        free_space = respObj.free_space;
                    }
                });
                var fileSize = document.getElementById("inp_" + memberName).files[0].size;
                var size = fileSize / (1024 * 1024);
                if (parseFloat(free_space) < size) {
                    validate_alert("", _("errSpaceMsg"));
                    return;
                }
            }
            if (_this_1.fileExt.length > 0 && (typeof errExt !== "undefined") && !commit) {
                var extIndex = fileName.lastIndexOf(".");
                if ((extIndex == -1) || _this_1.fileExt.indexOf(fileName.substr(extIndex)) == -1) {
                    blockUI_alert(_(errExt));
                    return;
                }
            }
            var formData = new FormData();
            params.forEach(function (p, i) {
                formData.append("param" + i, p);
            });
            formData.append("csrfTokenPost", csrfToken);
            url = "/fileupload" + url.split('.').slice(0, -1).join('.');
            formData.append("name", relFileName !== null && relFileName !== void 0 ? relFileName : targetFile);
            formData.append("target", memberName);
            if (commit) {
                var mode = queryParams["mode"];
                if (mode == "factory") {
                    formData.append("commit", "2");
                }
                else {
                    formData.append("commit", "1");
                }
            }
            else {
                formData.append("commit", "0");
                formData.append("file", document.getElementById("inp_" + memberName).files[0]);
            }
            if (!showProgress) {
                blockUI_wait(_("GUI pleaseWait"));
            }
            else {
                blockUI_wait_progress(_("GUI pleaseWait"));
            }
            var self = _this_1;
            $.ajax({
                xhr: function () {
                    var xhr = new XMLHttpRequest();
                    xhr.upload.addEventListener("progress", function (evt) {
                        if (evt.lengthComputable && showProgress) {
                            var percentComplete = evt.loaded / evt.total * 100;
                            $("#progressbar").progressbar({ value: percentComplete });
                        }
                    }, false);
                    return xhr;
                },
                url: url,
                data: formData,
                processData: false,
                contentType: false,
                type: 'post',
                success: function (respObj) {
                    $.unblockUI();
                    if (respObj.result == "0") {
                        var message = "uploaded";
                        message = respObj.message;
                        self.lengthyOperation(respObj);
                        fileName = undefined;
                        self.setFileUploadStatus(message, fileName);
                    }
                    else if (respObj.message != "") {
                        blockUI_alert(_(respObj.message));
                    }
                    else {
                        blockUI_alert(_(errLoad));
                    }
                    if (self.onPosted) {
                        self.onPosted(respObj);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $.unblockUI();
                }
            });
        };
        return _this_1;
    }
    FileUploader.prototype.lengthyOperation = function (respObj) {
        if (respObj.ping_delay > 0) {
            $.unblockUI();
            setTimeout(function () { blockUI_wait_progress(_(respObj.message)); }, 1000);
            var seconds_passed_1 = 0;
            var extras_1 = respObj.extras.split(";");
            setInterval(function () {
                seconds_passed_1 += 1;
                var percent = seconds_passed_1 / respObj.ping_delay * 100;
                if (percent > 98) {
                    respObj.ping_delay *= 1.02;
                    percent = seconds_passed_1 / respObj.ping_delay * 100;
                }
                $("#progressbar").progressbar({ value: percent });
            }, 1000);
            if ((typeof this.onLengthyOperation === "function")) {
                this.onLengthyOperation(respObj);
            }
            else {
                setTimeout(function () {
                    var timer = setInterval(function () {
                        $.ajax({
                            url: respObj.ping_url,
                            timeout: 800,
                            success: function () {
                                clearInterval(timer);
                                if (extras_1[1] && extras_1[1].length) {
                                    blockUI_wait_confirm(_(extras_1[1]), _("CSok"), function () {
                                        $(location).attr('href', respObj.ping_url);
                                    });
                                }
                                else {
                                    $(location).attr('href', respObj.ping_url);
                                }
                            },
                            error: function () {
                                if (extras_1[0] && extras_1[0].length) {
                                    $("#progress-message").text(_(extras_1[0]));
                                }
                            }
                        });
                    }, 1000);
                }, respObj.ping_delay * 1000);
            }
        }
    };
    FileUploader.prototype.getVal = function () { return ""; };
    FileUploader.prototype.setVal = function (obj, val) {
        var sts = _("not uploaded");
        var files = obj[this.memberName];
        var fileNameMatch = this.targetFile;
        if ((typeof obj.__id !== "undefined")) {
            fileNameMatch = this.targetFile.replace("*", String(obj.__id));
        }
        function lookForMatch(fileToMatch) {
            for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
                var file = files_1[_i];
                if (file.indexOf(fileToMatch) >= 0)
                    sts = _("uploaded");
            }
        }
        if ((typeof files !== "undefined")) {
            if (fileNameMatch.indexOf("*") >= 0) {
                for (var _i = 0, _a = this.fileExt; _i < _a.length; _i++) {
                    var ext = _a[_i];
                    lookForMatch(fileNameMatch.replace("*", ext));
                }
            }
            else {
                lookForMatch(fileNameMatch);
            }
        }
    };
    FileUploader.prototype.genHtml = function () {
        var attrs = { id: "inp_" + this.memberName, type: "file" };
        if (this.fileExt.length > 0) {
            attrs.accept = this.fileExt.join(",");
        }
        return htmlTag("span", { "class": "file-wrapper" }, htmlTag("input", attrs, "") +
            htmlTag("span", { "class": "secondary button fileUpload" }, _("chooseFile")));
    };
    ;
    FileUploader.prototype.setFileUploadStatus = function (sts, fileName) {
        var id = "#" + this.memberName + "_helperText";
        $(id).html(((typeof fileName !== "undefined") && fileName != "" ? "File '" + fileName + "' - " : "") + _(sts));
    };
    return FileUploader;
}(ShownVariable));
function fileUploader(memberName, labelText, targetFile, fileExt, getParams, errExt, errLoad, showProgress, extras) {
    return new FileUploader(memberName, labelText, targetFile, fileExt, getParams, errExt, errLoad, showProgress, extras);
}
var EditableDmsVariable = (function (_super) {
    __extends(EditableDmsVariable, _super);
    function EditableDmsVariable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EditableDmsVariable.prototype.genHtml = function () {
        var fnGenDmsBlocks = this.fnGenDmsBlocks;
        if (!(typeof fnGenDmsBlocks !== "undefined"))
            fnGenDmsBlocks = genHtmlDmsBlocks;
        return fnGenDmsBlocks(this.memberName, this.labelText);
    };
    return EditableDmsVariable;
}(ShownVariable));
function editableDmsVariable(memberName, labelText, _fnGenDmsBlocks) {
    var pe = new EditableDmsVariable(memberName, labelText);
    pe.fnGenDmsBlocks = _fnGenDmsBlocks;
    if (labelText == "Latitude") {
        pe.setValidate(function (val) {
            var value = Number(cvt_dms2dd("lati_dms"));
            return (value >= -90 && value <= 90);
        }, "out of range", function (field) { }, "isValid.DmsField('lati', v)");
    }
    else if (labelText == "Longitude") {
        pe.setValidate(function (val) {
            var value = Number(cvt_dms2dd("lati_dms"));
            return (value >= -180 && value <= 180);
        }, "out of range", function (field) { }, "isValid.DmsField('long', v)");
    }
    return pe;
}
var EditableTextArea = (function (_super) {
    __extends(EditableTextArea, _super);
    function EditableTextArea() {
        var _this_1 = _super !== null && _super.apply(this, arguments) || this;
        _this_1.style = "margin:6px 0 0 3px;";
        return _this_1;
    }
    EditableTextArea.prototype.updateCount = function (msg) { $("#CharCount").text(msg); };
    EditableTextArea.prototype.genHtml = function () {
        return htmlTag('textarea', { id: this.getHtmlId(), rows: this.rows, cols: this.cols }, '') + "<br>" + htmlTag('span', { id: "CharCount", style: "text-align:left;" }, '');
    };
    return EditableTextArea;
}(ShownVariable));
function editableTextArea(memberName, labelText, rows, cols, extras) {
    var pe = new EditableTextArea(memberName, labelText, extras);
    pe.rows = rows;
    pe.cols = cols;
    return pe;
}
var TextVariableWithHint = (function (_super) {
    __extends(TextVariableWithHint, _super);
    function TextVariableWithHint(memberName, labelText, extras) {
        var _this_1 = _super.call(this, memberName, labelText, extras) || this;
        if (memberName.match(/\d+/) != null)
            _this_1.num = memberName.match(/\d+/)[0];
        return _this_1;
    }
    TextVariableWithHint.prototype.genHtml = function () {
        var id = "hint";
        if ((typeof this.num !== "undefined"))
            id = id + this.num;
        var html = _super.prototype.genHtml.call(this);
        return html + htmlTag('label', { "class": "input-connect-dot", id: id, style: "color:BLUE;padding-left:10px;" }, "");
    };
    return TextVariableWithHint;
}(EditableTextVariable));
function phoneNumWithHint(memberName, labelText, extras) {
    var pe = new TextVariableWithHint(memberName, labelText, extras);
    pe.setValidate(function (val) { return (val.length != 0); }, "", function (field) { return check_phoneRegex(field); }, "isValid.PhoneNum(v)");
    return pe;
}
var ExtendableTextArray = (function (_super) {
    __extends(ExtendableTextArray, _super);
    function ExtendableTextArray(memberName, labelText, extras) {
        var _this_1 = _super.call(this, memberName, labelText, extras) || this;
        if (memberName.match(/\d+/) != null)
            _this_1.num = memberName.match(/\d+/)[0];
        return _this_1;
    }
    ExtendableTextArray.prototype.genHtml = function () {
        var html = _super.prototype.genHtml.call(this);
        return html + htmlTag('button', { type: "button", "class": "secondary", style: "margin-right:20px;", onclick: this.onclickIncrease }, "&nbsp;+&nbsp;") +
            htmlTag('button', { type: "button", "class": "secondary", style: "margin-right:20px;", onclick: this.onclickDecrease }, "&nbsp;-&nbsp;");
    };
    return ExtendableTextArray;
}(TextVariableWithHint));
function extendablePhoneNumArray(memberName, labelText, onclickIncrease, onclickDecrease, extras) {
    var pe = new ExtendableTextArray(memberName, labelText, extras);
    pe.onclickIncrease = onclickIncrease;
    pe.onclickDecrease = onclickDecrease;
    pe.setValidate(function (val) { return (val.length != 0); }, "", function (field) { return check_phoneRegex(field); }, "isValid.PhoneNum(v)");
    return pe;
}
function editIntegerSelect(memberName, labelText, fnOptions, msg, tips) {
    var pe = editableInteger(memberName, labelText);
    pe.setInputSizeCssName("sml");
    var options = fnOptions();
    var id = "inp_" + memberName;
    pe.htmlId = id;
    var bf_html = pe.genHtml();
    pe.genHtml = function () {
        var el;
        for (var _i = 0, options_1 = options; _i < options_1.length; _i++) {
            var opt = options_1[_i];
            el += htmlTag("option", { value: String(opt[0]) }, _(opt[1]));
        }
        return bf_html + htmlTag('label', { "class": "input-connect-dot" }, "&nbsp;&nbsp;" + msg + "&nbsp;&nbsp;") +
            htmlTag("span", { "class": "custom-dropdown" }, htmlTag("select", { id: "sel_" + memberName, "class": "select " + "defaultWid" }, el)) +
            htmlTag("span", { "class": "normal-text" }, tips);
    };
    pe.getVal = function () {
        var obj1 = document.getElementById("inp_" + memberName);
        var obj2 = document.getElementById("sel_" + memberName);
        var val = obj1.value + ',' + obj2.value;
        return val;
    };
    pe.validateLua = [];
    pe.setVal = function (obj, val) {
        var sumVal = val.split(",");
        var inp = document.getElementById("inp_" + memberName);
        var sel = document.getElementById("sel_" + memberName);
        inp.value = sumVal[0];
        sel.value = sumVal[1];
    };
    return pe;
}
var TableEdit = (function (_super) {
    __extends(TableEdit, _super);
    function TableEdit(memberName, labelText) {
        var _this_1 = _super.call(this, memberName) || this;
        _this_1.setLabel(labelText);
        return _this_1;
    }
    TableEdit.prototype.genHtml = function () {
        return htmlTag('a', { href: "", "class": "secondary sml edit" }, htmlTag('i', { "class": "icon " + this.editClass }, ''));
    };
    return TableEdit;
}(PageElement));
function tableEdit(memberName, labelText, editClass, tableFuncName) {
    var pe = new TableEdit(memberName, labelText);
    pe.editClass = editClass;
    pe.tableFuncName = tableFuncName;
    return pe;
}
function editPhoneNum(memberName, labelText, required) {
    var pe = editableTextVariable(memberName, labelText);
    pe.setRequired(required);
    pe.setValidate(function (val) { if (val.length == 0)
        return false; return true; }, "", function (field) { return check_phoneRegex(field); }, "isValid.PhoneNum(v)");
    return pe;
}
function selectVariableTable(memberName, labelText, fnOptions, onChange) {
    var pe = new SelectVariableTable(memberName, labelText, fnOptions, onChange);
    pe.setEnable = function (en) { setEnable(pe.getHtmlId(), en); };
    return pe;
}
var SelectVariableTable = (function (_super) {
    __extends(SelectVariableTable, _super);
    function SelectVariableTable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SelectVariableTable.prototype.setVal = function (obj, val) { setOption(this.rowMemberId, this.fnOptions(obj), val); };
    ;
    SelectVariableTable.prototype.getVal = function () { return String($("#sel_" + this.rowMemberId).val()); };
    ;
    SelectVariableTable.prototype.genHtml = function () {
        this.rowMemberId = this.htmlId;
        this.htmlId = "sel_" + this.rowMemberId;
        var attr = { id: this.htmlId, "class": "wideWidth", onChange: this.onChange + "(this.id, this.value);" };
        return htmlTag("span", { "class": "custom-dropdown" }, htmlTag("select", attr, ""));
    };
    ;
    return SelectVariableTable;
}(SelectVariable));
function pingableHostname(memberName, labelText, extras) {
    var pe = editableHostname(memberName, labelText, extras);
    pe.onInDOM = function () {
        addUpdateField(this.memberName);
    };
    return pe;
}
var TextLinkConst = (function (_super) {
    __extends(TextLinkConst, _super);
    function TextLinkConst(name, text, link, extras) {
        var _this_1 = _super.call(this, name, text, extras) || this;
        _this_1.link = link;
        return _this_1;
    }
    TextLinkConst.prototype.genHtml = function () {
        return htmlTag('div', { id: this.getHtmlId(), 'class': this.cssClass, style: this.style }, htmlTag('a', { id: this.getHtmlId() + "_hyperLink", "class": "hyperlink-text", href: this.link, style: "color:rgb(255, 130, 0)" }, _(this.text)));
    };
    return TextLinkConst;
}(NoticeTextConst));
function setMemberVisibility(_this, objShown, members) {
    for (var _i = 0, members_1 = members; _i < members_1.length; _i++) {
        var pe = members_1[_i];
        if (pe.hidden) {
            continue;
        }
        if (pe.memberName !== _this.visibilityVar) {
            var show = objShown;
            if ((typeof pe.fnIsVisible === "function")) {
                show = pe.fnIsVisible();
            }
            pe.setVisible(show);
        }
    }
}
function PageObj(name, label, extras) {
    var Obj = {
        objName: name,
        labelText: label,
        packageObj: function () {
            if (this.readOnly)
                return;
            var pgeObj = this;
            var obj = {};
            pgeObj.members.forEach(function (mem) {
                if (mem.readOnly)
                    return;
                if (mem.getVal) {
                    if ((typeof mem.encode !== "undefined") && mem.encode === true)
                        obj[mem.memberName] = encode(mem.getVal());
                    else
                        obj[mem.memberName] = mem.getVal();
                }
                else {
                    if ((typeof pgeObj.obj[mem.memberName] !== "undefined")) {
                        obj[mem.memberName] = pgeObj.obj[mem.memberName];
                    }
                }
            });
            if (pgeObj.encodeRdb) {
                obj = pgeObj.encodeRdb(obj);
            }
            obj.name = pgeObj.objName;
            return obj;
        },
        onInDOM: function () {
            var callMembers = function (members) {
                if ((typeof members !== "undefined")) {
                    for (var _i = 0, members_2 = members; _i < members_2.length; _i++) {
                        var pe = members_2[_i];
                        if ((typeof pe.onInDOM === "function")) {
                            pe.onInDOM();
                        }
                    }
                }
            };
            callMembers(this.members);
            callMembers(this.editMembers);
        },
        populate: function () {
            var _a, _b, _c;
            var obj = this.obj;
            var pgeObj = this;
            var disableWrite = false;
            if ((_a = pageData.authenticatedOnly) !== null && _a !== void 0 ? _a : true) {
                var writeGroups = (_c = (_b = pgeObj.writeGroups) !== null && _b !== void 0 ? _b : pageData.writeGroups) !== null && _c !== void 0 ? _c : ["root", "admin"];
                disableWrite = !checkGroupAccess(writeGroups, userGroups);
            }
            this.members.forEach(function (mem) {
                if (mem.hidden)
                    return;
                var val = obj[mem.memberName];
                if ((typeof val !== "undefined")) {
                    if ((typeof mem.encode !== "undefined") && (mem.encode === true)) {
                        val = decode(val);
                    }
                }
                else {
                    val = "";
                }
                if ((typeof mem.setVal === "function")) {
                    mem.setVal(obj, val);
                }
                if ((pgeObj.readOnly || mem.readOnly || disableWrite) && (typeof mem.setEnable === "function")) {
                    mem.setEnable(false);
                }
                if ((typeof pgeObj.postPopulate === "function")) {
                    pgeObj.postPopulate();
                }
            });
        },
        clear: function () {
            this.members.forEach(function (mem) {
                mem.setVal(this, "");
            });
        },
        editClear: function () {
            this.editMembers.forEach(function (mem) {
                mem.setVal(this, "");
            });
        },
        setPageObjectVisible: function (visible) {
            this.invisible = !visible;
            if (this.invisible) {
                setVisible("#objouterwrapper" + this.objName, false);
            }
            else {
                setVisible("#objouterwrapper" + this.objName, true);
            }
        }
    };
    mergeObject(Obj, extras);
    Obj.members.forEach(function (mem) {
        if (mem.visibilityVar) {
            Obj.visibilityVar = mem.memberName;
            mem.onClick = "onClick" + Obj.visibilityVar;
        }
    });
    if ((typeof Obj.postPageObj === "function")) {
        Obj.postPageObj();
    }
    return Obj;
}
function PageTableObj(name, label, extras) {
    var pgeObj = PageObj(name, label, extras);
    pgeObj.genObjHtml = genTable;
    pgeObj.populate = populateTable;
    pgeObj.packageObj = function () {
        if (this.readOnly)
            return;
        var obj = {};
        if (this.encodeRdb) {
            obj.objs = this.encodeRdb(this.obj);
        }
        else
            obj.objs = this.obj;
        obj.name = this.objName;
        return obj;
    };
    return pgeObj;
}
function _genVariableList(members, extraAttr) {
    function labelAndField(mem, field) {
        var divAttr = { "class": "field" };
        if ((typeof mem.style !== "undefined"))
            divAttr.style = mem.style;
        if ((typeof mem["class"] !== "undefined"))
            divAttr["class"] = mem["class"];
        var lfor = {};
        if (mem.labelFor)
            lfor = { "for": mem.labelFor };
        if (mem.labelStyle)
            lfor.style = mem.labelStyle;
        var labelTag = "label";
        if ((typeof extraAttr !== "undefined") && (typeof extraAttr.labelTag !== "undefined")) {
            labelTag = extraAttr.labelTag;
        }
        return htmlDiv({ id: "div_" + mem.memberName, "class": "form-row" }, htmlTag(labelTag, lfor, _(mem.labelText)) +
            htmlDiv(divAttr, field) + helperText(mem));
    }
    function addVerification(html, matchName) {
        return html.replace("[required]", "[required,equals[inp_" + matchName + "]]");
    }
    var list = "";
    if (members) {
        members.forEach(function (mem) {
            if (mem.hidden)
                return;
            var id = "inp_" + mem.memberName;
            mem.htmlId = id;
            if ((typeof mem.genMultiRow === "function")) {
                list += mem.genMultiRow(labelAndField);
            }
            else
                list += mem.unwrapped === true ? mem.genHtml() : labelAndField(mem, mem.genHtml());
        });
    }
    return list;
}
function genTable() {
    var pgeObj = this;
    var button = "";
    var colgroup = "";
    var thead = "";
    var heading = "";
    var headerTag = "h2-body-subtitle";
    var boxAttr = "body-box";
    var tAttr = pgeObj.extraAttr;
    if ((typeof tAttr !== "undefined") && (typeof tAttr.headerTag !== "undefined")) {
        headerTag = tAttr.headerTag;
    }
    if ((typeof tAttr !== "undefined") && (typeof tAttr.boxAttr !== "undefined")) {
        boxAttr = tAttr.boxAttr;
    }
    if (this.colgroup) {
        this.colgroup.forEach(function (col) {
            colgroup += htmlTag("col", { width: col }, "");
        });
        colgroup = htmlTag("colgroup", {}, colgroup);
    }
    function getThAttr(col) {
        if ((typeof tAttr !== "undefined") && (typeof tAttr.thAttr !== "undefined")) {
            var len = tAttr.thAttr.length;
            if (col >= len)
                col = len - 1;
            return tAttr.thAttr[col];
        }
        return { "class": "align10" };
    }
    var idx = 0;
    this.members.forEach(function (mem) {
        if (mem.hidden)
            return;
        thead += htmlTag("th", getThAttr(idx++), _(mem.labelText));
    });
    if (this.arrayEditAllowed || this.editAddOnly) {
        if (this.arrayEditAllowed) {
            thead += htmlTag("th", getThAttr(idx++), "");
            thead += htmlTag("th", getThAttr(idx++), "");
        }
        button = htmlDiv({ "class": "submit-row-condensed" }, htmlTag("button", { type: "button", onClick: "table_add('" + this.objName + "');", "class": "secondary editAdd fr", id: this.objName + "_addBtn" }, htmlTag("i", { "class": "icon plus" }, "") + _("add")));
        heading = htmlDiv({ "class": "grid-75" }, htmlTag(headerTag, {}, _(this.labelText))) +
            htmlDiv({ "class": "grid-25" }, button);
    }
    else if (this.editRemovalOnly) {
        thead += htmlTag("th", getThAttr(idx++), "");
        heading = htmlDiv({ "class": "grid-75" }, htmlTag(headerTag, {}, _(this.labelText))) +
            htmlDiv({ "class": "grid-25" }, button);
    }
    else if (this.makeTableHeading) {
        heading = htmlTag(headerTag, { id: "heading_msg" }, _(this.labelText)) +
            htmlTag("td", {}, htmlTag("a", { href: "javascript:window.location.reload()", "class": "secondary sml edit", style: "float:right" }, htmlTag("i", { "class": "icon refresh" }, ""))) + "<br>" +
            htmlTag("div", { id: "div_page_navi" }, htmlTag('button', { type: "button", "class": "secondary", id: "button_forwards", style: "margin-right:20px;margin-left:20px;", onclick: "table_page_nav('" + this.objName + "', -1);" }, "< Previous") +
                htmlTag('label', { "class": "input-connect-dot", id: "inp_pageNumber" }, "0 of 1") +
                htmlTag('button', { type: "button", "class": "secondary", id: "button_backwards", style: "margin-right:20px;margin-left:20px;", onclick: "table_page_nav('" + this.objName + "', 1);" }, "Next >")) +
            htmlTag('button', { type: "button", "class": "secondary fr", id: "button_delete", style: "margin-right:20px;margin-left:20px;", onclick: "table_page_clear('" + this.objName + "');" }, "Delete All");
    }
    else if (this.editHeader) {
        heading = htmlTag(headerTag, { id: "header_newText" }, _(this.labelText));
    }
    else if (this.labelText != "") {
        heading = htmlTag(headerTag, {}, _(this.labelText));
    }
    thead = htmlTag("thead", {}, htmlTag("tr", {}, thead));
    var table;
    if (this.autoScrollTable) {
        var tableHeaderAttribs = { id: this.objName + "Heder" };
        var tableAttribs = { id: this.objName };
        if ((typeof tAttr !== "undefined") && (typeof tAttr.tableAttr !== "undefined")) {
            tableHeaderAttribs = mergeObject(tableHeaderAttribs, tAttr.tableAttr);
            tableAttribs = mergeObject(tableAttribs, tAttr.tableAttr);
        }
        table = htmlDiv({ id: "table" + this.objName + "Header", "class": "autoScrollTable" }, heading +
            htmlTag("table", tableHeaderAttribs, colgroup + thead)) +
            htmlDiv({ id: "table" + this.objName, "class": "autoScrollTable" }, htmlTag("table", tableAttribs, htmlTag("tbody", {}, "")));
    }
    else {
        var tableAttribs = { id: this.objName };
        if ((typeof tAttr !== "undefined") && (typeof tAttr.tableAttr !== "undefined")) {
            tableAttribs = mergeObject(tableAttribs, tAttr.tableAttr);
        }
        table = htmlDiv({ id: "table" + this.objName }, heading +
            htmlTag("table", tableAttribs, colgroup + thead + htmlTag("tbody", {}, "")));
    }
    if (this.arrayEditAllowed) {
        table += htmlDiv({ id: "edit" + this.objName, style: "display:none" }, htmlTag(headerTag, {}, _(this.editLabelText)) +
            _genVariableList(this.editMembers));
    }
    var members = htmlDiv({ id: "objwrapper" + this.objName }, table);
    var styleCss = "";
    if (this.invisible) {
        styleCss += "display:none;";
    }
    return htmlDiv({ "class": boxAttr + " form-row" + " table-box", id: "objouterwrapper" + this.objName, style: styleCss }, members);
}
function genVariableList() {
    var headerTag = "h2-body-subtitle";
    if ((typeof this.extraAttr !== "undefined") && (typeof this.extraAttr.headerTag !== "undefined")) {
        headerTag = this.extraAttr.headerTag;
    }
    var heading = "";
    if ((typeof this.labelText !== "undefined") && this.labelText !== "") {
        heading = htmlTag(headerTag, {}, _(this.labelText));
    }
    var objWrapperDivAttr = { id: "objwrapper" + this.objName };
    if ((typeof this.extraAttr !== "undefined") && (typeof this.extraAttr.wrapperDivCssClass !== "undefined")) {
        objWrapperDivAttr["class"] = this.extraAttr.wrapperDivCssClass;
    }
    var members = htmlDiv(objWrapperDivAttr, _genVariableList(this.members, this.extraAttr));
    if (!this.setVisible) {
        this.setVisible = function (v) {
            var pgeObj = this;
            var visVar = pgeObj.visibilityVar;
            if (!(typeof visVar !== "undefined")) {
                setMemberVisibility(pgeObj, true, pgeObj.members);
            }
            else {
                if ((typeof v !== "undefined")) {
                    if ((typeof pgeObj.setEnabled === "function")) {
                        pgeObj.setEnabled(v == "1");
                    }
                }
                else {
                    v = this.obj[visVar];
                }
                setToggle("inp_" + visVar, v);
                setMemberVisibility(pgeObj, toBool(v), pgeObj.members);
            }
            if ((typeof pgeObj.setVisibleExtra === "function")) {
                pgeObj.setVisibleExtra(v);
            }
        };
    }
    return htmlDiv({ id: "objouterwrapper" + this.objName }, heading + members);
}
function displayAlert(heading, text) {
    var alert = htmlDiv({ "class": "grid-9 alpha" }, htmlDiv({ "class": "note-lrg" }, htmlDiv({ "class": "wrap alert clearfix" }, htmlTag("h2", {}, heading) +
        htmlTag("p", {}, text))));
    document.body.innerHTML = genBodyHtml(alert);
    setVisible('#form', '0');
    setVisible("#body", "1");
    genThemeHeader(pageData, userGroups);
}
function genPage() {
    if (pageData.disabled === true) {
        displayAlert(_(pageData.alertHeading), _(pageData.alertText));
        return;
    }
    document.body.innerHTML = genBodyHtml("");
    var columns = [];
    columns[0] = "";
    columns[1] = "";
    pageData.pageObjects.forEach(function (pgeObj) {
        var col = 0;
        if ((typeof pgeObj.pageWarning !== "undefined")) {
            columns[col] += "<h2-body><span>" + _(pgeObj.pageWarning[0]) + "</span></h2-body>";
            for (var i = 1; i < pgeObj.pageWarning.length; i++) {
                columns[col] += "<p>" + _(pgeObj.pageWarning[i]) + "</p>";
            }
        }
        if (typeof pgeObj.column !== "undefined")
            col = pgeObj.column - 1;
        if (!pgeObj.genObjHtml) {
            pgeObj.genObjHtml = genVariableList;
        }
        columns[col] += pgeObj.genObjHtml();
    });
    if (pageData.noTitleBox !== true) {
        var headerTag = "h2-titleBox-large";
        if ((typeof pageData.style !== "undefined") && (typeof pageData.style.headerCssClass !== "undefined")) {
            headerTag = pageData.style.headerCssClass;
        }
        var title = "";
        var titleText = _(pageData.title);
        if ((typeof pageData.overrideTitle !== "undefined")) {
            titleText = _(pageData.overrideTitle);
        }
        title = htmlDiv({ id: "objouterwrapper" + "TitleBox" }, htmlTag(headerTag, {}, titleText.toUpperCase()));
        $("#titleGoesHere").append(title);
    }
    $("#htmlGoesHere").append(columns[0]);
    if (columns[1].length > 0)
        $("#rightGoesHere").append(columns[1]);
    setVisible('#alertMsg', '0');
    for (var _i = 0, _a = pageData.pageObjects; _i < _a.length; _i++) {
        var pgeObj = _a[_i];
        if ((typeof pgeObj.onInDOM === "function")) {
            pgeObj.onInDOM();
        }
    }
    genThemeHeader(pageData, userGroups);
}
function populateTable(pageObj) {
    var _a, _b, _c;
    var pgeObj = this;
    if ((typeof pageObj !== "undefined")) {
        pgeObj = pageObj;
    }
    var disableWrite = false;
    if ((_a = pageData.authenticatedOnly) !== null && _a !== void 0 ? _a : true) {
        var writeGroups = (_c = (_b = pgeObj.writeGroups) !== null && _b !== void 0 ? _b : pageData.writeGroups) !== null && _c !== void 0 ? _c : ["root", "admin"];
        disableWrite = !checkGroupAccess(writeGroups, userGroups);
    }
    var table = document.getElementById(pgeObj.objName);
    if (!table)
        return;
    var tbody = table.getElementsByTagName("tbody")[0];
    if (!tbody)
        return;
    while (tbody.rows.length > pgeObj.obj.length)
        tbody.deleteRow(tbody.rows.length - 1);
    pgeObj.obj.forEach(function (ob, rowIndex) {
        function addIcon(row, type) {
            var cell = row.cells[colIndex++];
            if (!cell)
                cell = row.insertCell(-1);
            var icon = iconLink(type, "");
            var properHref = "javascript:table_" + icon.icon + "('" + pgeObj.objName + "'," + ob.__id + ");";
            cell.innerHTML = icon.genHtml(ob).replace('href=""', 'href="' + properHref + '"');
        }
        var row = tbody.rows[rowIndex];
        if (!row)
            row = tbody.insertRow(-1);
        var colIndex = 0;
        pgeObj.members.forEach(function (mem) {
            if (mem.hidden)
                return;
            mem.htmlId = pgeObj.objName + "_" + rowIndex + "_" + mem.memberName;
            var genHtml = false;
            var cell = row.cells[colIndex++];
            if (!cell) {
                cell = row.insertCell(-1);
                genHtml = true;
            }
            cell.id = mem.htmlId;
            var val = ob[mem.memberName];
            if (!pgeObj.textOnly && genHtml && (typeof mem.genHtml !== "undefined")) {
                cell.innerHTML = mem.genHtml();
            }
            if (mem instanceof TableEdit) {
                cell.innerHTML = mem.genHtml().replace('href=""', 'href="javascript:' + mem.tableFuncName + "('" + pgeObj.objName + "'," + ob.__id + ');"');
            }
            if ((typeof val !== "undefined"))
                mem.setVal(ob, val);
            if ((pgeObj.readOnly || mem.readOnly || disableWrite) && (typeof mem.setEnable === "function")) {
                mem.setEnable(false);
            }
        });
        if (pgeObj.arrayEditAllowed) {
            addIcon(row, "edit");
            if (!(typeof pgeObj.customRowDelete === "function") || !pgeObj.customRowDelete(ob, row, colIndex)) {
                addIcon(row, "close");
            }
            else {
                colIndex++;
            }
        }
        if (pgeObj.editRemovalOnly) {
            addIcon(row, "close");
        }
        if ((typeof pgeObj.postPopulate === "function")) {
            pgeObj.postPopulate();
        }
    });
}
function getRowIndex(htmlId) {
    var fields = htmlId.split("_");
    return fields[0] == "sel" ? parseInt(fields[2]) : parseInt(fields[1]);
}
function _table_edit(pgeObj, obj) {
    var tableName = pgeObj.objName;
    clear_alert();
    function cancelTableEdit() {
        $(".error").each(function () {
            $(this).removeClass("error");
        });
        $(".valid").each(function () {
            $(this).removeClass("valid");
        });
        setVisible("#edit" + tableName, "0");
        setVisible("#cancelButton", "0");
        setVisible("#table" + tableName, "1");
        $("#saveButton").off('click').on('click', sendObjects);
        if ((typeof pgeObj.offEdit !== "undefined"))
            pgeObj.offEdit();
        if ((typeof pgeObj.obj !== "undefined") && pgeObj.obj.length > 0) {
            var lastObj = pgeObj.obj[pgeObj.obj.length - 1];
            if (!lastObj.__saved) {
                pgeObj.obj.pop();
            }
        }
    }
    function cancelTableEditClearAlert() {
        clear_alert();
        cancelTableEdit();
    }
    function saveTableEdit() {
        pgeObj.editMembers.forEach(function (mem) {
            if ((typeof mem.memberName !== "undefined") && (typeof mem.getVal === "function")) {
                obj[mem.memberName] = mem.getVal();
            }
        });
        if ((typeof pgeObj.saveObj === "function"))
            pgeObj.saveObj(obj);
        obj.dirty = true;
        if ((typeof pgeObj.getValidationError === "function")) {
            var errMsg = pgeObj.getValidationError(obj);
            if ((typeof errMsg !== "undefined")) {
                validate_alert("", _(errMsg));
                return;
            }
        }
        if (pgeObj.sendThisObjOnly) {
            sendSingleObject(pgeObj, function () {
                pgeObj.populate();
                cancelTableEdit();
            });
        }
        else {
            sendObjects(function () {
                pgeObj.populate();
                cancelTableEdit();
            });
        }
    }
    if ((typeof pgeObj.onEdit === "function"))
        pgeObj.onEdit(obj);
    setVisible("#table" + tableName, "0");
    pgeObj.editMembers.forEach(function (mem) {
        mem.setVal(obj, (typeof mem.memberName !== "undefined") ? obj[mem.memberName] : "");
    });
    setVisible("#edit" + tableName, "1");
    $("#cancelButton").click(cancelTableEditClearAlert);
    $("#saveButton").off('click').on('click', saveTableEdit);
    setVisible("#cancelButton", "1");
    if ((typeof pgeObj.setVisible === "function") && (typeof pgeObj.visibilityVar !== "undefined")) {
        pgeObj.setVisible(obj[pgeObj.visibilityVar]);
    }
    if ((typeof pgeObj.unfoldTable === "function"))
        pgeObj.unfoldTable();
}
function table_page_nav(tableName, direction) {
    pageData.pageObjects.forEach(function (pgeObj) {
        if (pgeObj.objName == tableName) {
            if ((typeof pgeObj.tablePageNavFunc === "function")) {
                pgeObj.tablePageNavFunc(direction);
            }
        }
    });
}
function table_page_clear(tableName) {
    pageData.pageObjects.forEach(function (pgeObj) {
        if (pgeObj.objName == tableName) {
            if ((typeof pgeObj.tablePageClearFunc === "function")) {
                pgeObj.tablePageClearFunc();
            }
        }
    });
}
function table_edit(tableName, id) {
    pageData.pageObjects.forEach(function (pgeObj) {
        if (pgeObj.objName == tableName) {
            pgeObj.obj.forEach(function (obj) {
                if (obj.__id === id)
                    _table_edit(pgeObj, obj);
            });
        }
    });
}
function table_close(tableName, id) {
    pageData.pageObjects.forEach(function (pgeObj) {
        if (pgeObj.objName == tableName) {
            var delObj = true;
            if ((typeof pgeObj.delObj === "function")) {
                delObj = pgeObj.delObj(id);
            }
            if (delObj) {
                if (pgeObj.indexHoleAllowed) {
                    for (var _i = 0, _a = pgeObj.obj; _i < _a.length; _i++) {
                        var obj = _a[_i];
                        if (obj.__id === id) {
                            obj.__deleted = true;
                            break;
                        }
                    }
                }
                else {
                    var arr = pgeObj.obj;
                    var idx_deleted = -1;
                    for (var idx = 0; idx < arr.length; idx++) {
                        if (arr[idx].__id == id) {
                            idx_deleted = idx;
                        }
                        else if (arr[idx].__id > id) {
                            arr[idx].__id--;
                        }
                    }
                    if (idx_deleted >= 0) {
                        arr.splice(idx_deleted, 1);
                    }
                }
            }
            if (pgeObj.sendThisObjOnly) {
                sendSingleObject(pgeObj);
            }
            else {
                sendObjects();
            }
        }
    });
}
function table_add(tableName) {
    pageData.pageObjects.forEach(function (pgeObj) {
        if (pgeObj.objName == tableName) {
            var idx = pgeObj.obj.length;
            var newObj = {};
            if ((typeof pgeObj.initObj === "function")) {
                newObj = pgeObj.initObj();
            }
            if ((typeof newObj !== "undefined")) {
                if (!(typeof newObj.__id !== "undefined")) {
                    var offset = 0;
                    if ((typeof newObj._rdbIdxOffset !== "undefined") && typeof newObj._rdbIdxOffset === "number") {
                        offset = newObj._rdbIdxOffset;
                    }
                    var lastId = offset - 1;
                    var holeId = offset - 1;
                    for (var _i = 0, _a = pgeObj.obj; _i < _a.length; _i++) {
                        var obj = _a[_i];
                        if (obj.__id > lastId + 1) {
                            holeId = lastId + 1;
                            break;
                        }
                        lastId = obj.__id;
                    }
                    newObj.__id = (holeId < 0 + offset) ? (idx + offset) : holeId;
                }
                newObj.__saved = false;
                newObj.__deleted = false;
                pgeObj.obj[idx] = newObj;
                _table_edit(pgeObj, pgeObj.obj[idx]);
            }
        }
    });
}
function cachedScriptLoad(url, options) {
    options = $.extend(options || {}, {
        dataType: "script",
        cache: true,
        url: url
    });
    return jQuery.ajax(options);
}
;
function requestPageObjects() {
    var objectsToRequest = [];
    pageData.pageObjects.forEach(function (pgeObj) {
        var _a, _b;
        var readGroups = (_b = (_a = pgeObj.readGroups) !== null && _a !== void 0 ? _a : pageData.readGroups) !== null && _b !== void 0 ? _b : ['root', 'admin'];
        if (pageData.authenticatedOnly === false || checkGroupAccess(readGroups, userGroups)) {
            objectsToRequest[objectsToRequest.length] = pgeObj.objName;
        }
    });
    requestObjects(objectsToRequest, receiveFirstObjects);
}
function requestSinglePageObject(pgeObj) {
    requestObjects([pgeObj.objName], receiveObjects);
}
function getObjectsToSend() {
    var objs = [];
    pageData.pageObjects.forEach(function (pgeObj) {
        var _a, _b;
        var writeGroups = (_b = (_a = pgeObj.writeGroups) !== null && _a !== void 0 ? _a : pageData.writeGroups) !== null && _b !== void 0 ? _b : ['root', 'admin'];
        if (pageData.authenticatedOnly === false || checkGroupAccess(writeGroups, userGroups)) {
            var obj = pgeObj.packageObj();
            if (obj)
                objs[objs.length] = obj;
        }
    });
    return objs;
}
function receiveObjects(resp) {
    var validateFailed = true;
    if (resp.result !== 0) {
        if (resp.text.indexOf("Invalid csrfToken") >= 0) {
            alertInvalidCsrfToken();
        }
        else if ((typeof resp.errorText !== "undefined")) {
            validate_alert(_("invalidRequestTitle"), _(resp.errorText));
        }
        else if (resp.access === "NeedsAuthentication") {
            validate_alert(_("needAuthTitle"), _("needAuthMsg"));
        }
        else {
            alertInvalidRequest();
        }
    }
    else {
        validateFailed = false;
    }
    pageData.pageObjects.forEach(function (pgeObj) {
        var _a, _b;
        var obj = resp[pgeObj.objName];
        if (obj) {
            if (!(pgeObj.arrayEditAllowed && validateFailed)) {
                if ((typeof pgeObj.decodeRdb !== "undefined")) {
                    obj = pgeObj.decodeRdb(obj);
                }
                if ((typeof pgeObj.editMembers !== "undefined")) {
                    obj.forEach(function (obj) {
                        obj.__saved = true;
                    });
                }
                pgeObj.obj = obj;
                if (!validateFailed) {
                    pgeObj.populate();
                }
            }
            if ((typeof pgeObj.setVisible !== "undefined")) {
                pgeObj.setVisible();
            }
        }
        else {
            console.log(resp);
            var readGroups = (_b = (_a = pgeObj.readGroups) !== null && _a !== void 0 ? _a : pageData.readGroups) !== null && _b !== void 0 ? _b : ["root", "admin"];
            if (!checkGroupAccess(readGroups, userGroups)) {
                pgeObj.setPageObjectVisible(false);
            }
        }
    });
}
function isFormValid(form) {
    if (!(typeof form !== "undefined")) {
        form = "#form";
    }
    if (!$(form).validationEngine("validate")) {
        validate_alert("", "");
        return false;
    }
    return true;
}
function sendObjects(fnSuccess, fnFail) {
    if (isFormValid()) {
        var objs = getObjectsToSend();
        sendTheseObjects(objs, fnSuccess, fnFail);
    }
}
var cgiUrl = '/cgi-bin/jsonSrvr.lua';
function sendTheseObjects(objs, fnSuccess, fnFail) {
    $("button").prop("disabled", true);
    $.post(cgiUrl, "data=" + encodeURIComponent(JSON.stringify({ setObject: objs,
        csrfToken: csrfToken,
        queryParams: queryParams })), null, "json")
        .done(function (resp) {
        receiveObjects(resp);
        if ((typeof pageData.onDataUpdate !== "undefined")) {
            pageData.onDataUpdate(resp);
        }
        if (resp.result === 0) {
            var success = "";
            if (((typeof pageData.suppressAlertTxt !== "undefined") && !pageData.suppressAlertTxt) ||
                !(typeof pageData.suppressAlertTxt !== "undefined")) {
                if ((typeof pageData.alertSuccessTxt !== "undefined")) {
                    success = (typeof pageData.alertSuccessTxt === "function") ? _(pageData.alertSuccessTxt()) : _(pageData.alertSuccessTxt);
                }
                success_alert("", success);
            }
            if ((typeof fnSuccess === "function")) {
                fnSuccess();
            }
        }
        $("button").prop("disabled", false);
    })
        .fail(function (err) {
        if ((typeof fnFail === "function")) {
            fnFail(err);
        }
        alertInvalidRequest();
        $("button").prop("disabled", false);
    });
}
function sendSingleObject(pgeObj, fnSuccess, fnFail) {
    sendTheseObjects([pgeObj.packageObj()], fnSuccess, fnFail);
}
function requestObjects(objectstoRequest, fnCallback) {
    $.getJSON(cgiUrl, "req=" + JSON.stringify({ getObject: objectstoRequest,
        csrfToken: csrfToken,
        queryParams: queryParams }))
        .done(function (resp) {
        if (resp.result === 1 && resp.text === "redirect") {
            console.log("login timer expired, redirect to " + resp.redirect_url);
            $(location).attr('href', resp.redirect_url);
        }
        fnCallback(resp);
    })
        .fail(function (err) {
        setVisible("#body", "1");
    });
}
var pollIntervals = [];
function stopPagePolls() {
    for (var _i = 0, pollIntervals_1 = pollIntervals; _i < pollIntervals_1.length; _i++) {
        var interval = pollIntervals_1[_i];
        clearInterval(interval);
    }
    pollIntervals = [];
}
function startPagePolls() {
    stopPagePolls();
    var pollPeriods = [];
    pageData.pageObjects.forEach(function (pgeObj) {
        if ((typeof pgeObj.pollPeriod !== "undefined")) {
            var period = pgeObj.pollPeriod;
            if (period == 0) {
                return;
            }
            if (!(typeof pollPeriods[period] !== "undefined"))
                pollPeriods[period] = [];
            var objNames = pollPeriods[period];
            objNames[objNames.length] = pgeObj.objName;
        }
    });
    pollPeriods.forEach(function (objNames, period) {
        pollIntervals.push(setInterval(function () { requestObjects(objNames, receiveObjects); }, period));
    });
}
var pageGenerated = false;
var objectsReceived = null;
function receiveFirstObjects(resp) {
    var _a;
    if (pageGenerated === false) {
        objectsReceived = resp;
        return;
    }
    receiveObjects(resp);
    if ((typeof pageData.onReady !== "undefined")) {
        pageData.onReady(resp);
    }
    setVisible("#body", "1");
    if ((_a = pageData.validateOnload) !== null && _a !== void 0 ? _a : true) {
        $("#form").validationEngine();
    }
    $.blockUI.defaults.css.border = "3px solid #008bc6";
    $.blockUI.defaults.css.padding = "20px 0 20px 0";
    startPagePolls();
}
$(document).ready(function () {
    genPage();
    if ((typeof pageData.showImmediate !== "undefined"))
        setVisible("#body", "1");
    pageGenerated = true;
    if (objectsReceived !== null) {
        receiveFirstObjects(objectsReceived);
        objectsReceived = null;
    }
    if ((typeof pageData.onSubmit !== "undefined")) {
        $("#form").submit(function (event) {
            return pageData.onSubmit(event);
        });
    }
});
var loginStatus;
var webserverStatus;
function statusJsonpParser(res) {
    loginStatus = res.data.loginStatus;
    webserverStatus = res.data.status;
}
function waitUntilRebootComplete(estRebootingSecs, defLanIpAddr, unknownDefLanIpAddr, clearHttpsCerti) {
    if (defLanIpAddr === void 0) { defLanIpAddr = ''; }
    if (unknownDefLanIpAddr === void 0) { unknownDefLanIpAddr = false; }
    if (clearHttpsCerti === void 0) { clearHttpsCerti = false; }
    var counter = 0;
    var redirect_counter = 0;
    var estTime = estRebootingSecs;
    var numPolls = estTime;
    var expectedStatus = "N/A";
    var indexUrl = "/index.html?lang=" + currentLanguage;
    var statusUrl = "/web_server_status";
    var statusPollUrl;
    console.log("defLanIpAddr = " + defLanIpAddr);
    if (defLanIpAddr != '') {
        indexUrl = defLanIpAddr + indexUrl;
    }
    $("#spinner").show();
    $.ajaxSetup({
        timeout: 900
    });
    var intv = setInterval(function () {
        function stopPolling() {
            clearInterval(intv);
            $.unblockUI();
            $("button").prop("disabled", false);
        }
        numPolls--;
        counter++;
        var percentage = Math.floor(100 * counter / estTime);
        if (numPolls <= 0 || percentage >= 100) {
            console.log("numPolls = " + numPolls + ", percentage = " + percentage + ", estTime = " + estTime);
            stopPolling();
            $("#rebootCt").text("");
            $("#spinner").hide();
            if (unknownDefLanIpAddr && expectedStatus == "running") {
                blockUI_alert("rebootShouldCompleteIpUnknown");
            }
            else if (clearHttpsCerti) {
                blockUI_alert("rebootShouldCompleteNewCerti");
            }
            else {
                blockUI_alert("The reboot seems to be taking too long. You may need to manually power cycle your device.");
            }
            return;
        }
        else {
            if (redirect_counter > 0) {
                $("#rebootCt").text("100 %");
            }
            else {
                $("#rebootCt").text(percentage + " %");
            }
        }
        statusPollUrl = statusUrl + "?callback=statusJsonpParser";
        $.getScript(statusPollUrl).fail(function () { webserverStatus = 'N/A'; });
        console.log("expectedStatus = " + expectedStatus + ", webserverStatus = " + webserverStatus);
        if (expectedStatus == "N/A" && expectedStatus == webserverStatus) {
            console.log("detected web server power down, waiting for rebooting now");
            expectedStatus = "running";
            if (defLanIpAddr != '') {
                statusUrl = defLanIpAddr + statusUrl;
                statusPollUrl = statusUrl + "?callback=statusJsonpParser";
            }
        }
        if ((expectedStatus == "running" && expectedStatus == webserverStatus && percentage > 50) ||
            (defLanIpAddr != '' && percentage > 80)) {
            if (redirect_counter == 0) {
                console.log("numPolls = " + numPolls + ", percentage = " + percentage + ", estTime = " + estTime);
                console.log("detected web server power up, redirect to login page after 3 seconds");
                $("#rebootMsg").text(_("rebootSuccessRedirect"));
                $("#rebootCt").text("100 %");
            }
            else if (redirect_counter > 3) {
                stopPolling();
                console.log("redirect to " + indexUrl);
                $(location).attr('href', indexUrl);
                return;
            }
            redirect_counter++;
        }
        webserverStatus = 'N/A';
    }, 1000);
}
function genRebootWaitingMsgHtml() {
    return '<div id="rebootMsg" class = "rebootMsg">' + _("Rebooting...") + '</div>' +
        '<div id="spinner" class="rebootImgDiv"><img src="/img/spinner_250.gif" class="rebootIcon">' +
        '<b id="rebootCt" class="rebootCnt">0 %</b></div>';
}
function sendRdbCommand(url, rdbPrefix, cmd, param, timeout, csrfToken, fnSuccess, retryCounter) {
    if (retryCounter === void 0) { retryCounter = 5; }
    var numPolls;
    var cmdStatus = "";
    var cmdParam = {};
    var paramJson = JSON.stringify(param);
    var retry_intv = setInterval(send_rdb_command, 1000);
    var retry_command = true;
    url = "rdb_command/" + url;
    blockUI_wait(_("GUI pleaseWait"));
    function send_rdb_command() {
        console.log("send_rdb_command: retryCounter = " + retryCounter + ", retry_commmand = " + retry_command);
        if (retryCounter <= 0) {
            clearInterval(retry_intv);
            $.unblockUI();
            blockUI_alert("This operation seems to be taking too long. You may need to try again.", function () { location.reload(); });
        }
        if (retry_command) {
            retry_command = false;
            numPolls = timeout;
            $.post(url, { rdbPrefix: rdbPrefix, cmd: cmd, param: paramJson, csrfToken: csrfToken }, function (data, status) {
                var intv = setInterval(function () {
                    function stopPolling() {
                        clearInterval(intv);
                    }
                    numPolls--;
                    if (numPolls <= 0) {
                        stopPolling();
                        console.log("numPolls <= 0");
                        retryCounter--;
                        retry_command = true;
                        return;
                    }
                    $.getJSON(url, { rdbPrefix: rdbPrefix, param: paramJson }, function (res) {
                        cmdStatus = res.data.status;
                        cmdParam = res.data.param;
                        console.log("cmdStatus = " + cmdStatus + ", cmdParam = " + cmdParam);
                        if (cmdStatus == "[done]" || cmdStatus == "[error]") {
                            clearInterval(retry_intv);
                            stopPolling();
                            if (cmdStatus == "[done]") {
                                console.log("successfully executed the RDB command");
                                fnSuccess(cmdParam);
                            }
                            else {
                                console.log("RDB command failed: [error] returned");
                                $.unblockUI();
                                blockUI_alert("The operation failed. You may need to try again.", function () { location.reload(); });
                            }
                        }
                    })
                        .fail(function () {
                        console.log("RDB command(get) failed");
                        stopPolling();
                        retryCounter--;
                        retry_command = true;
                        return;
                    });
                }, 1000);
            })
                .fail(function () {
                console.log("RDB command(post) failed");
                retryCounter--;
                retry_command = true;
            });
        }
    }
}
function saveOrRestoreSettings(mode, password, csrfToken, restoreFactory, fnDone) {
    if (restoreFactory === void 0) { restoreFactory = false; }
    blockUI_wait(_("GUI pleaseWait"));
    var url = mode == "save" ? "BackupSettings" : "RestoreSettings";
    var restoreFactoryEn = restoreFactory ? "1" : "0";
    $.post(url, { password: password, csrfToken: csrfToken, restoreFactory: restoreFactoryEn }, function (res, status) {
        if (res.result == "0") {
            console.log("res.data = " + res.data);
            if (mode == "save") {
                console.log("res.data.filename = " + res.data.filename);
                location.href = res.data.filename;
                $.unblockUI();
            }
            else if (mode == "restore" && (typeof fnDone !== "undefined")) {
                fnDone(res);
            }
        }
        else {
            $.unblockUI();
            if ((typeof fnDone !== "undefined")) {
                fnDone(res);
            }
            else {
                blockUI_alert("The operation failed. You may need to try again.");
            }
        }
        ;
    })
        .fail(function () {
        $.unblockUI();
        blockUI_alert("The operation failed. You may need to try again.");
    });
}
function convertSpecialChars(specialStringSet, originalStr) {
    var i = 0;
    var newStr = "";
    for (i = 0; i < originalStr.length; i++) {
        if (specialStringSet.indexOf(originalStr[i]) == -1)
            newStr = newStr + originalStr[i];
        else
            newStr = newStr + convert(originalStr[i]);
    }
    return newStr;
}
function sendMsg(maxTxDstIdx, currentDstTopIdx) {
    var i, dst_cnt = 0;
    clear_alert();
    if (checkDuplicatedSendList(maxTxDstIdx, currentDstTopIdx) == false)
        return;
    var mobileNoList = {};
    for (i = 0; i <= currentDstTopIdx; i++) {
        if (String($("#inp_mob_num" + i).val()).length >= 3) {
            $("#hint" + i).html("");
            mobileNoList[i + 1] = $("#inp_mob_num" + i).val();
            dst_cnt++;
        }
    }
    if (dst_cnt == 0) {
        validate_alert("", "Destination number field required");
        return;
    }
    $.blockUI({ centerY: false, css: { top: "320px" }, message: "Sending message... Please wait." });
    var txMsgBody = convertSpecialChars("<>%\\^[]`\+\$\,'#&\n\r", $("#inp_newMsg").val());
    $.post("/sendSmsMsg", "data=" + JSON.stringify({ TxMsg: txMsgBody, MobileNoList: mobileNoList }), sendMsgHandler);
}
function sendMsgHandler(resp) {
    $.unblockUI();
    var tx_result = resp.sendMsgResult;
    var i = 0;
    while ($("#inp_mob_num" + i).val() != "") {
        var id = "#hint" + i;
        $(id).html(tx_result[i]);
        if (tx_result[i] == "Failure") {
            $(id).css("color", "RED");
        }
        else {
            $(id).css("color", "Black");
            $("#inp_newMsg").val("");
        }
        i++;
    }
}
function isSameDesNumber(num1, num2, digitsToCompare) {
    var num1_len = num1.length;
    var num2_len = num2.length;
    var comp_num1 = num1;
    var comp_num2 = num2;
    if ((typeof digitsToCompare !== "undefined") && num1_len > digitsToCompare) {
        comp_num1 = num1.substr(num1_len - digitsToCompare);
    }
    if ((typeof digitsToCompare !== "undefined") && num2_len > digitsToCompare) {
        comp_num2 = num2.substr(num2_len - digitsToCompare);
    }
    return (comp_num1 == comp_num2);
}
function checkDuplicatedSendList(maxTxDstIdx, currentDstTopIdx) {
    var i, j, val;
    for (i = 0; i < maxTxDstIdx; i++) {
        val = $("#inp_mob_num" + i).val();
        if (val == '')
            continue;
        for (j = i + 1; j <= currentDstTopIdx; j++) {
            if (isSameDesNumber(val, $("#inp_mob_num" + j).val())) {
                blockUI_wait_confirm("Destination" + " " + " No" + " [" + (i + 1) + "] " + val + " " + "is duplicated with" + " " +
                    "Destination" + " " + " No" + " [" + (j + 1) + "] " + $("#inp_mob_num" + j).val() + ".\n" +
                    "Destination" + " " + " No" + " [" + (j + 1) + "]" + $("#inp_mob_num" + j).val() + " " +
                    "cancelled" + " !", _("CSok"), function () { $("#inp_mob_num" + j).val(""); $.unblockUI(); });
                return false;
            }
        }
    }
    return true;
}
function startup() {
    var welBlock = false, passBlock = false, pageBlock = false;
    function displaySel() {
        pageBlock = false;
        $.unblockUI();
        setPageObjVisible(false, "factPass");
        if ($("#selOpt0").is(":checked")) {
            setPageObjVisible(false, "RestoreFile");
        }
        else {
            setPageObjVisible(false, "newPasswords");
            setEditButtonRowVisible(false);
        }
    }
    function passValid() {
        passBlock = false;
        $.unblockUI();
        $("#inp_factoryDefaultPassword").val(String($('#pass').val()));
        $.post("/factorydefaultpasswd", JSON.stringify({ "passwd": encode($("#inp_factoryDefaultPassword").val()) }), null, "json")
            .done(function (resp) {
            if (resp.result != "0") {
                $.unblockUI();
                setTimeout(function () { blockUI_wait(_("incorrectFactoryPassword")); }, 1000);
                setTimeout(actions, 3000);
            }
            else {
                $.blockUI({ message: _("selOptionsMsg") + "                      <div style='padding:5px; margin:20px 0 0 -125px'><input type='radio' id='selOpt0' name ='selOpt' checked='checked' style='width:10px; display: flex; position:absolute; top: 30%; left:10%;'>" + _("configNewMsg") + "</div>                      <div style='padding:5px'><input type='radio' id='selOpt1' name ='selOpt' style='width:10px; display: flex; position:absolute; top: 46%; left:10%;'>" + _("restoreBackupMsg") + "</div>                      <div class='button-raw med' style='padding-top:10px'><button class='secondary med' id='button_sel'>" + _("CSok") + "</button></div>",
                    css: { width: '550px', padding: '20px 20px' }
                });
                pageBlock = true;
                $('#button_sel').click(function () {
                    displaySel();
                });
            }
        })
            .fail(function () {
            $.unblockUI();
            setTimeout(function () { blockUI_wait("Failed request."); }, 1000);
            setTimeout(actions, 3000);
        });
    }
    function actions() {
        welBlock = false;
        $.unblockUI();
        $.blockUI({ message: _("entPasswdMsg") + "</br>      <div style='padding:12px 65px'><input class='large' type='text' id='pass'></div>      <div class='button-raw med' style='padding-top:40px'><button class='secondary med' id='button_pass'>" + "Next" + "</button></div>",
            css: { width: '320px', padding: '20px 20px' }
        });
        passBlock = true;
        $('#button_pass').click(function () {
            passValid();
        });
    }
    document.addEventListener("keydown", function (keyEvent) {
        if (keyEvent.key === "Enter") {
            keyEventTrige();
        }
    });
    function keyEventTrige() {
        if (welBlock) {
            actions();
        }
        else if (passBlock) {
            passValid();
        }
        else if (pageBlock) {
            displaySel();
        }
    }
    $.blockUI({ message: _("welcomeMsg") + "<div class='button-raw med'>    <button class='secondary med' id='button_wel'>" + "Next" + "</button></div>",
        css: { width: '320px', padding: '20px 20px' }
    });
    welBlock = true;
    $('#button_wel').click(function () {
        actions();
    });
}
function _genColumnsWrapper(heading, html) {
    return htmlDiv({ "class": "box" }, htmlDiv({ "class": "box-header close h2-status" }, htmlTag("h2-status", {}, _(heading))) + htmlDiv({ "class": "row hide" }, html));
}
function _genCols(objName, columns, extra) {
    var html = "";
    columns.forEach(function (col, i) {
        var colhtml = "";
        col.members.forEach(function (mem, j) {
            if (!(typeof mem.name !== "undefined")) {
                mem.name = objName + "_" + i + "_" + j;
            }
            colhtml += htmlTag("dl", { id: mem.name + "_div" }, htmlTag("dt", {}, _(mem.hdg)) + htmlTag("dd", { id: mem.name }, ""));
        });
        var attr = { "class": "each-box" + (i === 0 ? " alpha" : "") + (i === columns.length - 1 ? " omega" : "") };
        if (i === columns.length - 1)
            attr.style = "border:none";
        html += htmlDiv(attr, ((typeof col.heading !== "undefined") ? htmlTag("h3", {}, _(col.heading)) : "") + colhtml);
    });
    return htmlDiv({ id: objName, "class": "box-content" }, html + extra);
}
function genCols() {
    return _genColumnsWrapper(this.labelText, _genCols(this.objName, this.columns, ""));
}
function _populateCols(columns, obj) {
    columns.forEach(function (col) {
        col.members.forEach(function (mem) {
            if ((typeof mem.genHtml === "function")) {
                $("#" + mem.name).html(mem.genHtml(obj));
            }
            if ((typeof mem.isVisible === "function")) {
                var vis = mem.isVisible(obj);
                if (vis === true)
                    $("#" + mem.name + "_div").show();
                if (vis === false)
                    $("#" + mem.name + "_div").hide();
            }
        });
    });
}
function populateCols() {
    _populateCols(this.columns, this.obj);
}
function _genColsStsSystemInfo(objName, columns, extra) {
    var html = "";
    columns.forEach(function (col, i) {
        var colhtml = "";
        col.members.forEach(function (mem, j) {
            if (!(typeof mem.name !== "undefined")) {
                mem.name = objName + "_" + i + "_" + j;
            }
            colhtml += htmlTag("dl", { id: mem.name + "_div", "style": "height:40px;" }, htmlTag("dt", {}, _(mem.hdg)) + htmlTag("dd", { id: mem.name }, ""));
        });
        var attr = { "class": "each-box" + (i === 0 ? " alpha" : "") + (i === columns.length - 1 ? " omega" : ""), "style": "width:420px;" };
        if (i === columns.length - 1)
            attr.style = "border:none";
        html += htmlDiv(attr, ((typeof col.heading !== "undefined") ? htmlTag(i === 0 ? "h3 style='text-align: center;'" : "h3", {}, _(col.heading)) : "") + htmlTag("div", { "style": "display:flex; flex-direction:column; flex-wrap:wrap; height: 420px" }, colhtml));
    });
    return htmlDiv({ id: objName, "class": "box-content" }, html + extra);
}
function genColsStsSystemInfo() {
    return _genColumnsWrapper(this.labelText, _genColsStsSystemInfo(this.objName, this.columns, ""));
}
function WinExpIP(field,event) {
 if( field.value=="") {
  if($(field).hasClass("required")) {
   $(field).valid();
  }
 }
 else {
  if(!isValidIpEntry(field,event))
   validate_alert( "", _("dhcp warningMsg11"));
  else
   clear_alert();
 }
}
function WinExpIP_1(field,event) {
 if( field.value=="") {
  if($(field).hasClass("required")) {
   $(field).valid();
  }
 }
 else {
  switch(isValidIpEntry_1(field,event)) {
  case -1:
   validate_alert( "", _("dhcp warningMsg12"));
  break;
  case -2:
   validate_alert( "", _("dhcp warningMsg13"));
  break;
  default:
   clear_alert();
  break;
  }
 }
}
function hostMin(ip, mask) {
 var host_array=[];
 ip_array = ip.split('.');
 mask_array = mask.split('.');
 for (i = 0; i < 4; i++) {
  host_array[i] = parseInt(ip_array[i])&parseInt(mask_array[i]);
 }
 host_array[3]++;
 return host_array.join(".");
}
function hostMax(ip, mask) {
 var host_array=[];
 var wildcard_array=[];
 ip_array = ip.split('.');
 mask_array = mask.split('.');
 for (i = 0; i < 4; i++) {
  wildcard_array[i]=~parseInt(mask_array[i])&255;
  host_array[i] = parseInt(ip_array[i])&parseInt(mask_array[i])|wildcard_array[i];
 }
 host_array[3]--;
 return host_array.join(".");
}
function checkIPrange(ipMin, ipMax, myip) {
var fromArr = ipMin.split(".");
var toArr = ipMax.split(".");
var myipArr = myip.split(".");
var fromip=0; toip=0; myip=0;
 for(i=0;i<4;i++) {
  fromip=fromip*1000+parseInt(fromArr[i]);
  toip=toip*1000+parseInt(toArr[i]);
  myip=myip*1000+parseInt(myipArr[i]);
 }
 if(myip<fromip || myip>toip) {
  return false;
 }
 return true;
}
function isWithinHostIpRange(ip, mask, myip) {
 return checkIPrange(hostMin(ip, mask), hostMax(ip, mask), myip);
}
function checkIpAddr(field, ismask, msg) {
 if (field.value == "") {
  if (ismask) {
   validate_alert( "", typeof(msg)!="undefined"?msg+_("routing warningMsg5"):_("routing warningMsg5"));
  }
  else {
   validate_alert( "", typeof(msg)!="undefined"?msg+_("warningMsg01"):_("warningMsg01"));
  }
  field.value = field.defaultValue;
  field.focus();
  return false;
 }
 if (isAllNum(field.value) == 0) {
  validate_alert( "", typeof(msg)!="undefined"?msg+_("warningMsg02"):_("warningMsg02"));
  field.value = field.defaultValue;
  field.focus();
  return false;
 }
 if (ismask) {
  if ((!checkRange(field.value, 1, 0, 256)) ||
   (!checkRange(field.value, 2, 0, 256)) ||
   (!checkRange(field.value, 3, 0, 256)) ||
   (!checkRange(field.value, 4, 0, 256)))
  {
   validate_alert( "", typeof(msg)!="undefined"?msg+_("routing warningMsg2"):_("routing warningMsg2"));
   field.value = field.defaultValue;
   field.focus();
   return false;
  }
 }
 else {
  if ((!checkRange(field.value, 1, 0, 255)) ||
   (!checkRange(field.value, 2, 0, 255)) ||
   (!checkRange(field.value, 3, 0, 255)) ||
   (!checkRange(field.value, 4, 1, 254)))
  {
   if (ismask) {
    validate_alert( "", typeof(msg)!="undefined"?msg+_("routing warningMsg2"):_("routing warningMsg2"));
   }
   else {
    validate_alert( "", typeof(msg)!="undefined"?msg+_("warningMsg03"):_("warningMsg03"));
   }
   field.value = field.defaultValue;
   field.focus();
   return false;
  }
 }
 clear_alert();
 return true;
}
function parse_ip_into_fields(ipaddr, name) {
 var i;
 var ip_array;
 ip_array=ipaddr.split(".");
 if(ip_array.length != 4 ) {ip_array[0]=''; ip_array[1]='';ip_array[2]=''; ip_array[3]='';}
 for(i=0;i<4;i++) {
  $("input[name="+name+(i+1)+"]").val(ip_array[i]||"");
 }
}
function parse_ip_mask_into_fields(ipaddr_mask, name) {
        var i;
        var ip_array;
        var ip_mask_array;
        ip_mask_array=ipaddr_mask.split("/");
        ip_array=ip_mask_array[0].split(".");
        if(ip_array.length != 4 ) {ip_array[0]=''; ip_array[1]='';ip_array[2]=''; ip_array[3]='';}
        for(i=0;i<4;i++) {
                $("input[name="+name+(i+1)+"]").val(ip_array[i]||"");
        }
        $("input[name="+name+"5]").val(ip_mask_array[1]||"");
}
function parse_ip_from_fields(documentItem) {
 var ip_array=[];
 var val;
 var j=0;
 for(var i=0;i<4;i++) {
  val=$("input[name="+documentItem+(i+1)+"]").val();
  if(val!="") {
   ip_array[j++]=val;
  }
  else {
   return "";
  }
 }
 return ip_array.join(".");
}
function parse_ip_mask_from_fields(documentItem) {
        var ip_array=[];
        var val;
        var j=0;
        var mask_val;
        for(var i=0;i<4;i++) {
                val=$("input[name="+documentItem+(i+1)+"]").val();
                if(val!="") {
                        ip_array[j++]=val;
                }
                else {
                        return "";
                }
        }
        mask_val=$("input[name="+documentItem+"5]").val();
        return ip_array.join(".")+"/"+mask_val;
}
function ValidSubnetMask(n, t){
 NumfieldEntry(t);
 if(isValidSubnetMask(parse_ip_from_fields(n))<0) {
  for(i=0;i<4;i++) {
   $("input[name="+n+(i+1)+"]").removeClass("success-text").addClass("failure-text");
  }
 }
 else {
  for(i=0;i<4;i++) {
   $("input[name="+n+(i+1)+"]").removeClass("failure-text").addClass("success-text");
  }
 }
}
function _genHtmlIpBlocks(name, classes, onKeyUp) {
 var html = "";
 if(!(typeof onKeyUp !== "undefined")) onKeyUp = "NumfieldEntry(this);";
 [".",".",".",""].forEach(function(dot, i) {
  var id = name + (i+1);
  var inputAttribs = {type:'text', class: classes[i] +" ip-adress", maxLength: 3, name: id, id: id, onkeyup: onKeyUp, onchange: "validate_group('" + name + "')"};
  html += htmlDiv( {class:'field'}, htmlTag("input", inputAttribs, "")) + htmlTag("label", {for: id, class:'input-connect-dot'}, dot);
 });
 return html;
}
function _genHtmlIpAndMaskBlocks(name, classes, maskClass, onKeyUp) {
 var html = "";
 if(!(typeof onKeyUp !== "undefined")) onKeyUp = "NumfieldEntry(this);";
 [".",".",".",""].forEach(function(dot, i) {
  var id = name + (i+1);
  var inputAttribs = {type:'text', class: classes[i] +" ip-adress", maxLength: 3, name: id, id: id, onkeyup: onKeyUp, onchange: "validate_group('" + name + "')"};
  html += htmlDiv( {class:'field'}, htmlTag("input", inputAttribs, "")) + htmlTag("label", {for: id, class:'input-connect-dot'}, dot);
 });
        var inputMask = {type:'text', class: maskClass +" ip-adress", maxLength: 3, name: name + '5', id: name + '5', onkeyup: onKeyUp, onchange: "validate_group('" + name + "')"};
        html += htmlTag("label", {for: name + '5', class:'input-connect-dot'}, "&nbsp;/&nbsp;");
        html += htmlDiv( {class:'field'}, htmlTag("input", inputMask, ""));
 return html;
}
function getValidateStr(parm, func) {return "validate[" + parm + ",funcCall[" + func + "]]";}
function getRequiredValidateStr(func) {return getValidateStr("required", func);}
function getWithoutRequiredValidateStr(func) {return getValidateStr("", func);}
function genHtmlIpAndMaskBlocks(n) {
 var val = getRequiredValidateStr("validate_ip_0");
        var maskClass = getRequiredValidateStr("validate_mask");
 return _genHtmlIpAndMaskBlocks(n, [val, val, val, val], maskClass);
}
function genHtmlIpBlocks(n) {
 var val1 = getRequiredValidateStr("validate_ip_1");
 var valx = getRequiredValidateStr("validate_ip");
 return _genHtmlIpBlocks(n, [val1, valx, valx, valx]);
}
function genHtmlIpBlocks0(n) {
 var val = getRequiredValidateStr("validate_ip_0");
 return _genHtmlIpBlocks(n, [val, val, val, val]);
}
function genHtmlIpBlocks127(n) {
 var val1 = getRequiredValidateStr("validate_ip_127");
 var valx = getRequiredValidateStr("validate_ip");
 return _genHtmlIpBlocks(n, [val1, valx, valx, valx]);
}
function genHtmlMaskBlocks(n) {
 var valx = "success-text " + getRequiredValidateStr("validate_netmask");
 return _genHtmlIpBlocks(n, [valx, valx, valx, valx], "ValidSubnetMask('" + n + "',this)");
}
function genHtmlMaskBlocksWithoutRequired(n) {
 var valx = getWithoutRequiredValidateStr("validate_netmask");
 return _genHtmlIpBlocks(n, [valx, valx, valx, valx]);
}
function getcondRequired(n) {
 return "condRequired[" + n + "1," + n + "2," + n + "3," + n + "4]";
}
function genHtmlIpBlocksWithoutRequired(n) {
 var condRequired = getcondRequired(n);
 var val1 = "validate[" + condRequired + ",funcCall[validate_ip_1]]";
 var valx = "validate[" + condRequired + ",funcCall[validate_ip]]";
 return _genHtmlIpBlocks(n, [val1, valx, valx, valx]);
}
function genHtmlIpBlocksWithoutRequired0(n) {
 var valx = "validate[" + getcondRequired(n) + ",funcCall[validate_ip_0]]";
 return _genHtmlIpBlocks(n, [valx, valx, valx, valx]);
}
function clear_ip_group(group) {
 for(var i=4; i>=1; i--) {
  $("#"+group+i).val("");
 }
}
function validate_group( group ) {
 var err_counter=0;
 for(var i=4; i>=1; i--) {
  if($("#"+group+i).validationEngine("validate")) {
   if($("#"+group+i).val()!="") {
    err_counter++;
    for(var j=i+1; j<=4; j++) {
     $("#"+group+j).validationEngine("hide");
    }
   }
   else if(err_counter++) {
    $("#"+group+i).validationEngine("hide");
   }
  }
 }
 return err_counter;
}
function validate_ip_1(field, rules, i, options) {
 if(isNValidIP(field.val()) || field.val() <1 || field.val() >223) {
  field.value="192";
  return _("ip warningMsg1");
 }
 else if(field.val()==127) {
  field.value="192";
  return _("dhcp warningMsg13");
 }
 field.val(parseInt(field.val()));
 return true;
}
function validate_ip_127(field, rules, i, options) {
 if(isNValidIP(field.val()) || field.val() <1 || field.val() >223) {
  field.value="192";
  return _("ip warningMsg1");
 }
 field.val(parseInt(field.val()));
 return true;
}
function validate_ip_0(field, rules, i, options) {
 if(isNValidIP(field.val())) {
  return _("ip warningMsg3");
 }
 field.val(parseInt(field.val()));
 return true;
}
function validate_mask(field, rules, i, options) {
 if(isNValidMask(field.val())) {
  return _("ip warningMsg4");
 }
 field.val(parseInt(field.val()));
 return true;
}
function validate_ip(field, rules, i, options) {
 if(isNValidIP(field.val())) {
  return _("ip warningMsg2");
 }
 field.val(parseInt(field.val()));
 return true;
}
function validate_netmask(field, rules, i, options) {
 if(isNValidIP(field.val())) {
  return _("ip warningMsg3");
 }
 field.val(parseInt(field.val()));
 return true;
}
function ip_to_decimal(addr) {
 var deci;
 deci = parseInt(addr[0])*16777216 + parseInt(addr[1])*65536 + parseInt(addr[2])*256 + parseInt(addr[3]);
 return deci;
}
function decimal_to_ip(deci) {
 var addr = [];
 deci_int = deci - (deci % 16777216);
 addr[0] = deci_int / 16777216;
 addr[1] = (deci & 0x00ff0000) >> 16;
 addr[2] = (deci & 0x0000ff00) >> 8;
 addr[3] = deci & 0x000000ff;
 return addr;
}
function is_large(addr1, addr2) {
 var gap;
 gap = ip_to_decimal(addr1) - ip_to_decimal(addr2);
 if (gap >=0 )
  return 1;
 else
  return 0;
}
function ip_gap(addr1, addr2) {
 var gap;
 if (is_large(addr1, addr2))
  gap = ip_to_decimal(addr1) - ip_to_decimal(addr2);
 else
  gap = ip_to_decimal(addr2) - ip_to_decimal(addr1);
 return gap;
}
function subnetID(ip, mask) {
 var host_array=[];
 ip_array = ip.split('.');
 mask_array = mask.split('.');
 for (i = 0; i < 4; i++) {
  host_array[i] = parseInt(ip_array[i])&parseInt(mask_array[i]);
 }
 return host_array.join(".");
}
function broadcastIP(ip, mask) {
 var host_array=[];
 var wildcard_array=[];
 ip_array = ip.split('.');
 mask_array = mask.split('.');
 for (i = 0; i < 4; i++) {
  wildcard_array[i]=~parseInt(mask_array[i])&255;
  host_array[i] = parseInt(ip_array[i])&parseInt(mask_array[i])|wildcard_array[i];
 }
 return host_array.join(".");
}
function totalSubnet(mask) {
var sum=0;
 mask_array = mask.split('.');
 for (i = 0; i < 4; i++) {
  sum=sum*256+(~parseInt(mask_array[i])&255);
 }
 return sum-1;
}
function netInfo() {
 clear_alert();
 $("#lan_addr").val(parse_ip_from_fields("lan_addr"));
 $("#mask").val(parse_ip_from_fields("mask"));
 switch(isValidSubnetMask($("#mask").val())) {
  case -1:
   validate_alert("",_("invalidSubnetMask"));
   return;
  break;
  case -2:
   validate_alert("",_("wlan warningMsg16"));
   return;
  break;
 }
 if(!isValidIpAddress($("#lan_addr").val())) {
  validate_alert("",_("warningMsg05"));
  return;
 }
 var msg="<div class='message_box' style='text-align:left;'>"+_("subnetID")+subnetID($("#lan_addr").val(), $("#mask").val())+" / "+maskBits($("#mask").val()) +"<br/>"+_("broadcastAddress")+broadcastIP($("#lan_addr").val(), $("#mask").val()) +"<br/>"+_("subnetIpRange")+hostMin($("#lan_addr").val(), $("#mask").val())+"-"+hostMax($("#lan_addr").val(), $("#mask").val()) +"<br/>"+_("hostsPerSubnet")+totalSubnet($("#mask").val()) +"<br/></div><div style='margin-left:180px'><button class='secondary mini' onClick='$.unblockUI();'>"+_("CSok")+"</button><div/>";
 $.blockUI({message:msg});
 return;
}
function validate_dms_lati_d(field, rules, i, options) {
    if( field.val() < 0 || field.val() > 90) {
        return _("warningforDMSLatiDeg");
    }
}
function validate_dms_long_d(field, rules, i, options) {
    if( field.val() < 0 || field.val() > 180) {
        return _("warningforDMSLongDeg");
    }
}
function validate_dms_ms(field, rules, i, options) {
    if( field.val() < 0 || field.val() >= 60) {
        return _("warningforDMSMinSec");
    }
}
function DDfieldEntry(field) {
    field.value=field.value.replace(/[^\+\-\.0-9]+/g, "");
    field.value=field.value.substring(0,1).concat(field.value.substring(1).replace(/[^\.0-9]+/g, ""));
    var idx = field.value.indexOf(".");
    if (idx > 0)
        field.value=field.value.substring(0,idx+1).concat(field.value.substring(idx,idx+7).replace(/[^0-9]+/g, ""));
    else if (idx == 0)
        field.value=field.value.substring(1);
}
function DMSecondfieldEntry(field) {
    field.value=field.value.replace(/[^\.0-9]+/g, "");
    var idx = field.value.indexOf(".");
    if (idx > 0)
        field.value=field.value.substring(0,idx+1).concat(field.value.substring(idx,idx+7).replace(/[^0-9]+/g, ""));
    else if (idx == 0)
        field.value=field.value.substring(1);
}
function genHtmlDmsBlocks(name, label) {
    var html = "";
    if (label == "Latitude") {
        html += htmlTag("input", {
                    type: "text", id: name + "_d",
                    class: "validate[required,funcCall[validate_dms_lati_d]] required",
                    maxLength: "2", size: "2"}) +
                htmlTag("label", {class: "input-connect-dot"}, "&deg");
    } else {
        html += htmlTag("input", {
            type: "text", id: name + "_d",
            class: "validate[required,funcCall[validate_dms_long_d]] required",
            maxLength: "3", size: "3"}) +
        htmlTag("label", {class: "input-connect-dot"}, "&deg");
    }
    html += htmlTag("input", {
                type: "text", id: name + "_m",
                class: "validate[required,funcCall[validate_dms_ms]] required",
                maxLength: "2", size: "2"}) +
            htmlTag("label", {class: "input-connect-dot"}, "'");
    html += htmlTag("input", {
                type: "text", id: name + "_s",
                class: "validate[required,funcCall[validate_dms_ms]] required",
                onkeyup: "DMSecondfieldEntry(this);",
                maxLength: "7", size: "7"}) +
            htmlTag("label", {class: "input-connect-dot"}, '"');
    var attr = {id: name + "_dir", class: "sml", size: "1"};
    html += htmlTag("span",{class: "custom-dropdown"},
                htmlTag("select", attr,
                    htmlTag("option", {value: "+"},
                        htmlTag("label", "", label == "Latitude"? "N":"E")) +
                    htmlTag("option", {value: "-"},
                        htmlTag("label", "", label == "Latitude"? "S":"W"))));
    return html;
}
if ( (typeof(util_js_included) == "undefined") || util_js_included == false )
{
 var util_js_included = true;
function isDigit(digit) {
 return (digit >= '0' && digit <= '9');
}
function isHexaDigit(digit) {
 return (digit >= '0' && digit <= '9') || (digit >= 'a' && digit <= 'f') || (digit >= 'A' && digit <= 'F');
}
function isValidKey(val, size) {
var ret = false;
var len = val.length;
var dbSize = size * 2;
 if ( len == size )
  ret = true;
 else if ( len == dbSize ) {
  for ( i = 0; i < dbSize; i++ )
   if ( isHexaDigit(val.charAt(i)) == false )
    break;
  if ( i == dbSize )
   ret = true;
 } else
  ret = false;
 return ret;
}
function isValidHexKey(val, size) {
var ret = false;
 if (val.length == size) {
  for ( i = 0; i < val.length; i++ ) {
   if ( isHexaDigit(val.charAt(i)) == false ) {
    break;
   }
  }
  if ( i == val.length ) {
   ret = true;
  }
 }
 return ret;
}
function filterUsingFn(field, unsafefn ) {
var i = 0;
 for ( i = 0; i < field.value.length; i++ ) {
  if ( unsafefn(field.value.charAt(i)) == true ) {
   field.value=field.value.replace(field.value.charAt(i), '');
   i--;
  }
 }
}
function nameFilter(field) {
 filterUsingFn( field, isNameUnsafe );
}
function userNameFilter(field) {
 filterUsingFn( field, isUserNameUnsafe );
}
function emailFilter(field) {
 filterUsingFn( field, isEmailUnsafe );
}
function nameFilterWSpace(field) {
 filterUsingFn( field, isCharUnsafe );
}
function macAddrFilter(field) {
 filterUsingFn( field, isMacAddrUnsafe );
}
function isMacAddrUnsafe(compareChar) {
 if (isValidHexKey(compareChar, 1))
  return false;
 return compareChar != ":";
}
function hostNameFilter(field) {
 filterUsingFn( field, isHostNameUnsafe );
}
function isHostNameUnsafe(compareChar) {
 var charCode = compareChar.charCodeAt(0);
 if ( charCode >=48 && charCode <= 57 )
  return false;
 if ( charCode >=65 && charCode <= 90 )
  return false;
 if ( charCode >=97 && charCode <= 122 )
  return false;
 if ( charCode == 95 || charCode == 46 || charCode == 45 )
  return false;
 return true;
}
function hostNameIpFilter(field) {
 filterUsingFn(field, isHostNameIpUnsafe);
}
function isHostNameIpUnsafe(compareChar) {
 let res = isHostNameUnsafe(compareChar);
 if (!res) {
  return false;
 }
 return compareChar != ":";
}
function urlFilter(field) {
 filterUsingFn( field, isURLUnsafe );
}
function isURLUnsafe(compareChar) {
 var patt=/[^a-zA-Z0-9-._~!*'();:@&=+$,\/?#\[\]]/
 return patt.test(compareChar);
}
function ssidFilter(field) {
 filterUsingFn( field, isSSIDUnsafe );
}
function isSSIDUnsafe(compareChar) {
 var unsafeString = "\"\t\\$";
 if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) >= 32
  && compareChar.charCodeAt(0) < 123 )
  return false;
 return true;
}
function isNameUnsafe(compareChar) {
var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.:\t";
 if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
   && compareChar.charCodeAt(0) < 123 ) {
  return false;
 }
 return true;
}
function isUserNameUnsafe(compareChar) {
var unsafeString = "\"<>%\\^[]`\+\$\,='#&:\t";
 if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
   && compareChar.charCodeAt(0) < 123 ) {
  return false;
 }
 return true;
}
function isEmailUnsafe(compareChar) {
var unsafeString = "\"<>%\\^[]`\+\$\,='#&:\t";
 if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
   && compareChar.charCodeAt(0) < 123 ) {
  return false;
 }
 return true;
}
function isValidName(name) {
var i = 0;
 for ( i = 0; i < name.length; i++ ) {
  if ( isNameUnsafe(name.charAt(i)) == true )
   return false;
 }
 return true;
}
function isCharUnsafe(compareChar) {
var unsafeString = "\"<>%\\^[]`\+\$\,='#&@.:\t";
 if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) >= 32
  && compareChar.charCodeAt(0) < 123 )
  return false;
 return true;
}
function isValidNameWSpace(name) {
var i = 0;
 for ( i = 0; i < name.length; i++ ) {
  if ( isCharUnsafe(name.charAt(i)) == true )
   return false;
 }
 return true;
}
function isSameSubNet(lan1Ip, lan1Mask, lan2Ip, lan2Mask) {
var count = 0;
 lan1a = lan1Ip.split('.');
 lan1m = lan1Mask.split('.');
 lan2a = lan2Ip.split('.');
 lan2m = lan2Mask.split('.');
 for (i = 0; i < 4; i++) {
  l1a_n = parseInt(lan1a[i]);
  l1m_n = parseInt(lan1m[i]);
  l2a_n = parseInt(lan2a[i]);
  l2m_n = parseInt(lan2m[i]);
  if ((l1a_n & l1m_n) == (l2a_n & l2m_n))
   count++;
 }
 if (count == 4)
  return true;
 return false;
}
function KeyCode(e) {
 if(e&&e.which){
  e=e;
  return(e.which);
 }
 e=event;
 return(e.keyCode);
}
function isBlank(s) {
 for (i=0;i<s.length;i++) {
  c=s.charAt(i);
  if ((c!=' ') && (c!='\n') && (c!='\t'))
   return false;
 }
 return true;
}
function isNValidIP(s) {
 if((isBlank(s))||(isNaN(s))||(s<0||s>255))
  return true;
 return false;
}
function isNValidMask(s) {
 if((isBlank(s))||(isNaN(s))||(s<0||s>32))
  return true;
 return false;
}
function IPfieldEntry(field) {
 if(isNaN(field.value.charAt(field.value.length-1))&&field.value.charAt(field.value.length-1)!='.')
  field.value=field.value.slice(0,field.value.length-1);
 field.value=parseInt(field.value);
}
function SignedNumfieldEntry(field) {
  field.value=field.value.replace(/(?!^)-/g, "").replace(/[^-0-9]+/g, "");
}
function NumfieldEntry(field) {
 field.value=field.value.replace(/[^0-9]+/g, "");
}
function SignedFloatNumfieldEntry(field) {
    field.value=field.value.replace(/(?!^)-/g, "").replace(/[^-0-9.]+/g, "");
}
function FloatNumfieldEntry(field) {
 field.value=field.value.replace(/[^0-9.]+/g, "");
}
function lastEntryChar(field,spchar) {
 if(field.value.charAt(field.value.length-1)==spchar) {
  field.value=field.value.slice(0,field.value.length-1);
  if(field.value.length)
   return(1);
 }
 return(0);
}
function isValidIpEntry(field,e) {
  IPfieldEntry(field);
  if(lastEntryChar(field,' '))
   field.value=field.value.substring(0,field.value.length);
  if(lastEntryChar(field,'.')||field.value.length==3) {
   if(isNValidIP(field.value)) {
    field.value="255";
    field.select();
    return false;
   }
   else if(field.value.length<3)
    focusOnNext(field);
  }
 return true;
}
function isValidIpEntry_1(field,e) {
  IPfieldEntry(field);
  if(lastEntryChar(field,' '))
   field.value=field.value.substring(0,field.value.length);
   if(lastEntryChar(field,'.')||field.value.length==3) {
    if(isNValidIP(field.value) || field.value <1 || field.value >223) {
     field.value="192";
     field.select();
     return -1;
    }
   else if(field.value==127) {
    field.value="192";
    field.select();
    return -2;
   }
   else if(field.value.length<3)
    focusOnNext(field);
  }
 return 1;
}
function is_valid_domain_name(addr) {
 var valid=false;
 $.each(addr.split("."),function(i,v){
  valid=v.match(/^[a-zA-Z]([a-zA-Z0-9\\-]*[a-zA-Z0-9]$|[a-zA-Z0-9]*$)/)!=null;
  return valid;
 });
 return valid;
}
function isDomainNameFormat(addr) {
 addrParts = addr.split('.');
 return ( addrParts.length != 4 || isNaN(addrParts[0]) || isNaN(addrParts[1]) ||
    isNaN(addrParts[2]) || isNaN(addrParts[3]) );
}
function isValidIpAddress(address) {
var i = 0;
 if ( address == '0.0.0.0' || address == '255.255.255.255' )
  return false;
 addrParts = address.split('.');
 if ( addrParts.length != 4 ) return false;
 for (i = 0; i < 4; i++) {
  if (isNaN(addrParts[i]) || addrParts[i] =="")
   return false;
  num = parseInt(addrParts[i]);
  if ( num < 0 || num > 255 )
   return false;
 }
 return true;
}
function isValidIpAddress0(address) {
var i = 0;
 if ( address == '255.255.255.255' )
  return false;
 addrParts = address.split('.');
 if ( addrParts.length != 4 ) return false;
 for (i = 0; i < 4; i++) {
  if (isNaN(addrParts[i]) || addrParts[i] =="")
   return false;
  num = parseInt(addrParts[i]);
  if ( num < 0 || num > 255 )
   return false;
 }
 return true;
}
function isValidIpv6Address(addr) {
var ipv6RegexpPattern=/^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/
 return ipv6RegexpPattern.test(addr);
}
function getLeftMostZeroBitPos(num) {
var i = 0;
var numArr = [128, 64, 32, 16, 8, 4, 2, 1];
 for ( i = 0; i < numArr.length; i++ )
  if ( (num & numArr[i]) == 0 )
   return i;
 return numArr.length;
}
function getRightMostOneBitPos(num) {
var i = 0;
var numArr = [1, 2, 4, 8, 16, 32, 64, 128];
 for ( i = 0; i < numArr.length; i++ )
  if ( ((num & numArr[i]) >> i) == 1 )
   return (numArr.length - i - 1);
 return -1;
}
function printf(fmt) {
var reg = /%s/;
var result = new String(fmt);
 for (var i = 1; i < arguments.length; i++)
  result = result.replace(reg, new String(arguments[i]));
 document.write(result);
}
function isValidSubnetMask(mask) {
var correct_range = {128:1,192:1,224:1,240:1,248:1,252:1,254:1,255:1,0:1};
var m = mask.split('.');
 for (var i = 0; i <= 3; i ++) {
  if (!(m[i] in correct_range)) {
   return -2;
  }
 }
 if (m.length!=4 || (m[0] != 255 && m[1] != 0) || (m[1] != 255 && m[2] != 0) || (m[2] != 255 && m[3] != 0)) {
  return -1;
 }
 return 1;
}
function isValidPort(port) {
var fromport = 0;
var toport = 100;
 portrange = port.split(':');
 if ( portrange.length < 1 || portrange.length > 2 ) {
  return false;
 }
 if ( isNaN(portrange[0]) )
  return false;
 fromport = parseInt(portrange[0]);
 if ( portrange.length > 1 ) {
  if ( isNaN(portrange[1]) )
   return false;
  toport = parseInt(portrange[1]);
  if ( toport <= fromport )
   return false;
 }
 if ( fromport < 1 || fromport > 65535 || toport < 1 || toport > 65535 )
  return false;
 return true;
}
function isValidNatPort(port) {
var fromport = 0;
var toport = 100;
 portrange = port.split('-');
 if ( portrange.length < 1 || portrange.length > 2 ) {
  return false;
 }
 if ( isNaN(portrange[0]) )
  return false;
 fromport = parseInt(portrange[0]);
 if ( portrange.length > 1 ) {
  if ( isNaN(portrange[1]) )
   return false;
  toport = parseInt(portrange[1]);
  if ( toport <= fromport )
   return false;
 }
 if ( fromport < 1 || fromport > 65535 || toport < 1 || toport > 65535 )
  return false;
 return true;
}
function isValidMacAddress(address) {
var c = '';
var i = 0, j = 0;
 address = address.replace(/\s+$/g,'');
 if ( address == 'ff:ff:ff:ff:ff:ff' ) return false;
 addrParts = address.split(':');
 if ( addrParts.length != 6 ) return false;
 for (i = 0; i < 6; i++) {
  if ( addrParts[i].length!=2 )
   return false;
  for ( j = 0; j < addrParts[i].length; j++ ) {
   c = addrParts[i].toLowerCase().charAt(j);
   if ( (c >= '0' && c <= '9') ||
    (c >= 'a' && c <= 'f') )
    continue;
   else
    return false;
  }
 }
 return true;
}
function maskBits(mask) {
 var bits=0;
 mask_array = mask.split('.');
 for (i = 0; i < 4; i++) {
  bits+=parseInt(mask_array[i]).toString(2).replace(/0/g, "").length;
 }
 return bits;
}
var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
              "A", "B", "C", "D", "E", "F");
var unsafeString = "\"<>%\\^[]`\+\$\,'#&";
function isUnsafe(compareChar) {
 if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
   && compareChar.charCodeAt(0) < 123 )
  return false;
 return true;
}
function decToHex(num, radix) {
var hexString = "";
 while ( num >= radix ) {
  temp = num % radix;
  num = Math.floor(num / radix);
  hexString += hexVals[temp];
 }
 hexString += hexVals[num];
 return reversal(hexString);
}
function reversal(s) {
var len = s.length;
var trans = "";
 for (i = 0; i < len; i++)
  trans = trans + s.substring(len-i-1, len-i);
 s = trans;
 return s;
}
function convert(val) {
var hstr = decToHex(val.charCodeAt(0), 16);
 if (hstr.length > 1)
  return "%" + hstr;
 else if (hstr.length > 0)
  return "%0" + hstr;
}
function encodeUrl(val) {
var len = val.length;
var i = 0;
var newStr = "";
var original = val;
 for ( i = 0; i < len; i++ ) {
  if ( val.substring(i,i+1).charCodeAt(0) < 255 ) {
   if (isUnsafe(val.substring(i,i+1)) == false)
    newStr = newStr + val.substring(i,i+1);
   else
    newStr = newStr + convert(val.substring(i,i+1));
  } else {
   validate_alert ( "", "Found a non-ISO-8859-1 character at position: " + (i+1) + ",\nPlease eliminate before continuing.");
   newStr = original;
   i = len;
  }
 }
 return newStr;
}
function convertCharToAscii(val) {
    var pad = "00";
    var hstr = val.charCodeAt(0).toString(16);
    hstr = pad.substring(0, pad.length - hstr.length) + hstr;
    return "\\x" + hstr;
}
function convertCharToEntity(val) {
    var pad = "00";
    var hstr = val.charCodeAt(0).toString();
    hstr = pad.substring(0, pad.length - hstr.length) + hstr;
    return "&#" + hstr + ";";
}
function specialCharEscape(val, method, esc_chars) {
    var len = val.length;
    var i = 0;
    var newStr = "";
    if (typeof method === 'undefined') {
        method = 'e';
    }
    if (typeof esc_chars === 'undefined') {
        esc_chars = method == 'e' ? "\"'&<>" : "\"'\\";
    }
    for ( i = 0; i < len; i++ ) {
        var nextChar = val.substring(i,i+1);
        if (esc_chars.indexOf(nextChar) == -1) {
            newStr = newStr + nextChar;
        } else {
            newStr = newStr + (method == 'e' ? convertCharToEntity(nextChar) :
                                               convertCharToAscii(nextChar));
        }
    }
    return newStr;
}
function hex2a (hexx)
{
    var hex = hexx.toString();
    var str = '';
    for (var ix = 0; ix < hex.length; ix += 2) {
        str += String.fromCharCode(parseInt(hex.substr(ix, 2), 16));
    }
    return str;
}
function percent_decode (str)
{
    var percent_index;
    var search_index = 0;
    var result_str = '';
    var hex;
    percent_index = str.indexOf("%", search_index);
    while (percent_index != -1) {
        hex = str.slice(percent_index + 1, percent_index + 3);
        result_str += str.slice(search_index, percent_index) + hex2a(hex);
        search_index = percent_index + 3;
        percent_index = str.indexOf("%", search_index);
    }
    result_str += str.slice(search_index);
    return result_str;
}
var markStrChars = "\"'";
function isMarkStrChar(compareChar) {
 if ( markStrChars.indexOf(compareChar) == -1 )
  return false;
 return true;
}
function processMarkStrChars(str) {
var i = 0;
var retStr = '';
 for ( i = 0; i < str.length; i++ ) {
  if ( isMarkStrChar(str.charAt(i)) == true )
   retStr += '\\';
  retStr += str.charAt(i);
 }
 return retStr;
}
function showhide(element, sh) {
var status;
 if (document.getElementById) {
  if (sh == 1)
   status = "";
  else
   status = "none"
  document.getElementById(element).style.display = status;
 }
 else if (document.all) {
  if (sh == 1)
   status = "block";
  else
   status = "none"
  document.all[element].style.display = status;
 }
 else if (document.layers) {
  if (sh == 1)
   status = "block";
  else
   status = "none"
  document.layers[element].display = status;
 }
}
function getSelect(item) {
var idx;
 if (item.options.length > 0) {
     idx = item.selectedIndex;
     return item.options[idx].value;
 }
 return '';
}
function setSelect(item, value) {
 for (i=0; i<item.options.length; i++) {
  if (item.options[i].value == value) {
   item.selectedIndex = i;
   break;
  }
 }
}
function setCheck(item, value) {
 if ( value == '1' )
  item.checked = true;
 else
  item.checked = false;
}
function setDisable(item, value) {
 if ( value == 1 || value == '1' )
  item.disabled = true;
 else
  item.disabled = false;
}
function submitText(item) {
 return '&' + item.name + '=' + item.value;
}
function submitSelect(item) {
 return '&' + item.name + '=' + getSelect(item);
}
function submitCheck(item) {
var val;
 if (item.checked == true) {
  val = 1;
 }
 else {
  val = 0;
 }
 return '&' + item.name + '=' + val;
}
function HostDate() {
    var currentTime = new Date();
    var seconds = currentTime.getUTCSeconds();
    var minutes = currentTime.getUTCMinutes();
    var hours = currentTime.getUTCHours();
    var month = currentTime.getUTCMonth() + 1;
    var day = currentTime.getUTCDate();
    var year = currentTime.getFullYear();
    var seconds_str = " ";
    var minutes_str = " ";
    var hours_str = " ";
    var month_str = " ";
    var day_str = " ";
    var year_str = " ";
 if(seconds < 10)
  seconds_str = "0" + seconds;
 else
  seconds_str = ""+seconds;
 if(minutes < 10)
  minutes_str = "0" + minutes;
 else
  minutes_str = ""+minutes;
 if(hours < 10)
  hours_str = "0" + hours;
 else
  hours_str = ""+hours;
 if(month < 10)
  month_str = "0" + month;
 else
  month_str = ""+month;
 if(day < 10)
  day_str = "0" + day;
 else
  day_str = day;
 return year+"."+month_str+"."+day_str+"-"+hours_str+":"+minutes_str;
}
function f_filterResults(n_win, n_docel, n_body) {
var n_result = n_win ? n_win : 0;
 if (n_docel && (!n_result || (n_result > n_docel)))
  n_result = n_docel;
 return n_body && (!n_result || (n_result > n_body)) ? n_body : n_result;
}
function f_clientWidth() {
 return f_filterResults (
  window.innerWidth ? window.innerWidth : 0,
  document.documentElement ? document.documentElement.clientWidth : 0,
  document.body ? document.body.clientWidth : 0
 );
}
var pre_wwidth = 0;
var left;
var currentLeft;
var top;
var currentTop;
function init_moveGUI() {
 var wwidth = f_clientWidth();
 if(wwidth>1024) {
  left = currentLeft = 558;
  top = currentTop = 110;
  document.getElementById( "banner" ).style['display']='';
 }
 else if(wwidth>666) {
  left = currentLeft = wwidth-460;
  top = currentTop = 110;
  document.getElementById( "banner" ).style['display']='';
 }
 else {
  left = currentLeft = 20;
  top = currentTop = 20;
  document.getElementById( "banner" ).style['display']='none';
 }
 document.getElementById( "basicGUI" ).style['left']=currentLeft+'px';
 document.getElementById( "basicGUI" ).style['top']=currentTop+'px';
}
function moveGUI() {
 var wwidth = f_clientWidth();
 if( Math.abs(wwidth - pre_wwidth)>20 ) {
  pre_wwidth = wwidth;
  if(wwidth>1024) {
   left=558;
   top=110;
   document.getElementById( "banner" ).style['display']='';
  }
  else if(wwidth>666) {
   left=wwidth-460;
   top=110;
   document.getElementById( "banner" ).style['display']='';
  }
  else {
   left=20;
   top=20;
   document.getElementById( "banner" ).style['display']='none';
  }
 }
 diff=Math.abs( currentLeft-left );
 if( diff>=2 ) {
  if( currentLeft<left )
   currentLeft=currentLeft+diff/2;
  else if( currentLeft>left )
   currentLeft=currentLeft-diff/2;
  document.getElementById( "basicGUI" ).style['left']=currentLeft+'px';
 }
 diff=Math.abs( currentTop-top );
 if( diff>=2 ) {
  if( currentTop<top )
   currentTop=currentTop+diff/2;
  else if( currentTop>top )
   currentTop=currentTop-diff/2;
  document.getElementById( "basicGUI" ).style['top']=currentTop+'px';
 }
}
function toAdvV(url) {
 $('#basicGUI').animate({
 opacity: 0.25,
 left: '+=50',
 height: 'toggle'
 }, 1000, function() {
   location.href=url;
 });
}
function IpCheck(IP1,IP2,IP3,IP4) {
 if (((isBlank(IP1))||(isNaN(IP1))||(IP1<0||IP1>255))||((isBlank(IP2))||(isNaN(IP2))||(IP2<0||IP2>255))||((isBlank(IP3))||(isNaN(IP3))||(IP3<0||IP3>255)) || ((isBlank(IP4))||(isNaN(IP4))||(IP4<0||IP4>255)))
  return false;
 return true;
}
function sprintf(fmt) {
 var reg = /%s/;
 var result = new String(fmt);
 for (var i = 1; i < arguments.length; i++) {
  result = result.replace(reg, new String(arguments[i]));
 }
 return result;
}
function isValidNameEntry(field,e) {
 if(KeyCode(e)!=9){
  if(isCharUnsafe(field.value.charAt(field.value.length-1))) {
   field.value=field.value.slice(0,field.value.length-1);
   return false;
  }
 }
 return true;
}
function atoi(str, num) {
i=1;
 if(num != 1 ) {
  while (i != num && str.length != 0){
   if(str.charAt(0) == '.'){
    i++;
   }
   str = str.substring(1);
  }
  if(i != num )
   return -1;
 }
 for(i=0; i<str.length; i++) {
  if(str.charAt(i) == '.') {
   str = str.substring(0, i);
   break;
  }
 }
 if(str.length == 0)
  return -1;
 return parseInt(str, 10);
}
function isAllNum(str) {
 for (var i=0; i<str.length; i++){
  if((str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) == '.'))
   continue;
  return 0;
 }
 return 1;
}
function isAllNumAndSlash(str) {
 for (var i=0; i<str.length; i++){
  if( (str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) == '.') || (str.charAt(i) == '/'))
   continue;
  return 0;
 }
 return 1;
}
function isNumOnly(str) {
 for (var i=0; i<str.length; i++){
  if((str.charAt(i) >= '0' && str.charAt(i) <= '9') )
   continue;
  return 0;
 }
 return 1;
}
function checkRange(str, num, min, max) {
 d = atoi(str,num);
 if(d > max || d < min)
  return false;
 return true;
}
function hasSubStr(str, substr) {
 return str.search(substr) >= 0;
}
function multiLangRadio(txt) {
 if(Butterlate.getLang()=="ar")
  document.write("<font dir=\"rtl\">"+_(txt));
 else
  document.write("<font>"+_(txt));
}
function toUpTime( uptime ) {
var upday = parseInt(uptime / (24 * 3600));
var uphr = parseInt((uptime - upday * 24 * 3600) / (3600));
var upmin = parseInt((uptime - upday * 24 * 3600 - uphr * 3600) / 60);
var upsec = parseInt(uptime - upday * 24 * 3600 - uphr * 3600 - upmin * 60);
 uphr=uphr<10?"0"+uphr.toString():uphr.toString();
 upmin=upmin<10?"0"+upmin.toString():upmin.toString();
 upsec=upsec<10?"0"+upsec.toString():upsec.toString();
 if (upday) {
  var buf2=upday.toString() + " Day";
  if (upday > 1)
   buf2=buf2+"s";
  buf2=buf2+"  ";
 }
 else {
  buf2="";
 }
 return buf2+uphr+":"+upmin+":"+upsec;
}
function checkIE10() {
var pos=navigator.userAgent.indexOf("MSIE");
 if(pos!=-1 && (parseInt(navigator.userAgent.substr(pos+4, 10))>=9) ) {
  $('.Rotate-90').removeClass('Rotate-90').addClass('Rotate-90-IE10');
 }
}
function breakWord(inString, maxWordLength, htmlEncode) {
 if( inString=="" || inString==null || inString.length==null ) {
  return "";
 }
 var mystr = inString.match(new RegExp('[\\S]{1,}', 'g'));
 var retstr="";
 for(x=0;x<mystr.length;x++) {
  var mystr2 = mystr[x].match(new RegExp('[\\s\\S]{1,'+maxWordLength+'}', 'g'));
  if(mystr2.length==1) {
   retstr+=htmlEncode==1?htmlNumberEncode(mystr[x]):mystr[x]+" ";
  }
  else {
   for(y=0;y<mystr2.length;y++) {
    retstr+=htmlEncode==1?htmlNumberEncode(mystr2[y]):mystr2[y]+"<br/>";
   }
  }
 }
 return retstr;
}
function add_options(myid, mylist, def) {
 $.each( ["#"+myid], function(idx,el) {
  $.each(
   mylist, function(val,txt) { $(el).append("<option value='"+val+"'>"+txt+"</option>");}
  );
 });
 if(def!="") {
  $("#"+myid).val(def);
 }
}
function hidePPPoE()
{
 if(service_pppoe_server_0_enable=="1") {
  $(".hide_for_pppoe_en").css("display", "none");
  $(".pppoeEnablesMsg").css("display", "");
 }
}
function blockUI_alert(msg, func) {
 if($.type(func)!="undefined") {
  myfunc=func;
 }
 else {
  myfunc=function() {
  };
 }
 $.blockUI( {message: _(msg)+"		<div class='button-raw med'>		<button class='secondary med' onClick='$.unblockUI();myfunc();'>"+_("CSok")+"</button>		</div>", css: {width:'320px', padding:'20px 20px'}
 });
}
function blockUI_alert_l(msg, func) {
 if($.type(func)!="undefined") {
  myfunc=func;
 }
 else {
  myfunc=function() {
  };
 }
 if($.type(msg)!="undefined" && msg.length>50) {
  align="left";
 }
 else {
  align="center";
 }
 $.blockUI( {message: "<div style='text-align:"+align+";'>"+_(msg)+"		<div class='button-raw med'>		<button class='secondary med' onClick='$.unblockUI();myfunc();'>"+_("CSok")+"</button>		</div></div>", css: {width:'320px', padding:'20px 20px'}
 });
}
function blockUI_confirm(msg, func1, func2, but1_text, but2_text, extraCss) {
 myfunc=func1;
 myfunc2=function(){return;}
 if (typeof func2 == 'function') {
  myfunc2=func2
 }
 but1_text = but1_text ?? _("CSok");
 but2_text = but2_text ?? _("cancel");
 $.blockUI( {message: msg+"		<div class='button-double'>		<button class='secondary med' onClick='$.unblockUI();myfunc();'>"+ but1_text +"</button><button class='secondary med' onClick='$.unblockUI();" + "myfunc2();'>"+ but2_text +"</button>		</div>", css: Object.assign({width:'380px', padding:'20px 20px'}, extraCss)
 });
}
function blockUI_confirm_l(msg, func1, func2) {
 myfunc=func1;
 myfunc2=function(){return;}
 if (typeof func2 == 'function') {
  myfunc2=func2
 }
 if(msg.length>50) {
  align="left";
 }
 else {
  align="center";
 }
 $.blockUI( {message: "<div style='text-align:"+align+";'>"+msg+"		<div class='button-double'>		<button class='secondary med' onClick='$.unblockUI();myfunc();'>"+_("CSok")+"</button><button class='secondary med' onClick='$.unblockUI();" + "myfunc2();'>"+_("cancel")+"</button>		</div></div>", css: {width:'380px', padding:'20px 20px'}
 });
}
function blockUI_cancel(msg, func) {
 if($.type(func)!="undefined") {
  myfunc=func;
 }
 else {
  myfunc=function() {
  };
 }
 $.blockUI( {message: _(msg)+"		<div class='button-raw med'>		<button class='secondary med' onClick='$.unblockUI();myfunc();'>"+_("cancel")+"</button>		</div>", css: {width:'320px', padding:'20px 20px'}
 });
}
function blockUI_input(msg, func1, func2, but1_text, but2_text, extraCss) {
 myfunc1 = func1 ?? function(){};
 myfunc2 = func2 ?? function(){};
 but1_text = but1_text ?? "CSok";
 but2_text = but2_text ?? "cancel";
 $.blockUI( {message: _(msg) + "		<div style='padding:12px 65px'>		<input class='large' type='text' id='inp_block'>		</div>		<div class='button-double' style='padding-top:40px'>		<button class='secondary med' onClick='$.unblockUI();myfunc1($(\"#inp_block\").val());'>"+ _(but1_text) +"</button>		<button class='secondary med' onClick='$.unblockUI();myfunc2($(\"#inp_block\").val());'>"+ _(but2_text) +"</button>		</div>",
  css: Object.assign({width:'320px', padding:'20px 20px'}, extraCss)
 });
}
function get_first_form() {
 var forms = window.document.forms;
 var ix;
 for (ix = 0; ix < forms.length; ix++) {
  var e = forms[ix];
  if (e.id != "logOffForm") {
   return e;
  }
 }
 return null;
}
function validate_alert( t1, t2, t3 ) {
 $.unblockUI();
 if(typeof(t1)=="undefined" || t1=="") {
  t1="errorsTitle";
 }
 if(typeof(t2)=="undefined" || t2=="") {
  t2=VALIDATOR.config.errors.summary;
 }
 t1 = _(t1);
 t2 = _(t2);
 var e=$(get_first_form()), g="form-error";
 a='<li><a class="link-text jump-link" href="#{id}"><span class="icon icon-arrow-r"></span>{error}</a></li>';
 h='<div class="note" id="'+g+'">			<div class="wrap failure">				<h2><span class="access">'+VALIDATOR.config.strings.error+'</span>'+t1+'</h2>';
    if (t3==true) {
     var len = t2.length;
     for (i = 0; i < len; i++)
      h+='<p>'+t2[i]+'</p>';
    } else {
     h+='<p>'+t2+'</p>';
    }
    h+='<ul class="list-plain"></ul>			</div>		</div>';
 h=$(h);
 if(e.attr("data-summary")==="false") {
  return;
 }
 e.prev(".note").remove();
 e.before(h);
 window.location.hash=g;
 $("#form").validationEngine("updatePromptsPosition");
}
function clear_alert() {
 var e=$(get_first_form());
 e.prev(".note").remove();
 $("#form").validationEngine("hideAll");
}
function success_alert(t1, t2) {
 if(typeof(t1)=="undefined" || t1=="") {
  t1="succCongratulations";
 }
 if(typeof(t2)=="undefined" || t2=="") {
  t2="submitSuccess";
 }
 var e=$(get_first_form()), g="form-success";
 h='<div class="note" id="'+g+'">			<div class="wrap success" style="padding-bottom:6px">				<h2>'+_(t1)+'</h2>				<p>'+_(t2)+'</p>			</div>		</div>';
 h=$(h);
 if(e.attr("data-summary")==="false") {
  return;
 }
 e.prev(".note").remove();
 e.before(h);
 window.location.hash=g;
}
(function(){this.VALIDATOR={}}).call(this);
(function() {
VALIDATOR.config={
 strings:{
  error: "_('log Error')+' - '"
 },
 errors:{
  error: "_('log Error')+' - '",
  summary: _('errorsSummary'),
  title: "_('validatorTitle')"
 }
};
}(VALIDATOR));
(function($) {
$.fn.validationEngineLanguage = function(){};
$.validationEngineLanguage = {
 newLang: function(){
  $.validationEngineLanguage.allRules = {
   "required": {
    "regex": "none",
    "alertText": _('fieldRequired'),
    "alertTextCheckboxMultiple": "* Please select an option",
    "alertTextCheckboxe": "* This checkbox is required",
    "alertTextDateRange": "* Both date range fields are required"
   },
   "requiredInFunction": {
    "func": function(field, rules, i, options){
     return (field.val() == "test") ? true : false;
    },
    "alertText": "* Field must equal test"
   },
   "dateRange": {
    "regex": "none",
    "alertText": "* Invalid ",
    "alertText2": "Date Range"
   },
   "dateTimeRange": {
    "regex": "none",
    "alertText": "* Invalid ",
    "alertText2": "Date Time Range"
   },
   "minSize": {
    "regex": "none",
    "alertText": "* Minimum ",
    "alertText2": " characters required"
   },
   "maxSize": {
    "regex": "none",
    "alertText": "* Maximum ",
    "alertText2": " characters allowed"
   },
   "groupRequired": {
    "regex": "none",
    "alertText": "_('groupRequiredError')"
   },
   "min": {
    "regex": "none",
    "alertText": "* Minimum value is "
   },
   "max": {
    "regex": "none",
    "alertText": "* Maximum value is "
   },
   "past": {
    "regex": "none",
    "alertText": "* Date prior to "
   },
   "future": {
    "regex": "none",
    "alertText": "* Date past "
   },
   "maxCheckbox": {
    "regex": "none",
    "alertText": "* Maximum ",
    "alertText2": " options allowed"
   },
   "minCheckbox": {
    "regex": "none",
    "alertText": "* Please select ",
    "alertText2": " options"
   },
   "equals": {
    "regex": "none",
    "alertText": _("passwordMismatch")
   },
   "creditCard": {
    "regex": "none",
    "alertText": "* Invalid credit card number"
   },
   "phone": {
    "regex": /^([\+][0-9]{1,3}[\ \.\-])?([\(]{1}[0-9]{2,6}[\)])?([0-9\ \.\-\/]{3,20})((x|ext|extension)[\ ]?[0-9]{1,4})?$/,
    "alertText": "* Invalid phone number"
   },
   "email": {
    "regex": /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    "alertText": "* Invalid email address"
   },
   "integer": {
    "regex": /^[\-\+]?\d+$/,
    "alertText": "* Not a valid integer"
   },
   "number": {
    "regex": /^[\-\+]?((([0-9]{1,3})([,][0-9]{3})*)|([0-9]+))?([\.]([0-9]+))?$/,
    "alertText": "* Invalid floating decimal number"
   },
   "date": {
  "func": function (field) {
    var pattern = new RegExp(/^(\d{4})[\/\-\.](0?[1-9]|1[012])[\/\-\.](0?[1-9]|[12][0-9]|3[01])$/);
    var match = pattern.exec(field.val());
    if (match == null)
     return false;
    var year = match[1];
    var month = match[2]*1;
    var day = match[3]*1;
    var date = new Date(year, month - 1, day);
    return (date.getFullYear() == year && date.getMonth() == (month - 1) && date.getDate() == day);
   },
   "alertText": "* Invalid date, must be in YYYY-MM-DD format"
   },
   "ipv4": {
    "regex": /^((([01]?[0-9]{1,2})|(2[0-4][0-9])|(25[0-5]))[.]){3}(([0-1]?[0-9]{1,2})|(2[0-4][0-9])|(25[0-5]))$/,
    "alertText": "* Invalid IP address"
   },
   "url": {
    "regex": /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\U000000a0-\U0000d7ff\U0000f900-\U0000fdcf\U0000fdf0-\U0000ffef])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\U000000a0-\U0000d7ff\U0000f900-\U0000fdcf\U0000fdf0-\U0000ffef])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\U0000e000-\U0000f8ff]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\U000000a0-\U0000d7ff\U0000f900-\U0000fdcf\U0000fdf0-\U0000ffef])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i,
    "alertText": "* Invalid URL"
   },
   "coapurl": {
    "regex": /^(coaps?):\/\/(((([a-z]|\d|-|\.|_|~|[\U000000a0-\U0000d7ff\U0000f900-\U0000fdcf\U0000fdf0-\U0000ffef])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\U000000a0-\U0000d7ff\U0000f900-\U0000fdcf\U0000fdf0-\U0000ffef])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?$/i,
    "alertText": "* Invalid URL; example: coap://server.com"
   },
   "onlyNumber": {
    "regex": /^[0-9]+$/,
    "alertText": "* Numbers only"
   },
   "onlyNumberSp": {
    "regex": /^[0-9\ ]+$/,
    "alertText": "* Numbers only"
   },
   "onlyLetterSp": {
    "regex": /^[a-zA-Z\ \']+$/,
    "alertText": "* Letters only"
   },
   "onlyLetterNumber": {
    "regex": /^[0-9a-zA-Z]+$/,
    "alertText": "* No special characters allowed"
   },
   "ajaxUserCall": {
    "url": "ajaxValidateFieldUser",
    "extraData": "name=eric",
    "alertText": "* This user is already taken",
    "alertTextLoad": "* Validating, please wait"
   },
   "ajaxUserCallPhp": {
    "url": "phpajax/ajaxValidateFieldUser.php",
    "extraData": "name=eric",
    "alertTextOk": "* This username is available",
    "alertText": "* This user is already taken",
    "alertTextLoad": "* Validating, please wait"
   },
   "ajaxNameCall": {
    "url": "ajaxValidateFieldName",
    "alertText": "* This name is already taken",
    "alertTextOk": "* This name is available",
    "alertTextLoad": "* Validating, please wait"
   },
    "ajaxNameCallPhp": {
     "url": "phpajax/ajaxValidateFieldName.php",
     "alertText": "* This name is already taken",
     "alertTextLoad": "* Validating, please wait"
    },
   "validate2fields": {
    "alertText": "* Please input HELLO"
   },
   "dateFormat":{
    "regex": /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$|^(?:(?:(?:0?[13578]|1[02])(\/|-)31)|(?:(?:0?[1,3-9]|1[0-2])(\/|-)(?:29|30)))(\/|-)(?:[1-9]\d\d\d|\d[1-9]\d\d|\d\d[1-9]\d|\d\d\d[1-9])$|^(?:(?:0?[1-9]|1[0-2])(\/|-)(?:0?[1-9]|1\d|2[0-8]))(\/|-)(?:[1-9]\d\d\d|\d[1-9]\d\d|\d\d[1-9]\d|\d\d\d[1-9])$|^(0?2(\/|-)29)(\/|-)(?:(?:0[48]00|[13579][26]00|[2468][048]00)|(?:\d\d)?(?:0[48]|[2468][048]|[13579][26]))$/,
    "alertText": "* Invalid Date"
   },
   "dateTimeFormat": {
    "regex": /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])\s+(1[012]|0?[1-9]){1}:(0?[1-5]|[0-6][0-9]){1}:(0?[0-6]|[0-6][0-9]){1}\s+(am|pm|AM|PM){1}$|^(?:(?:(?:0?[13578]|1[02])(\/|-)31)|(?:(?:0?[1,3-9]|1[0-2])(\/|-)(?:29|30)))(\/|-)(?:[1-9]\d\d\d|\d[1-9]\d\d|\d\d[1-9]\d|\d\d\d[1-9])$|^((1[012]|0?[1-9]){1}\/(0?[1-9]|[12][0-9]|3[01]){1}\/\d{2,4}\s+(1[012]|0?[1-9]){1}:(0?[1-5]|[0-6][0-9]){1}:(0?[0-6]|[0-6][0-9]){1}\s+(am|pm|AM|PM){1})$/,
    "alertText": "* Invalid Date or Date Format",
    "alertText2": "Expected Format: ",
    "alertText3": "mm/dd/yyyy hh:mm:ss AM|PM or ",
    "alertText4": "yyyy-mm-dd hh:mm:ss AM|PM"
   }
  };
 }
};
$.validationEngineLanguage.newLang();
})(jQuery);
function blockUI_wait(msg) {
 $.blockUI({centerX: true, centerY: true, css: { left: parseInt($(window).width()/2-150)+"px", top:"320px", width: "300px", padding: "20px 30px"}, message: msg+"&nbsp;&nbsp;<i class='progress-sml' style='padding-bottom:2px;'></i>"});
}
function blockUI_wait_progress(msg) {
 $.blockUI({centerX: true, centerY: true, css: { left: parseInt($(window).width()/2-150)+"px", top:"320px", width: "300px", padding: "20px 30px"}, message: "<span id='progress-message'>" + msg + "</span> <p><div id='progressbar'></div>"});
}
function set_progress_message(msg) {
 $("#progress-message").text(msg);
}
function blockUI_wait_confirm(msg, label, call_back) {
 $.blockUI({centerX: true, centerY: true,
  css: { left: parseInt($(window).width()/2-150)+"px", top:"320px", width: "300px", padding: "20px 30px"},
  message: msg+"<p><button type='button' id='wait_confirm' class='secondary'>"});
 $("#wait_confirm").text(label);
 $("#wait_confirm").click(call_back);
}
function rdb_tool(token) {
 var opt_idx=1;
 var opt_obj=new Object();
 var csrf_token=token;
 opt_obj["csrfTokenGet"]=csrf_token;
 this.reset=function() {
  opt_idx=1;
  opt_obj=new Object();
  opt_obj["csrfTokenGet"]=csrf_token;
 };
 this.set_flag=function(flags) {
  opt_obj["flag"]=flags;
 };
 this.add_to_mget=function(cfg){
  var rdb=this;
  $.each(cfg,function(i,o){
   if((typeof o != 'undefined') && (o.el != null))
    rdb.add(o.rdb);
  });
 };
 this.add_to_mset=function(cfg) {
  var rdb=this;
  $.each(cfg,function(i,o){
   var val;
   if(typeof o != 'undefined')
    if(o.el == null)
     val=o.def;
    else
     val=load_value_from_element(o.el);
   if((typeof o != 'undefined') && (o.el != null))
    rdb.add(o.rdb,val);
  });
 };
 this.get_ctrls=function(cfg) {
  var ctrls=new Array();
  $.each(cfg,function(i,o){
   if((typeof o == 'undefined') || (o.el == null))
    return;
   if(is_ip_address_element(o.el))
    ctrls.push(get_ip_address_elements(o.el));
   else
    ctrls.push(o.el);
  });
  return ctrls.join(",");
 };
 this.disable_ctrl=function(cfg,dis) {
  $(this.get_ctrls(cfg)).attr("disabled",dis);
 };
 this.pour_to_ctrl=function(res,cfg) {
  $.each(cfg,function(i,o){
   if((typeof o == 'undefined') || (o.el == null))
    return true;
   var val;
   if($.type(res[o.rdb]) === "undefined" || $.type(res[o.rdb]) === "null" || res[o.rdb] == "")
    val=o.def;
   else
    val=res[o.rdb];
   load_value_to_element(o.el,val);
  });
 };
 this.add=function(rdb_var,rdb_val) {
  var rdbs=Array();
  if(rdb_var instanceof Array) {
   $.merge(rdbs,rdb_var)
  }
  else {
   rdbs.push(rdb_var);
  }
  if(rdb_val instanceof Array) {
   $.merge(rdbs,rdb_val)
  }
  else if(rdb_val!==undefined) {
   rdbs.push(rdb_val);
  }
  $.each(rdbs,function(i,v){
   opt_obj["opt"+opt_idx]=v;
   opt_idx++;
  });
 };
 this.mget=function(func) {
  opt_obj["cmd"]="rdb_mget";
  $.getJSON(
   "./cgi-bin/rdb_tool.cgi",
   opt_obj,
   func
  );
 };
 this.mset=function(func) {
  opt_obj["cmd"]="rdb_mset";
  $.getJSON(
   "./cgi-bin/rdb_tool.cgi",
   opt_obj,
   func
  );
 };
 this.wait_for_rdb_chg=function(rdb_to_wait,cur,timeout,func) {
  var timer;
  var s;
  var n;
  s=$.now();
  var rdb=this;
  var timer_func=function(){
   n=$.now();
   if( n-s >= timeout ) {
    func(cur);
    return;
   }
   rdb.reset();
   rdb.add(rdb_to_wait);
   rdb.mget(function(res){
    if(res[rdb_to_wait]==cur) {
     timer=setTimeout(timer_func,500);
    }
    else {
     func(res[rdb_to_wait]);
    }
   });
  };
  timer=setTimeout(timer_func,500);
 };
 this.wait_for_rdb_result=function(rdb_to_wait,timeout,func) {
  this.wait_for_rdb_chg(rdb_to_wait,"",timeout,func);
 }
}
function cgi(bin, token) {
 var url=bin;
 var opt_idx=1;
 var opt_obj=new Object();
 var csrf_token;
 if (token !== undefined) {
  csrf_token=token;
  opt_obj["csrfTokenGet"]=csrf_token;
 }
 this.reset=function() {
  opt_idx=1;
  opt_obj=new Object();
  if (csrf_token !== undefined) {
   opt_obj["csrfTokenGet"]=csrf_token;
  }
 };
 this.dn=function(cmd,func) {
  opt_obj["cmd"]=cmd;
  var form=$("<form/>");
  form.attr("action",url+"?"+$.param(opt_obj));
  form.attr("method","post");
  form.attr("encType","multipart/form-data");
  form.attr("style","display:none");
  form.appendTo("body");
  form.submit();
  form.remove();
 }
 this.reset_up=function(el) {
  $(el).closest("form").each(function(){
   this.reset();
  });
 }
 this.up=function(el,complete_func,preserveResponseFormatting) {
  if (preserveResponseFormatting === undefined) {
   preserveResponseFormatting = false;
  }
  var upload_input=$(el);
  if(!$("#postiframe").length) {
   $("<iframe id='postiframe' name='postiframe' style='width: 0; height: 0; border: none;'></iframe>").appendTo("body");
  }
  var form = $(el).closest("form");
  $("#postiframe").unbind("load");
  $("#postiframe").load(function(){
   var doc=$("#postiframe").contents();
   if (preserveResponseFormatting) {
    var res=doc.find("body pre").text();
   } else {
    var res=doc.find("body pre").html();
   }
   complete_func($.parseJSON(res));
  });
  form.attr("action", url+"?"+$.param(opt_obj));
  form.attr("method", "post");
  form.attr("enctype", "multipart/form-data");
  form.attr("encoding", "multipart/form-data");
  form.attr("target", "postiframe");
  form.submit();
 };
 this.add=function(opt) {
  var opts=Array();
  if(opt instanceof Array) {
   $.merge(opts,opt)
  }
  else {
   opts.push(opt);
  }
  $.each(opts,function(i,v){
   opt_obj["opt"+opt_idx]=v;
   opt_idx++;
  });
 };
 this.setcmd=function(cmd) {
  opt_obj["cmd"]=cmd;
 };
 this.run=function(cmd,func) {
  opt_obj["cmd"]=cmd;
  $.getJSON(
   url,
   opt_obj,
   func
  );
 };
 this.poll=function(interval,cmd,func) {
  var this_cgi=this;
  this.run(cmd,function(r){
   var res=func(r);
   if((res===undefined || res==true) && (interval>0))
    setTimeout(
     function() {
      this_cgi.poll(interval,cmd,func);
     },
     interval
    );
  });
 }
}
var windowConfirm;
var windowPrompt;
function check_insert_rtl( txt ) {
 if(Butterlate.getLang()!="ar")
  return txt;
 var ray = new Array();
 var retStr="";
 ray = txt.split("\n");
 for(i=0; i<ray.length; i++)
  retStr = retStr+"\u202b"+ray[i]+"\n";
 return retStr;
}
function check_phoneRegex(e) {
var phoneRegEx = /[^(\d+\+)]/g;
 e.value=e.value.replace(phoneRegEx,'');
}
function overridewindowAlert() {
 windowConfirm=window.confirm;
 windowPrompt=window.prompt;
 window.alert = function(txt) {
  blockUI_alert_l( check_insert_rtl( txt ) );
 }
 window.confirm = function(txt) {
  return windowConfirm( check_insert_rtl( txt ) );
 }
 window.prompt = function(txt,def) {
  return windowPrompt(check_insert_rtl( txt ),check_insert_rtl( def ));
 }
}
overridewindowAlert();
function row_display(id, display) {
 if(document.getElementById){
  var el = document.getElementById(id);
  el.style.display = display ? '' : 'none';
 }
}
function get_ip_address_elements(el) {
 if(el[0]=="#")
  return false;
 var els=new Array();
 for(i=1;i<=4;i++)
  els.push("#" + el + i);
 var ids=els.join(",");
 if( $(ids).filter(".ip-adress").length==4 )
  return ids;
 return "";
}
function is_ip_address_element(el) {
 return get_ip_address_elements(el)!="";
}
function load_value_from_element(el) {
 if(is_ip_address_element(el))
  return parse_ip_from_fields(el);
 else if($(el).is("input:radio.access")) {
  if( $(el).filter(":checked").length>0 )
   return $(el).filter(":checked").val();
 }
 return $(el).val();
}
function load_value_to_element(el,val) {
 var toggle_element;
 if($(el).is("input:checkbox"))
  $(el).prop("checked",val);
 else if($(el).is("input:radio.access")) {
  if($.type(val)=="string") {
   val=(val=="on" || val=="1")?true:false;
  }
  else if($.type(val)=="number") {
   val=(val>0)?true:false;
  }
  if($.type(val)=="boolean") {
   if( $(el).filter("[value=on]").length>0 )
    filter=val?"[value=on]":"[value=off]";
   if( $(el).filter("[value=yes]").length>0 )
    filter=val?"[value=yes]":"[value=no]";
   else if( $(el).filter("[value=1]").length>0 )
    filter=val?"[value=1]":"[value=0]";
   else
    filter=val?":first":":last";
  }
  else if ( ($.type(val)=="undefined") || (val=="") )
   filter=":first";
  else
   filter="[value="+val+"]";
  $(el).filter(filter).prop("checked",true);
  $(el).blur();
  toggle_element=$(el).parent().attr("data-toggle-element");
  if(toggle_element!==undefined) {
   $("#"+toggle_element).toggle(val);
  }
 }
 else if($(el).is("select")) {
  $(el).children("[value='"+val+"']").attr("selected",true);
  $(el).val(val);
 }
 else if(is_ip_address_element(el)) {
  parse_ip_into_fields(val,el);
 }
 else if($(el).is("span")) {
  $(el).html(val);
 }
 else {
  $(el).val(val);
 }
}
function load_values_from_elements(cfg) {
 var res={};
 $.each(cfg, function(el,rdb) {
  res[rdb]=load_value_from_element(el);
 });
 return res;
}
function load_values_to_elements(cfg) {
 $.each(cfg,
  function(el,val) {
   load_value_to_element(el,val);
  }
 );
}
function lang_sentence(stc, arr) {
 for(i in arr) {
  stc=stc.replace("%%"+i, arr[i]);
 }
 return stc;
}
function is_touch_device() {
 return ('ontouchstart' in window) || (navigator.userAgent.indexOf('IEMobile') !== -1);
}
function is_edge_browser() {
 return (navigator.userAgent.indexOf('Edge') !== -1);
}
function parseQueryString(queryString) {
 var params = {};
 queryString.split("&").forEach ( function(param) {
   temp = param.split('=');
   params[temp[0]] = temp[1];
  } );
 params.getParamByName = function ( paramName ) {
  param = this[paramName];
  if ( param === undefined )
   return "";
  return param;
 };
 return params;
};
function htmlNumberEncode(input) {
 var i = 0;
 var c = 0;
 var string = "";
 for (i = 0; i < input.length; i++) {
  c = input.charCodeAt(i);
  string += "&#" + c + ";";
 }
 return string;
}
var Base64 = {
    _keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    encode : function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = Base64._utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
            this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
            this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
        }
        return output;
    },
    decode : function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = Base64._utf8_decode(output);
        return output;
    },
    _utf8_encode : function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
        }
        return utftext;
    },
    _utf8_decode : function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while ( i < utftext.length ) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}
function alertInvalidCsrfToken() {
 validate_alert( _("invalidTokenTitle"), _("invalidTokenMsg"));
}
function alertInvalidRequest() {
 validate_alert( _("invalidRequestTitle"), _("invalidRequestMsg"));
}
function getUtf8StringLengthInBytes(string) {
 var length = 0;
 for (var n = 0; n < string.length; n++) {
  var c = string.charCodeAt(n);
  if (c < 128) {
   length++;
  }
  else if((c > 127) && (c < 2048)) {
   length += 2;
  }
  else {
   length += 3;
  }
 }
 return length;
}
function setZxcvbntsOption() {
    const options = {
      translations: zxcvbnts['language-en'].translations,
      graphs: zxcvbnts['language-common'].adjacencyGraphs,
      dictionary: {
        ...zxcvbnts['language-common'].dictionary,
        ...zxcvbnts['language-en'].dictionary,
      },
    }
    zxcvbnts.core.zxcvbnOptions.setOptions(options);
}
function passStrengthValidation(PassStr, score) {
 var token, PassLen, result, passScore;
 var nUpper=0, nLower=0, nSpecial=0, nNum=0, nCons=0;
 PassLen = PassStr.length;
 if (typeof(score) == "undefined") {
  result = zxcvbnts.core.zxcvbn(PassStr);
  console.log('password score of "'+PassStr+'" = '+result.score);
  passScore = result.score;
 } else {
  passScore = score;
 }
 token = PassStr.match(/[A-Z]/g);
 if (token)
  nUpper = token.length;
 token = PassStr.match(/[a-z]/g);
 if (token)
  nLower = token.length;
 token = PassStr.match(/[0-9]/g);
 if (token)
  nNum = token.length;
 token = PassStr.match(/[`~!@#\$%\^&*()\-_=+\[{\]}\\|;:'",<.>\/?]/g);
 if (token) {
  nSpecial = token.length;
 }
 return (PassLen <= PASSWD_MAXLEN && PassLen >= 8 && nNum > 0 && nUpper > 0 && nSpecial > 0 && passScore >= 2);
}
function getPassStrength(PassStr) {
 var result;
 if (PassStr.length == 0)
  return 'none';
 if (PassStr.length > PASSWD_MAXLEN)
  return 'too_long';
 var result = zxcvbnts.core.zxcvbn(PassStr);
 console.log('password score of "'+PassStr+'" = '+result.score);
 if (result.score >= 2) {
  if (passStrengthValidation(PassStr, result.score))
   return 'strong';
  else
   return 'medium';
 } else if (result.score >= 1) {
  return 'medium';
 } else if (result.score >= 0) {
  return 'weak';
 }
 return 'none';
}
function updatePassStrengthField(t, strength, title) {
 if (strength == 'strong') {
  if (title)
   t.title = _("strongPassword");
  else
   t.innerHTML = _("strongPassword");
  t.style.color="Green";
 } else if (strength == 'medium') {
  if (title)
   t.title = _("mediumPassword");
  else
   t.innerHTML = _("mediumPassword");
  t.style.color="Orange";
 } else if (strength == 'weak') {
  if (title)
   t.title = _("weakPassword");
  else
   t.innerHTML = _("weakPassword");
  t.style.color="Red";
 } else if (strength == 'too_long') {
  if (title)
   t.title = _("passwordTooLong");
  else
   t.innerHTML = _("passwordTooLong");
  t.style.color="Red";
 } else {
  if (title)
   t.title = "";
  else
   t.innerHTML = "";
  t.style.color="Black";
 }
}
function updatePassStrength(f, t) {
 var PassStr, strength = 0;
 PassStr = f.value;
 strength = getPassStrength(PassStr);
 updatePassStrengthField(t, strength, 0);
}
function smsPassStrength(f, t) {
 var PassStr, strength = 0;
 filterUsingFn( f, isNameUnsafe );
 updatePassStrength(f, t);
}
function convert_to_html_entity(value) {
    var newStr = "";
 var patt=/[a-zA-Z0-9]/
    for ( i = 0; i < value.length; i++ ) {
        var nextChar = value.charAt(i);
  if (patt.test(nextChar))
   newStr = newStr + nextChar;
  else
   newStr = newStr + convertCharToEntity(nextChar);
    }
    return newStr;
}
var bulletHead=convert_to_html_entity("  • ");
function showStrongPasswordInfo() {
 clear_alert();
 var msg="<div class='message_box' style='text-align:left;'>";
 msg+=_("passwordWarning6")+"<br/>";
 msg+=bulletHead+_("passwordWarning2")+"<br/>";
 msg+=bulletHead+_("passwordWarning3")+"<br/>";
 msg+=bulletHead+_("passwordWarning4")+convert_to_html_entity('`~!@#$%^&*()-_=+[{]}\|;:\'\",\<.>/?.')+"<br/>";
 msg+=bulletHead+_("passwordWarning5")+"<br/>";
 msg+="<br/></div><div style='margin-left:180px'><button class='secondary mini' onClick='$.unblockUI();'>"+_("CSok")+"</button><div/>";
 $.blockUI({message:msg});
 return;
}
function showStrongSmsPasswordInfo() {
 clear_alert();
 var msg="<div class='message_box' style='text-align:left;'>";
 msg+=_("passwordWarning6")+"<br/>";
 msg+=bulletHead+_("passwordWarning2")+"<br/>";
 msg+=bulletHead+_("passwordWarning3")+"<br/>";
 msg+=bulletHead+_("passwordWarning8")+ convert_to_html_entity('!*()?/.')+"<br/>";
 msg+=bulletHead+_("passwordWarning5")+"<br/>";
 msg+="<br/></div><div style='margin-left:180px'><button class='secondary mini' onClick='$.unblockUI();'>"+_("CSok")+"</button><div/>";
 $.blockUI({message:msg});
 return;
}
function blockUI_RebootWaiting() {
  var msg = genRebootWaitingMsgHtml();
 $.blockUI({centerX: true, centerY: true, css: { left: "30%", top:"20%", width: "400px", padding: "20px 30px"}, message: msg});
}
function infoBoxPlaceHolder(objId, infoIconTitle) {
 var html = "<a href='javascript:customShowInfo("+objId+");' id='info' title='"+_(infoIconTitle)+"'><i class='icon help_info' id='icon_info_"+objId+"'></i></a><div id='infoBox"+objId+"' class='infoBox' style='display:none;'></div>";
 return html;
}
var showingInfoBoxId = -1;
function showInfo(id, title, content) {
 clear_alert();
 if (showingInfoBoxId >= 0) {
  $("#infoBox"+showingInfoBoxId).css("display", "none");
  showingInfoBoxId = -1;
 }
 var html = "<div class='info_box_title'>" + _(title) + "</div>";
 if (Array.isArray(content)) {
  html += "<ul class='info_box_lines'>";
  content.forEach(function(line) {
   html += "<li class='info_box_line'>" + _(line) + "</li>";
  });
  html += "</ul>";
 } else {
  html += "<div class='info_box_content'>" + _(content) + "</div>";
 }
 html += "<div class='info_box_buttons'><button onClick='$(\"#infoBox" + id + "\").css(\"display\", \"none\");' type='button' class='secondary'>"+_("CSok")+"</button></div>";
 $("#infoBox" + id).html(html);
 $("#infoBox" + id).css("display", "block");
 $("#infoBox" + id).css("position", "absolute");
 var boxWidth = 300;
 $("#infoBox" + id).css("width", boxWidth);
 var icon = $("#icon_info_"+id);
 var iconPosition = icon.offset();
 $("#infoBox" + id).css("top", iconPosition.top);
 $("#infoBox" + id).css("left", iconPosition.left - boxWidth);
 showingInfoBoxId = id;
}
}
